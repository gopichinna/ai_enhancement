/* jshint ignore:start */

(function (){
  'use strict';

  const C_VERSION = '22.2.0';
  const T_VERSION = '${__tVersion__}';
  const CACHE_NAME = `d2sv_${C_VERSION}_${T_VERSION}`;
  const DB_NAME = 'D2SV';
  const DB_VERSION = 1; //TODO: Update this whenever the DB schema changes
  const DEFAULT_CACHE_TTL_MS = 30000;
  const DEFAULT_CACHE_MAX_TTL_MS = 24 * 60 * 60 * 1000; // 1 day
  const LOG_PREFIX = '[D2SV-SW]';
  const DEFAULT_CONFIG = {
    enabled: true,
    logging: false,
    permanentCacheEndpoints: [
      "services",
      "product-info",
      "about-d2"
    ],
    noCacheEndpoints: {
      'logout': 0,
      "preview-urls": 0,
      "Download": 0,
      "d2-zip-and-downloads/[^/]+":0,
      "search-configuration/[a-f0-9]{16,}/d2-search-attribute-value-list":0,
      "d2-saved-searches/[a-f0-9]{16,}/[^/]+": 0,
      "d2-saved-searches/[a-f0-9]{16,}": 0
    },
    endpointsUsedBeforeAccessContextSetup: {
      'd2-preferences': 0,
      'currentuser': 0,
      "repositories/[^/]+": 0
    }
  };

  const staticContentsToCache = [
    //STATIC_FILES_LIST
  ];

  self.addEventListener('install', (event) => {
    logDebug('Installing');

    let promise = new Promise((res, rej) => {
      if(staticContentsToCache.length) {
        caches
          .open(CACHE_NAME)
          .then(cache => {
            return cache.addAll(staticContentsToCache);
          })
          .then(res, rej);
      } else {
        res();
      }
    }).catch(() => {});

    event.waitUntil(promise);
  });

  self.addEventListener('activate', (event) => {
    logDebug('Activating');

    let promise = caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => (cacheName!==CACHE_NAME ? caches.delete(cacheName) : undefined))
        );
      })
      .then(() => getDB(DB_NAME, DB_VERSION, (db) => {
        db.createObjectStore('clients', {keyPath: 'id'});
        db.createObjectStore('config');
        db.createObjectStore('lt-cache-stat');
      }))
      .then(() => {
        const configUrl = self.location.pathname.replace('/ui/', `/ui-${new Date().getTime()}/`).replace('service-worker.js', 'sw-config.json');

        return fetch(configUrl).then(resp => resp.json()).catch(() => {});
      })
      .then((config) => {
        config = config || {};
        config._rawConfig = JSON.stringify(config); //Keep a backup copy of original config

        config.enabled = (typeof config.enabled === 'boolean') ? config.enabled : DEFAULT_CONFIG.enabled;
        config.logging = (typeof config.logging === 'boolean') ? config.logging : DEFAULT_CONFIG.logging;
        config.maxCacheTTL = 0;

        config.cacheEndpoints = normalizeEndpointPatterns(config.permanentCacheEndpoints, DEFAULT_CONFIG.permanentCacheEndpoints).reduce((res, e) => {res[e] = 0; return res;}, {});
        normalizeEndpointPatterns(config.stepForwardCacheEndpoints, []).forEach((e) => {config.cacheEndpoints[e] = -1;});

        config.cacheCategories = (typeof config.cacheCategories === 'object') ? config.cacheCategories : {};
        Object.keys(config.cacheCategories).forEach((kCat) => {
          let vCat = config.cacheCategories[kCat];
          vCat.ttlInMS = (Number.isInteger(vCat.ttlInMS) && vCat.ttlInMS >= 0) ? vCat.ttlInMS : DEFAULT_CACHE_TTL_MS;
          vCat.endpoints = normalizeEndpointPatterns(vCat.endpoints, []);
          vCat.endpoints.forEach((e) => {
            config.cacheEndpoints[e] = (config.cacheEndpoints[e] && config.cacheEndpoints[e] < vCat.ttlInMS) ? config.cacheEndpoints[e] : vCat.ttlInMS;
          });
          if(vCat.ttlInMS > config.maxCacheTTL) {
            config.maxCacheTTL = vCat.ttlInMS;
          }
        });

        //Remove potential misconfigured endpoints that are never to be cached.
        Object.keys(config.cacheEndpoints).forEach((e) => {
          let kMatch = findMatchingEndpoint(e, DEFAULT_CONFIG.noCacheEndpoints);
          if(!!kMatch) {
            delete config.cacheEndpoints[kMatch];
          }
        });

        //Limit config to only the used keys
        const allowedProperties = ['enabled', 'logging', 'maxCacheTTL', 'cacheEndpoints', '_rawConfig'];
        Object.keys(config).forEach((cKey) => {
          if(!allowedProperties.includes(cKey)) {
            delete config[cKey];
          }
        });

        return getDBConfig()
          .then((oldConfig) => {
            if(oldConfig) {
              config.activatorId = oldConfig.activatorId;
            }
          }).finally(() => replaceDBConfig(config));
      })
      .then(() => clearDBCacheTS())
      .catch((e) => {
        logDebug(`Error ${e} during activation.`);
      })
      .then(() => self.clients.claim())
      .then(() => notifyAppUpdateToClients())
      .then(() => {
        // This auto update detection doesn't work on Firefox(as of 98.0) though, so app html has to have an equivalent code to be run only for Firefox
        self.registration.addEventListener('updatefound', function(e) {
          const sw = e.target.installing || e.target.waiting;

          if(sw.state === 'installed') {
            e.target.active.postMessage('NOTIFY_WAITING');
          }
          sw._d2svSwInstallHandler = () => {
            if(sw.state === 'installed') {
              sw.removeEventListener('statechange', sw._d2svSwInstallHandler);
              e.target.active.postMessage('NOTIFY_WAITING');
            }
          };
          sw.addEventListener('statechange', sw._d2svSwInstallHandler);
        });
      });

    event.waitUntil(promise);
  });

  self.addEventListener('message', (event) => {
    let promise = null;

    if(event.data === 'NOTIFY_WAITING') {
      if((event.source instanceof ServiceWorker && event.source.state === 'activated') || (isFirefox() && event.source instanceof WindowClient)) {
        promise = checkAndNotifyPendingAppUpdateToClients();
      } else {
        logDebug('Discarded notify waiting request due to unrecognized source');
        promise = Promise.reject('unrecognized-source');
      }
    } else if(event.data === 'ACTIVATE_WAITING') {
      promise = getDBConfig()
        .then((config) => {
          config.activatorId = event.source.id;
          return replaceDBConfig(config);
        })
        .catch(() => {})
        .then(() => {
          return getDBClient(event.source.id)
            .catch(() => {})
            .then(dbClient => (!!dbClient ? Promise.reject('not-window-reload') : Promise.resolve()));
        })
        .then(() => self.skipWaiting())
        .catch((e) => {
          logWarn(`Discarded activation request due to ${e}`);
        });
    } else {
      const sender = event.source.id,
        type = event.data.type;

      promise = self.clients.get(sender)
        .then((client) => {
          return getDBConfig()
            .then((config) => Promise.resolve({config: config, client: client}))
            .catch(() => Promise.resolve({config: {}, client: client}));
        })
        .then(({config, client}) => {
          if(type === 'init') {
            return updateDBClient({id: client.id, basePath: event.data.dynamicBasePath})
              .then(() => {
                client.postMessage({
                  type: 'init',
                  clientId: client.id,
                  enabled: config.enabled === true
                });
              })
              .then(() => pruneDataCache());
          } else if(type === 'cache_access_context') {
            if(!!event.data.contextData) {
              return getDBClient(client.id)
                .then((dbClient) => {
                  let contextData = ((typeof event.data.contextData === 'string') ? event.data.contextData : JSON.stringify(event.data.contextData));
                  dbClient.cacheAccessKey = encodeBase64(contextData);
                  return dbClient;
                })
                .then(dbClient => updateDBClient(dbClient));
            } else {
              return Promise.reject('invalid context data');
            }
          } else {
            return Promise.reject(`unrecognozed type ${type}`);
          }
        })
        .catch((e) => {
          logDebug(`[ServiceWorker] Discarded message due to ${e}`);
        })
        .finally(() => {
          pruneDBClients();
        });
    }

    event.waitUntil(promise);
  });

  self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    let waitUntilPromise = beforeEachFetch();
    let logEnabled = false;

    if (url.origin === self.location.origin) {
      if(staticContentsToCache.length && url.pathname.indexOf('/ui') !== -1 && !url.pathname.endsWith('service-worker.js') && (url.pathname.endsWith('ui') || url.pathname.endsWith('ui/') || url.pathname.match(/\.(html|js|json|css|hbs|txt|svg|ttf|woff2|ico)$/i))) {
        const pathName = url.pathname.replace(/\/ui-[^\/]*\//, '/ui/');
        const statPromise = caches.match(pathName)
          .then((cachedResponse) => {
            if(cachedResponse) {
              return cachedResponse;
            }

            return caches.open(CACHE_NAME).then((cache) => {
              return fetch(event.request).then((response) => {
                if(response.status < 400) {
                  return cache.put(pathName, response.clone())
                    .then(() => response);
                } else {
                  return response;
                }
              });
            });
          });

        event.respondWith(statPromise);
      } else if(!url.pathname.match(/\.(html|js|json|css|hbs|txt|svg|ttf|woff2|ico)$/i)) {
        if(event.request.method === 'GET') {
          const dynPromise = getDBConfig()
            .then((config) => (config.enabled === true ? Promise.resolve(config) : Promise.reject('disabled')))
            .then((config) => {
              logEnabled = (config.logging === true);
              return getDBClient(event.clientId)
                .then((client) => {
                  const basePath = !!client ? client.basePath : undefined;
                  if(!basePath || (url.pathname.startsWith(basePath) && url.pathname.indexOf('/ui') === -1)) {
                    const options = {config: config, basePath: basePath};
                    if(!!client && !findMatchingEndpoint(url.pathname, DEFAULT_CONFIG.endpointsUsedBeforeAccessContextSetup)) {
                      options.cacheAccessKey = client.cacheAccessKey;
                    }
                    return Promise.resolve(options);
                  }

                  return Promise.reject('static-url');
                });
            })
            .then((options) => {
              if(event.request.headers.has('authorization')) {
                return Promise.reject('forbidden');
              } else {
                if(findMatchingEndpoint(url.pathname, DEFAULT_CONFIG.noCacheEndpoints)) {
                  return Promise.reject('non-cacheable');
                }
                options.cacheMatchKey = findMatchingEndpoint(url.pathname, options.config.cacheEndpoints);
                if(!options.cacheMatchKey) {
                  return Promise.reject('non-cacheable');
                }
              }

              return Promise.resolve(options);
            })
            .then((options) => {
              return new Promise((res, rej) => {
                const acceptType = event.request.headers.get('accept') || 'default',
                  csrfToken = event.request.headers.get('DOCUMENTUM-CSRF-TOKEN');

                logEnabled && logDebug(`'${event.request.method}' '${acceptType}' ${event.request.url}`);

                const endpointCacheTTL = options.config.cacheEndpoints[options.cacheMatchKey],
                  isContextLessEndpoint = (endpointCacheTTL === 0),
                  skipCache = event.request.headers.has('X-SW-NO-CACHE'),
                  cacheAccessKey = options.cacheAccessKey || csrfToken,
                  qualifiedUrl = ((!options.basePath || isContextLessEndpoint) ? event.request.url : getTokenQualifiedUrl(event.request.url, cacheAccessKey));

                caches.match(qualifiedUrl)
                  .then((cachedResponse) => {
                    if (cachedResponse && skipCache !== true) {
                      const cachedType = cachedResponse.headers.get('content-type').split(';')[0];

                      logEnabled && logDebug(`From cache '${cachedType}' ${event.request.url}`);

                      if((acceptType.indexOf('*/*') !== -1) || (acceptType.indexOf(cachedType) !== -1)) {
                        logEnabled && logDebug(`Serving cached ${event.request.url}`);

                        if(isContextLessEndpoint) {
                          return cachedResponse;
                        }

                        if(endpointCacheTTL > 0) {
                          const currentTS = new Date().getTime();

                          waitUntilPromise = waitUntilPromise
                            .then(() => getDBCacheTS(qualifiedUrl))
                            .then((cacheTS) => {
                              return ((currentTS - cacheTS) < endpointCacheTTL) ? Promise.resolve() :  Promise.reject("expired");
                            })
                            .catch(() => updateCache(event, qualifiedUrl, logEnabled));
                        } else {
                          waitUntilPromise = waitUntilPromise
                            .then(() => updateCache(event, qualifiedUrl, logEnabled));
                        }

                        return cachedResponse;
                      }
                    } else {
                      if(skipCache === true) {
                        logEnabled && logDebug(`Cache skipped ${event.request.url}`);
                      }
                    }

                    logEnabled && logDebug(`Server fetch ${event.request.url}`);
                    return fetchAndCache(event, qualifiedUrl, false, logEnabled);
                  })
                  .then((response) => {
                    res(response);
                  });
              });
            })
            .catch((e) => {
              logEnabled && logDebug(`Passthrough '${event.request.method}' ${url} as '${e}'`);
              return serverFetch(event.request, logEnabled);
            });

          event.respondWith(dynPromise);
        } else if(['POST', 'PUT', 'PATCH', 'DELETE'].includes(event.request.method)){
          waitUntilPromise = waitUntilPromise
            .then(() => getDBConfig())
            .then((config) => (config.enabled === true ? Promise.resolve(config) : Promise.reject('disabled')))
            .then((config) => {
              logEnabled = (config.logging === true);
              if(findMatchingEndpoint(url.pathname, DEFAULT_CONFIG.noCacheEndpoints)) {
                return Promise.reject('non-cacheable');
              }
              let cacheMatchKey = findMatchingEndpoint(url.pathname, config.cacheEndpoints);
              return !!cacheMatchKey ? Promise.resolve({config: config, cacheMatchKey: cacheMatchKey}) : Promise.reject('non-cacheable');
            })
            .then((options) => {
              if(findMatchingEndpoint(url.pathname, DEFAULT_CONFIG.endpointsUsedBeforeAccessContextSetup)) {
                return options;
              }

              return getDBClient(event.clientId)
                .then((client) => {
                  options.cacheAccessKey = !!client ? client.cacheAccessKey : undefined;
                  return options;
                })
                .catch(() => options);
            })
            .then((options) => {
              const csrfToken = event.request.headers.get('DOCUMENTUM-CSRF-TOKEN'),
                isContextLessEndpoint = (options.config.cacheEndpoints[options.cacheMatchKey] === 0),
                cacheAccessKey = options.cacheAccessKey || csrfToken,
                qualifiedUrl = (isContextLessEndpoint ? event.request.url : getTokenQualifiedUrl(event.request.url, cacheAccessKey));

              return caches.open(CACHE_NAME)
                .then((cache) => cache.delete(qualifiedUrl))
                .then((result) => {
                  result && logEnabled && logDebug(`Removed cached ${event.request.url}`);
                });
            })
            .catch(() => {})
            .finally(() => {
              logEnabled && logDebug(`Passthrough '${event.request.method}' ${event.request.url}`);
            });
        }
      }
    }

    event.waitUntil(waitUntilPromise);
  });

  function beforeEachFetch() {
    return Promise.resolve(); //Nothing for now
  }

  function updateCache(fetchEvent, cacheKey, logEnabled) {
    logEnabled && logDebug(`Updating cache ${fetchEvent.request.url}`);
    return fetchAndCache(fetchEvent, cacheKey, true, logEnabled);
  }

  function fetchAndCache(fetchEvent, cacheKey, raiseAuthError, logEnabled) {
    return caches.open(CACHE_NAME).then((cache) => {
      return serverFetch(fetchEvent.request, logEnabled).then((response) => {
        if(response.status < 400) {
          return cache.put(cacheKey, response.clone())
            .then(() => updateDBCacheTS(cacheKey))
            .then(() => response);
        } else if(response.status === 401 && raiseAuthError === true) {
          return notifyClient(fetchEvent.clientId, {type: 'unauthorized'})
            .catch(() => {})
            .finally(() => response);
        } else {
          return response;
        }
      });
    });
  }

  function serverFetch(request, logEnabled=false) {
    return caches.open(CACHE_NAME).then((cache) => {
      return fetch(request).then((response) => {
        if(response.headers.has('X-SW-FLUSH-CACHE')) {
          return cache.matchAll().then((cResponses) => {
            return Promise.all(cResponses.map((cResponse) => {
              if(cResponse.headers.has('X-SW-FLUSH-CACHE')) {
                logEnabled && logDebug(`Flushed cached response for ${cResponse.url}`);
                return cache.delete(cResponse.url, {ignoreSearch: true, ignoreVary: true});
              }

              return Promise.resolve();
            }))
              .then(() => response);
          });
        }

        return response;
      });
    });
  }

  function notifyClient(clientId, message) {
    message = message || {};
    message.clientId = clientId;

    return self.clients.get(clientId)
      .then((client) => {
        client.postMessage(message);
      });
  }

  function checkAndNotifyPendingAppUpdateToClients() {
    if(self.registration.waiting || isFirefox()) { // First(also the only significant) constraint is not compatible with Firefox 98.0, but should be used as soon as a future version starts to support it.
      return self.clients.matchAll().then((clientList) => {
        return Promise.all(clientList.map((client) => {
          return getDBClient(client.id)
            .then((dbClient) => {
              if(!dbClient.appUpdateNotified) {
                return notifyClient(client.id, {type: 'app_update_pending'})
                  .then(() => {
                    dbClient.appUpdateNotified = true;
                    return updateDBClient(dbClient);
                  })
                  .catch(() => {})
                  .finally(() => Promise.resolve());
              } else {
                return Promise.resolve();
              }
            })
            .catch(() => notifyClient(client.id, {type: 'app_update_pending'}));
        }));
      });
    } else {
      return Promise.resolve();
    }
  }

  function notifyAppUpdateToClients() {
    return self.clients.matchAll().then((clientList) => {
      return getDBConfig()
        .then((config) => {
          const activatorId = config.activatorId;
          delete config.activatorId;
          return replaceDBConfig(config).then(() => activatorId, () => activatorId);
        })
        .catch(() => {})
        .then((activatorId) => {
          return Promise.all(clientList.map((client) => {
            return getDBClient(client.id)
              .then((dbClient) => {
                delete dbClient.appUpdateNotified;
                return updateDBClient(dbClient)
                  .finally(() => ((!activatorId || client.id !== activatorId) ? notifyClient(client.id, {type: 'app_update_settled'}) : Promise.resolve()));
              })
              .catch(() => ((!activatorId || client.id !== activatorId) ? notifyClient(client.id, {type: 'app_update_settled'}) : Promise.resolve()));
          }));
        });
    });
  }

  let pruningDataCache = false;
  function pruneDataCache() {
    if(!pruningDataCache) {
      pruningDataCache = true;

      return caches.open(CACHE_NAME)
        .then((cache) => {
          return getAllDBCacheTSKeys()
            .then(cacheKeys => cacheKeys.filter(k => (k.indexOf('xs=') !== -1)))
            .then((cacheKeys) => {
              return getDBConfig()
                .then(config => config.maxCacheTTL || DEFAULT_CACHE_MAX_TTL_MS)
                .then((maxTTL) => {
                  const currTS = new Date().getTime();
                  return Promise.all(cacheKeys.map((cK) => {
                    return getDBCacheTS(cK)
                      .then(cacheTS => (((currTS - cacheTS) >= maxTTL) ? Promise.resolve() : Promise.reject('na')))
                      .then(() => cache.delete(cK).finally(() => removeDBCacheTS(cK)))
                      .catch(() => {});
                  }));
                });
            })
        })
        .finally(() => {
          pruningDataCache = false;
        });
    }

    return Promise.resolve();
  }

  /*************************** DB Utils ***************************/

  let dbPromise; //For faster access to DB when the sw is live for sometime
  function getDB(name, version, upgradeCallback) {
    if(dbPromise) return dbPromise;

    dbPromise = new Promise((resolve, reject) => {
      const oRequest = self.indexedDB.open(name, version);

      oRequest.onsuccess = (e) => {
        resolve(e.target.result);
      };

      oRequest.onerror = (e) => {
        reject(oRequest.error);
      };

      oRequest.onupgradeneeded = (e) => {
        upgradeCallback && upgradeCallback(e.target.result);
      };
    });

    return dbPromise;
  }

  function withDBStore(storeName, opType, storeOpCallback) {
    return new Promise((resolve, reject) => {
      getDB(DB_NAME, DB_VERSION)
        .then((db) => {
          return new Promise((res, rej) => {
            let tx = db.transaction(storeName, opType);
            tx.oncomplete = () => res();
            tx.onerror = () => rej(tx.error);
            storeOpCallback && storeOpCallback(tx.objectStore(storeName));
          });
        })
        .then(() => resolve())
        .catch(reject);
    });
  }

  function updateDBClient(clientData) {
    return withDBStore('clients', 'readwrite', (store) => {
      store.put(clientData);
    });
  }

  function removeDBClient(clientId) {
    return withDBStore('clients', 'readwrite', (store) => {
      store.delete(clientId);
    });
  }

  function getDBClients() {
    return new Promise((res, rej) => {
      let req;
      withDBStore('clients', 'readonly', (store) => {
        req = store.getAll();
      })
        .then(() => res(req.result))
        .catch(rej);
    });
  }

  function getDBClient(clientId) {
    return new Promise((res, rej) => {
      let req;
      withDBStore('clients', 'readonly', (store) => {
        req = store.get(clientId);
      })
        .then(() => res(req.result))
        .catch(rej);
    });
  }

  function getDBClientBasepath(clientId) {
    return getDBClient(clientId)
      .then(client => (client && client.basePath || undefined));
  }

  function pruneDBClients() {
    return self.clients.matchAll()
      .then((clientList) => clientList.map((c) => c.id))
      .then((activeClientIds) => {
        return getDBClients()
          .then((storedClients) => {
            return Promise.all(
              storedClients.map((storedClient) => {
                if(!activeClientIds.includes(storedClient.id)) {
                  return removeDBClient(storedClient.id);
                }
              }))
          })
      });
  }

  function replaceDBConfig(config) {
    return withDBStore('config', 'readwrite', (store) => {
      config = config || {};
      store.put(config, 1);
      dbConfigPromise = undefined; //So that next getDBConfig() gets correct data
    });
  }

  let dbConfigPromise; //For a faster repetitive DB access when the service worker continues to run
  function getDBConfig() {
    if(dbConfigPromise) {
      return dbConfigPromise;
    }

    dbConfigPromise = new Promise((res, rej) => {
      let req;
      withDBStore('config', 'readonly', (store) => {
        req = store.get(1);
      })
        .then(() => res(req.result))
        .catch(() => res({}));
    });

    return dbConfigPromise;
  }

  let dbLTCacheLocal;
  function updateDBLTCacheLocal(key, value) {
    if(!dbLTCacheLocal) {
      dbLTCacheLocal = {};
    }
    dbLTCacheLocal[key] = value;
  }

  function getDBCacheTS(key) {
    if(dbLTCacheLocal && dbLTCacheLocal[key]) {
      return Promise.resolve(dbLTCacheLocal[key]);
    }

    return new Promise((res, rej) => {
      let req;
      withDBStore('lt-cache-stat', 'readonly', (store) => {
        req = store.get(key);
      }).then(() => {
        updateDBLTCacheLocal(key, req.result.ts);
        return res(req.result.ts);
      })
        .catch(() => res(0));
    });
  }

  function updateDBCacheTS(key) {
    const ts = new Date().getTime();
    updateDBLTCacheLocal(key, ts);

    return withDBStore('lt-cache-stat', 'readwrite', (store) => {
      store.put({ts: ts}, key);
    }).catch(() => {})
      .finally(() => Promise.resolve(ts));
  }

  function removeDBCacheTS(key) {
    return withDBStore('lt-cache-stat', 'readwrite', (store) => {
      store.delete(key);
    });
  }

  function clearDBCacheTS() {
    return withDBStore('lt-cache-stat', 'readwrite', (store) => {
      store.clear();
    }).catch(() => {})
      .finally(() => {
        dbLTCacheLocal = {};
      });
  }

  function getAllDBCacheTSKeys() {
    return new Promise((res, rej) => {
      let req;
      withDBStore('lt-cache-stat', 'readonly', (store) => {
        req = store.getAllKeys();
      })
        .then(() => res(req.result))
        .catch(rej);
    });
  }

  /************************** General Utils **************************/

  function getTokenQualifiedUrl(url, tValue) {
    return getQualifiedUrl(url, {xs: tValue});
  }

  function getQualifiedUrl(url, qParams) {
    const qIndex = url.indexOf('?'),
      starter = (qIndex === -1) ? '?' : '&',
      parts = [];

    for(const qParam of Object.keys(qParams)) {
      const part = (qParams[qParam] !== undefined) && (qParams[qParam] !== null) && `${encodeURIComponent(qParam)}=${encodeURIComponent(qParams[qParam])}`;
      part && parts.push(part);
    }

    return parts.length ? `${url}${starter}${parts.join('&')}` : url;
  }

  function findMatchingEndpoint(urlPath, patterns) {
    urlPath = (typeof urlPath === 'string') ? urlPath : '';
    if(urlPath.endsWith('/')) {
      urlPath = urlPath.substr(0, urlPath.length - 1);
    }

    return Object.keys(patterns).find(p => urlPath.match(`${p}$`));
  }

  function normalizeEndpointPatterns(srcList, defaultList) {
    srcList = (Array.isArray(srcList) ? srcList : [])
      .filter(v => (typeof v === 'string' && !v.startsWith('!!') && v.length))
      .map(v => (v.endsWith('$') ? v.substring(0, v.length - 1) : v));

    defaultList.forEach((d) => {
      if(!srcList.includes(d)) {
        srcList.push(d);
      }
    });

    return srcList.filter(v => !!v.length);
  }

  function isFirefox() {
    return navigator && navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
  }

  function to8BitStringFrom16BitString(string16Bit) {
    //Reference https://developer.mozilla.org/en-US/docs/Web/API/btoa
    const codeUnits = new Uint16Array(string16Bit.length);
    for (let i = 0; i < codeUnits.length; i++) {
      codeUnits[i] = string16Bit.charCodeAt(i);
    }
    const charCodes = new Uint8Array(codeUnits.buffer);
    let result = '';
    for (let i = 0; i < charCodes.byteLength; i++) {
      result += String.fromCharCode(charCodes[i]);
    }
    return result;
  }

  function encodeBase64(string16Bit) {
    return btoa(to8BitStringFrom16BitString(string16Bit));
  }

  function logInfo(msg) {
    console.log(`${LOG_PREFIX} ${msg}`);
  }

  function logDebug(msg) {
    console.debug(`${LOG_PREFIX} ${msg}`);
  }

  function logWarn(msg) {
    console.warn(`${LOG_PREFIX} ${msg}`);
  }

  function logError(msg) {
    console.error(`${LOG_PREFIX} ${msg}`);
  }
})();

/* jshint ignore:end */