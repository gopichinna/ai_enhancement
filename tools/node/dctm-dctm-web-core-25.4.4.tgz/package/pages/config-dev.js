(function () {
  'use strict';

  let
    scripts = document.getElementsByTagName('script'),
    scriptExpression = /(\w+)\/nuc\/bundles\/nuc-loader\.js/,
    getScriptMode = function (mode) {
      Array.prototype.slice.call(scripts)
        .some(function (script) {
          var match = scriptExpression.exec(script.src);
          if (match) {
            mode = match[1];
            return mode;
          }
        });
      return mode;
    },
    inferredBuildMode = getScriptMode(),
    buildMode = inferredBuildMode || 'src',
    isRtl = (function(){
      let result = /\brtl(?!:)(?:=([^&]*))?/i.exec(location.search);
      return result && result[1] ? result[1] === 'true' : false
    }());

  // --------------- Customize the configuration ---------------
  window.csui || (window.csui = {});
  window.sv = window.sv || {};
  window.sv.config = window.sv.config || {};
  let config = window.sv.config;

  config.devMode = true;
  config.buildMode = buildMode;
  config.log = {
    level: (function () {
      let result = /\bloglevel(?!:)(?:=([^&]*))?/i.exec(location.search);
      return result && result[1] ? result[1].toUpperCase() : null;
    }()),
    modules: (function () {
      let logLevelModulesRegExp = /\bloglevel:([^=&]+)(?:=([^&]*))?/ig,
        logLevelModules = {}, logLevelModule;
      while ((logLevelModule = logLevelModulesRegExp.exec(location.search)) != null) {
        logLevelModules[decodeURIComponent(logLevelModule[1])] = {
          level: logLevelModule[2] ? logLevelModule[2].toUpperCase() : null
        };
      }
      return logLevelModules;
    }())
  };
  
  if(isRtl) {
    config.i18n = config.i18n || {};
    config.i18n.rtl = true;
  }

}());
