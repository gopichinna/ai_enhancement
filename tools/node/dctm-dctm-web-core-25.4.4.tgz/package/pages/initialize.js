(function () {
  'use strict';
  window.sv = window.sv || {};
  window.sv.init = window.sv.init || {};
  
  let debug = false,
    query = window.location.search;
  if (query) {
    if (query.indexOf('?') === 0) {
      query = query.substring(1);
    }
    let qParams = query.split('&');
    if (qParams) {
      if (qParams.indexOf('debug=true') >= 0) {
        debug = true;
      }
    }
  }

  // Defaults for initialization
  let
    initCfg = window.sv.init,
    appworks = (initCfg.appworks === true),
    appworksFirstLogin = false,
    mobile = appworks || isMobileViewEnabled(),
    embedMode = (initCfg.embedMode === true),
    pluginData = initCfg.pluginData || {},
    releaseLocation = initCfg.baseLocation || '../ui',
    baseLocation = initCfg.baseLocation || (debug ? '../ui-debug' : '../ui'),
    loadableLocales = initCfg.loadableLocales,
    otherBundlesLocation = initCfg.otherBundlesLocation || '',
    cfgLocation = initCfg.cfgLocation || '',
    extraConfig = initCfg.extraConfig || '',
    otdsCallbackPageUrl = initCfg.otdsCallbackPageUrl,
    filesToLoad = initCfg.filesToLoad,
    loadBundles = !filesToLoad,
    launcherJsonLocation = initCfg.launcherJsonLocation || '.',
    commonStartup = function () {
      window.csui.require([
        'dctmw/pages/app/application',
        'nuc/lib/domReady!'
      ], function(Application){
        Application.start({
          embedMode: embedMode,
          appworks: appworks,
          mobile: mobile,
          productInfo: window.sv.config.productInfo
        });
      });
    },

    startup = initCfg.startup || commonStartup;

  delete window.sv.init;

  const selfLocation = getSelfLocation();

  function getSelfLocation() {
    var currentScript = document.currentScript || (function() {
      var scripts = document.getElementsByTagName('script');
      return scripts[scripts.length - 1];
    })();
    if(!currentScript) return;
    var selfPath = currentScript.src;
    var queryStart = selfPath.indexOf('?');
    if (queryStart > 0) {
      selfPath = selfPath.substring(0, queryStart);
    }
    var anchorStart = selfPath.indexOf('#');
    if (anchorStart > 0) {
      selfPath = selfPath.substring(0, anchorStart);
    }
    var lastSlash = selfPath.lastIndexOf('/');
    selfPath = lastSlash > 0 ? selfPath.substring(0, lastSlash) : '.';

    return selfPath;
  }

  // Check whether we are on mobile form factor
  function isMobileViewEnabled() {
    var D2KEY = 'D2',
      appPathName = window.location.pathname.split('/')[1];
    if (localStorage.getItem(D2KEY + ':' + appPathName + ':' + 'mobile')) {
      var mobileStore = JSON.parse(localStorage.getItem(D2KEY + ':' + appPathName + ':' + 'mobile'));
      return mobileStore['mobile_view_enabled'] ? isMobile() : false;
    } else {
      return isMobile();
    }
  }

  function isMobile() {
    if (/Android|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
      var screenOrientation = screen.orientation.type;
      return ((screen.width < 768 && (screenOrientation === 'portrait-primary' || screenOrientation === 'portrait-secondary')) ||
        ((screen.height < 768 && (screenOrientation === 'landscape-primary' || screenOrientation === 'landscape-secondary'))));
    }
    return (/iPhone|iPod/i.test(navigator.userAgent));
  }

  function handleError(error) {
    console.error(error);
    var el = document.createElement('h3'),
      msg = (typeof error === 'string') ? error : 'Failed loading the application. Please contact the administrator.';
    el.className = 'd2-startup-error';
    el.innerHTML = msg.replace('\n', '<br>');
    document.body.appendChild(el);
    document.querySelector('.d2-init-loader-container') && document.querySelector('.d2-init-loader-container').remove();
  }

  // Helper function to fetch file using AJAX
  function loadText(method, url, callback, headers) {
    try {
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
          callback(xhr.responseText);
        }
      };

      xhr.onerror = function error(e) {
        handleError(e);
      };

      xhr.open(method, url, true);
      if(headers) {
        for(var h in headers) {
          if(headers.hasOwnProperty(h)) {
            xhr.setRequestHeader(h, headers[h]);
          }
        }
      }
      xhr.send();
    } catch (e) {
      handleError(e);
    }
  }

  // Helper function to load JS file
  function loadJs({src, queryString}, callback) {
    if(queryString && src.indexOf(queryString) < 0) {
      const u = new URL(src, selfLocation);
      if(u.searchParams.size) {
        src = `${src}&${queryString}`;
      } else {
        src = `${src}?${queryString}`;
      }
    }
    const el = document.createElement('script');
    el.src = src;
    el.type = 'text/javascript';
    if (callback) {
      el.addEventListener('load', callback);
    }
    document.getElementsByTagName("head")[0].appendChild(el);
  }

  // Helper function to load multiple JS files
  function loadJsFiles({baseLocation, filesToLoad, queryString}, callback) {
    function loadJsFile(file) {
      loadJs({src: baseLocation + file, queryString}, function () {
        const next = filesToLoad.shift();
        if (next) {
          loadJsFile(next);
        } else if (callback) {
          callback();
        }
      });
    }

    loadJsFile(filesToLoad.shift());
  }

  function loadLauncher(callback) {
    loadText('GET', selfLocation + `/${launcherJsonLocation}/launcher.json`, (text) => {
      callback(JSON.parse(text));
    });
  }

  // Set default file list (normally only "debug" HTML files set this. In all other cases, we set it here
  if (loadBundles) {
    filesToLoad = [
      otherBundlesLocation + '/nuc/bundles/nuc-loader.js',
      otherBundlesLocation + '/nuc/bundles/nuc-index.js'
    ];
  }

  loadLauncher(function (launchConfig) {
    const
      {version, packages, app_server_url, ...launchConfigExtra} = launchConfig,
      queryString = loadBundles ? `v=${version}` : '';
    
    Object.assign(pluginData, launchConfig.packages || {});

    let cfgBase;
    /*if (!appworks) {
      baseLocation = baseLocation + version;
      releaseLocation = releaseLocation + version;
    }*/

    cfgBase = releaseLocation + cfgLocation;

    // Show spinner
    createLoaderElement();

    // Add favicon
    if (!appworks) {
      const link = document.createElement('link');
      link.type = 'image/vnd.microsoft.icon';
      link.rel = 'icon';
      link.href = cfgBase + '/favicon.ico';
      document.getElementsByTagName('head')[0].appendChild(link);
    }

    loadJsFiles({baseLocation, filesToLoad, queryString}, function () {
      window.sv.config = {
        build: version,
        mobile: mobile,
        appworks: appworks,
        appworksFirstLogin: appworksFirstLogin,
        embedMode: embedMode,
        pluginData: pluginData,
        baseLocation: baseLocation,
        releaseLocation: releaseLocation,
        otherBundlesLocation: otherBundlesLocation,
        otdsCallbackPageUrl: otdsCallbackPageUrl,
        loadableLocales: loadableLocales,
        startup: startup,
        handleError: handleError,
        launchConfig: launchConfigExtra
      };
      
      if(app_server_url) {
        try {
          const u = new URL(app_server_url);
          window.sv.config.connection = {
            url: app_server_url,
            supportPath: '/'
          };
        }catch(e) {
          try {
            const u = new URL(app_server_url, selfLocation);
            window.sv.config.connection = {
              url: app_server_url,
              supportPath: '/'
            };
          }catch(e) {
            console.warn(`Refused app server: ${app_server_url}`);
          }
        }
      }

      if (extraConfig) {
        loadJs({src: `${cfgBase}/${extraConfig}`, queryString}, function () {
          loadMainConfig();
        });
      } else {
        loadMainConfig();
      }

      function loadMainConfig() {
        loadJs({src: `${cfgBase}/config.js`, queryString}, null);
      }
    });

    function createLoaderElement() {
      const loaderEl = document.createElement('div');
      let loaderClass = 'd2-init-loader-container';
      if (mobile) {
        loaderClass += ' d2-mob';
      }
      loaderEl.setAttribute('class', loaderClass);
      //Note: Hiding the loader element here, and showing it in config.js after we find the theme.
      //If this delays the time taken to show the loader, bring the getPreloadCache logic from config.js here,
      //and make use of preloadData to load the previous theme
      loaderEl.style.display = 'none';
      const childEl1 = document.createElement('div');

      childEl1.setAttribute('class', 'd2-init-loader-outer-border');
      loaderEl.appendChild(childEl1);
      
      const childEl2 = document.createElement('div');
      childEl2.setAttribute('class', 'd2-init-loader');
      //BASE64 encoded version of the loader svg from blocker.hbs
      const spinnerSVG = 'PHN2ZyBjbGFzcz0ic3Bpbm5lciBzcGlubmVyLWlubmVyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI3MyIgaGVpZ2h0PSI3MyIgdmlld0JveD0iMCAwIDczIDczIiBmaWxsPSIjRkZGRkZGIiBzdHlsZT0iIj4KICAgICAgICA8cGF0aCBkPSJNMzYuNSA4Ljc5NzUyQzUxLjc4NzQgOC43OTc1MiA2NC4yMDI1IDIxLjIxMjYgNjQuMjAyNSAzNi41QzY0LjIwMjUgNTEuNzg3NCA1MS43ODc0IDY0LjIwMjUgMzYuNSA2NC4yMDI1QzIxLjIxMjYgNjQuMjAyNSA4Ljc5NzUzIDUxLjc4NzQgOC43OTc1MyAzNi41QzguNzk3NTMgMjEuMjEyNiAyMS4yMTI2IDguNzk3NTIgMzYuNSA4Ljc5NzUyWk03Mi41IDM2LjVDNzIuNSAxNi42MyA1Ni4zNyAwLjUgMzYuNSAwLjVDMTYuNjMgMC41IDAuNDk5OTk5IDE2LjYzIDAuNDk5OTk5IDM2LjVDMC40OTk5OTkgNTYuMzcgMTYuNjMgNzIuNSAzNi41IDcyLjVDNTYuMzcgNzIuNSA3Mi41IDU2LjM3IDcyLjUgMzYuNVoiIGZpbGw9IiNGRkZGRiIgc3R5bGU9ImZpbGw6I0ZGRkZGRjtmaWxsOmNvbG9yKGRpc3BsYXktcDMgMC44MTE4IDAuODYyNyAwLjk4ODIpO2ZpbGwtb3BhY2l0eToxO2JhY2tncm91bmQ6IHJlYmVjY2FwdXJwbGU7Ij48L3BhdGg+CiAgICAgICAgPGNsaXBQYXRoIGlkPSJkY3Rtd19pbml0X2xvYWRlciI+CiAgICAgICAgICA8cGF0aCBkPSJNNDAuNjQ4OCA0LjY0ODc2QzQwLjY0ODggMi4zNTc0NiAzOC43OTEzIDAuNSAzNi41IDAuNUMxNi42MyAwLjUgMC41MDAwMDcgMTYuNjMgMC41MDAwMDcgMzYuNUMwLjUwMDAwNyA1Ni4zNyAxNi42MyA3Mi41IDM2LjUgNzIuNUM1Ni4zNyA3Mi41IDcyLjUgNTYuMzcgNzIuNSAzNi41QzcyLjUgMzQuMjA4NyA3MC42NDI1IDMyLjM1MTIgNjguMzUxMiAzMi4zNTEyQzY2LjA1OTkgMzIuMzUxMiA2NC4yMDI1IDM0LjIwODcgNjQuMjAyNSAzNi41QzY0LjIwMjUgNTEuNzg3NCA1MS43ODc0IDY0LjIwMjUgMzYuNSA2NC4yMDI1QzIxLjIxMjYgNjQuMjAyNSA4Ljc5NzUzIDUxLjc4NzQgOC43OTc1MyAzNi41QzguNzk3NTMgMjEuMjEyNiAyMS4yMTI2IDguNzk3NTIgMzYuNSA4Ljc5NzUyQzM4Ljc5MTMgOC43OTc1MiA0MC42NDg4IDYuOTQwMDYgNDAuNjQ4OCA0LjY0ODc2WiIgc3R5bGU9IiI+PC9wYXRoPgogICAgICAgIDwvY2xpcFBhdGg+CiAgICAgICAgPGZvcmVpZ25PYmplY3Qgd2lkdGg9IjczIiBoZWlnaHQ9IjczIiBjbGlwLXBhdGg9InVybCgjZGN0bXdfaW5pdF9sb2FkZXIpIj4KICAgICAgICAgIDxkaXYgY2xhc3M9InNwaW5uZXItZ3JhZGllbnQiPjwvZGl2PgogICAgICAgIDwvZm9yZWlnbk9iamVjdD4KICAgICAgPC9zdmc+';
      childEl2.innerHTML = atob(spinnerSVG);
      childEl1.appendChild(childEl2);
      document.body.appendChild(loaderEl);

      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.type = 'text/css';
      link.href = `${cfgBase}/loader.css${loadBundles ? `?${queryString}` : ''}`;
      document.getElementsByTagName('HEAD')[0].appendChild(link);
    }
  });
})();
