csui.require.config({
bundles: {
  "dctmw/bundles/nls/it/dctmw-all": [
    "dctmw/utils/nls/it/lang",
    "dctmw/overrides/csui/utils/impl/nls/it/lang",
    "dctmw/controls/list/impl/nls/it/lang",
    "dctmw/pages/app/impl/nls/it/lang",
    "dctmw/pages/error/impl/nls/it/lang",
    "dctmw/controls/signin/impl/nls/it/localized.strings",
    "dctmw/pages/signin/impl/nls/it/lang",
    "dctmw/pages/signout/impl/nls/it/lang",
    "dctmw/server.adaptors/models/impl/nls/it/lang",
    "dctmw/utils/icons/impl/nls/it/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/it/lang",
    "dctmw/widgets/favorites/impl/nls/it/lang",
    "dctmw/widgets/favorites/impl/nls/it/favorites.manifest"
  ]
}
});