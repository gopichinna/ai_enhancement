csui.define("dctmw/utils/nls/it/lang", {
  "geolocationDisabledError": "Non si dispone dell'autorizzazione ad accedere. Il browser non � in grado di fornire la posizione dell'utente.\n Per accedere, aggiornare le impostazioni sulla privacy per consentire al sito di accedere alla posizione.",
  "mobileGeolocationDisabledError": "Impossibile accedere. I servizi di localizzazione sono disattivati.\n Per accedere all'applicazione \"D2 mobile\", attivare le impostazioni del localizzazione.",
  "authenticationError": "Autenticazione non riuscita. � stata fornita un'autenticazione dei dati non valida.",
  "InvalidRepositoryId": "Il repository {0} non esiste.",
  "labelBannerDismissButton": "Rifiuta",
  "labelReloadLink": "ricarica",
  "msgUpdateAvailable": "� disponibile un aggiornamento. {0} la pagina per installarlo.",
  "msgUpdateInstalled": "� stato installato un aggiornamento. Ricaricare la pagina per continuare a utilizzare l'applicazione."
});

csui.define("dctmw/overrides/csui/utils/impl/nls/it/lang", {
  "errorContinueSession": "Proseguimento della sessione non riuscito.",
  "errorHttpPrefix": "HTTP"
});

csui.define("dctmw/controls/list/impl/nls/it/lang", {
  "SortableListLastColumnMandatory": "Almeno una colonna deve restare nella griglia",
  "emptyStateMessage": "Nessun elemento"
});

csui.define("dctmw/pages/app/impl/nls/it/lang", {
  "defaultModuleErrorMessage": "Impossibile caricare l'applicazione. Contattare l'amministratore.",
  "errorEmbedModeUnsupported": "La modalit� Embed non � supportata sui dispositivi mobili."
});

csui.define("dctmw/pages/error/impl/nls/it/lang", {
  "reloadLabel": "Ricarica",
  "signOutLabel": "Esci",
  "appLoadingError": "Impossibile caricare l'applicazione. Contattare l'amministratore."
});

csui.define("dctmw/controls/signin/impl/nls/it/localized.strings", {
  "signinButtonText": "Accedi",
  "signinForgotPassword": "Password dimenticata?",
  "signinPlaceholderUsername": "Nome utente",
  "signinPlaceholderPassword": "Password",
  "signinPlaceholderDomain": "Dominio",
  "signinPlaceholderApplication": "Applicazione",
  "signinPlaceholderLocation": "Posizione di rete",
  "signinPlaceholderRepository": "Repository",
  "signinInvalidUsernameOrPassword": "Il nome utente o la password inseriti non sono validi. Riprovare.",
  "signinApplicationSelectionNotAllowedWithoutDefault": "Nessuna selezione dell'applicazione consentita e nessun valore predefinito specificato.",
  "failedRepoConnection": "Impossibile connettersi al repository. Contatta l'amministratore.",
  "haveBeenLoggedOut": "L'utente � stato disconnesso.",
  "closeBrowser": "Chiudere completamente il browser Web per garantire la riservatezza dei dati recentemente visualizzati.",
  "closeMobileBrowser": "Chiudere completamente il browser del dispositivo mobile per garantire la riservatezza dei dati recentemente visualizzati.",
  "loginPage": "Accedere alla pagina di registrazione",
  "repoNotAvailable": "Impossibile recuperare l'elenco degli archivi. Contattare l'amministratore.",
  "defaultApplication": "Valutazione predefinita",
  "applicationFromURL": "Applicazione dall'URL",
  "retryButtonText": "Riprova",
  "ssoUserNotValidForRepository": "Non � presente alcun account relativo all'utente nell'archivio selezionato.",
  "ssoSigninFailed": "",
  "noAccountwithRepo": "Non disponi di un account con il repository",
  "invalidRepoInUrl": "Nome docbase fornito non valido nei parametri. Verificare l'URL.",
  "invalidApplicationInUrl": "Il parametro URL dell'applicazione o il nome dell'applicazione nell'URL non � valido.",
  "mobileHeaderName": "OpenText D2 Mobile CE 23.2"
});

csui.define("dctmw/pages/signin/impl/nls/it/lang", {
  "copyrightMessage": "Copyright © 2023 Open Text. Tutti i diritti riservati. Marchi commerciali di propriet� di Open Text."
});

csui.define("dctmw/pages/signout/impl/nls/it/lang", {
  "signOutLabel": "Esci",
  "message": "Accesso effettuato come <b>{0}</b>"
});

csui.define("dctmw/server.adaptors/models/impl/nls/it/lang", {
  "doclistWidgetUnavailable": "Impossibile accedere al widget Elenco documenti predefinito. Il widget non esiste o utilizza una configurazione non valida oppure non hai il permesso di accedervi.",
  "typeColumnLabel": "Tipo",
  "d2VersionColumnLabel": "Versione",
  "reservedColumnLabel": "Stato",
  "externalShareColumnLabel": "Condividi",
  "favoriteColumnLabel": "Preferito",
  "inlineRowActionsColumnLabel": "Azioni",
  "vdmSequenceColumnLabel": "Sequenza",
  "locationColumnLabel": "Posizione",
  "nodeTypeRepository": "Repository",
  "nodeTypeCabinet": "Archivio",
  "nodeTypeFolder": "Cartella",
  "nodeTypeDocument": "Documento",
  "nodeTypeRendition": "Copia trasformata",
  "nodeTypeTask": "Attivit�",
  "nodeTypeWorkflowStep": "Passaggio flusso di lavoro",
  "nodeTypeDQL": "DQL",
  "nodeTypeFavorites": "Preferiti",
  "nodeTypeObject": "Oggetto",
  "nodeTypeUnreadTask": "Attivit� non letta",
  "nodeTypeReadTask": "Attivit� letta",
  "nodeTypeAcquiredTask": "Attivit� acquisita",
  "nodeTypeDelegatedTask": "Attivit� delegata",
  "nodeTypeRejectedTask": "Attivit� rifiutata",
  "nodeTypeWorkflow": "Flusso di lavoro",
  "advanceSearch": "Ricerca avanzata",
  "advanceSearchForm": "Modulo ricerca avanzata",
  "advanceSearchGroup": "Categoria",
  "queryFormSearch": "Modulo query"
});

csui.define("dctmw/utils/icons/impl/nls/it/localized.strings", {
  "NodeTypeDOC": "Microsoft Word",
  "NodeTypeIRMDOC": "Microsoft Word protetto da IRM",
  "NodeTypeIRMTemplateDOC": "Modello di Microsoft Word protetto da IRM",
  "NodeTypePDF": "Portable Document Format",
  "NodeTypeIRMPDF": "Formato di documento portabile protetto da IRM",
  "NodeTypePPT": "Microsoft Powerpoint",
  "NodeTypePresentation": "Presentazione",
  "NodeTypeXLS": "Microsoft Excel",
  "NodeTypeIRMXLS": "Microsoft Excel protetto da IRM",
  "NodeTypeSpreadsheet": "Foglio di calcolo",
  "NodeTypeFormula": "Formula",
  "NodeTypePublisher": "Microsoft Publisher",
  "NodeTypeVisio": "Microsoft Visio",
  "NodeTypeMPP": "Microsoft Project",
  "NodeTypeONE": "Microsoft OneNote",
  "NodeTypeAccess": "Microsoft Access",
  "NodeTypeAI": "Adobe Illustrator",
  "NodeTypePhotoShop": "Adobe PhotoShop",
  "NodeTypeContentless": "Documento senza contenuti",
  "NodeTypeVirtualDoc": "Documento virtuale",
  "NodeTypeVirtualSnapshot": "Istantanea del documento virtuale",
  "NodeTypeVirtualDocContentless": "Documento virtuale senza contenuti",
  "NodeTypeXLSTemplate": "Modello di Microsoft Excel",
  "NodeTypeXLSIRMTemplate": "Modello di Microsoft Excel protetto da IRM",
  "NodeTypeHTML": "Documento HTML",
  "NodeTypeInfoPath": "Microsoft InfoPath",
  "NodeTypeEmail": "Email",
  "NodeTypeXML": "Documento XML",
  "NodeTypeAudio": "Audio",
  "NodeTypeCompressed": "File compresso",
  "NodeTypeImage": "Immagine",
  "NodeTypeText": "Documento di testo",
  "NodeTypeHtml": "Documento HTML",
  "NodeTypeUnknown": "Sconosciuto",
  "NodeTypeVideo": "Video",
  "NodeTypePPTTemplate": "Modello di Microsoft PowerPoint",
  "NodeTypePPTME": "Microsoft PowerPoint con macro abilitate",
  "NodeTypeCabinet": "Archivio",
  "NodeTypeRepository": "Repository",
  "NodeTypePPTIRM": "Microsoft PowerPoint protetto da IRM",
  "NodeTypePPTIRMTemplate": "Modello Microsoft PowerPoint protetto da IRM",
  "NodeTypeBusinessWorkspace": "Area di lavoro aziendale",
  "NodeTypeFolder": "Cartella",
  "NodeTypeQueryForm": "Modulo query",
  "NodeTypeEmcmf": "Emcmf",
  "NodeTypeEmcmfConverted": "Emcmf Email"
});

csui.define("dctmw/widgets/widgettile/impl/nls/it/lang", {
  "tileTitle": "Widget elenco",
  "expandAria": "Espandi",
  "searchPlaceholder": "Cerca elementi",
  "searchAria": "Cerca elementi",
  "openView": "Apri",
  "emptyListText": "Nessun elemento da visualizzare.",
  "loadingListText": "Caricamento risultati in corso...",
  "failedListText": "Caricamento risultati non riuscito.",
  "zeroResults": "Nessun risultato trovato."
});

csui.define("dctmw/widgets/favorites/impl/nls/it/lang", {
  "dialogTitle": "Preferiti",
  "expandAria": "Apri widget Preferiti",
  "searchPlaceholder": "Cerca preferiti",
  "searchAria": "Cerca preferiti",
  "parent_id": "Posizione",
  "openView": "Apri widget Preferiti"
});

csui.define("dctmw/widgets/favorites/impl/nls/it/favorites.manifest", {
  "title": "Preferiti",
  "description": "Mostra gli oggetti preferiti dell'utente attuale."
});
