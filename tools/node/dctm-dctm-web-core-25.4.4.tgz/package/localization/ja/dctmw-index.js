csui.require.config({
bundles: {
  "dctmw/bundles/nls/ja/dctmw-all": [
    "dctmw/utils/nls/ja/lang",
    "dctmw/overrides/csui/utils/impl/nls/ja/lang",
    "dctmw/controls/list/impl/nls/ja/lang",
    "dctmw/pages/app/impl/nls/ja/lang",
    "dctmw/pages/error/impl/nls/ja/lang",
    "dctmw/controls/signin/impl/nls/ja/localized.strings",
    "dctmw/pages/signin/impl/nls/ja/lang",
    "dctmw/pages/signout/impl/nls/ja/lang",
    "dctmw/server.adaptors/models/impl/nls/ja/lang",
    "dctmw/utils/icons/impl/nls/ja/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/ja/lang",
    "dctmw/widgets/favorites/impl/nls/ja/lang",
    "dctmw/widgets/favorites/impl/nls/ja/favorites.manifest"
  ]
}
});