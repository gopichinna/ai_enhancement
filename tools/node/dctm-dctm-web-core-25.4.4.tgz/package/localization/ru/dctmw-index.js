csui.require.config({
bundles: {
  "dctmw/bundles/nls/ru/dctmw-all": [
    "dctmw/utils/nls/ru/lang",
    "dctmw/overrides/csui/utils/impl/nls/ru/lang",
    "dctmw/controls/list/impl/nls/ru/lang",
    "dctmw/pages/app/impl/nls/ru/lang",
    "dctmw/pages/error/impl/nls/ru/lang",
    "dctmw/controls/signin/impl/nls/ru/localized.strings",
    "dctmw/pages/signin/impl/nls/ru/lang",
    "dctmw/pages/signout/impl/nls/ru/lang",
    "dctmw/server.adaptors/models/impl/nls/ru/lang",
    "dctmw/utils/icons/impl/nls/ru/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/ru/lang",
    "dctmw/widgets/favorites/impl/nls/ru/lang",
    "dctmw/widgets/favorites/impl/nls/ru/favorites.manifest"
  ]
}
});