csui.define("dctmw/utils/nls/fr/lang", {
  "geolocationDisabledError": "Vous n'�tes pas autoris� � vous connecter, car le navigateur n'est pas en mesure de fournir votre emplacement.\n Pour pouvoir vous connecter, vous devez mettre � jour vos param�tres de confidentialit� pour permettre l'acc�s de ce site � votre emplacement.",
  "mobileGeolocationDisabledError": "Vous n'�tes pas autoris� � vous connecter, car les services li�s � l'emplacement sont d�sactiv�s.\n Pour pouvoir vous connecter � l'application ��D2 mobile��, vous devez mettre � jour vos param�tres d'emplacement.",
  "authenticationError": "�chec de l'authentification. Les donn�es d'authentification fournies ne sont pas valides.",
  "InvalidRepositoryId": "Le r�f�rentiel {0} n'existe pas.",
  "labelBannerDismissButton": "Rejeter",
  "labelReloadLink": "recharger",
  "msgUpdateAvailable": "Une mise � jour est disponible, {0} la page pour l'installer.",
  "msgUpdateInstalled": "Une mise � jour a �t� install�e, rechargez la page pour continuer � utiliser l'application."
});

csui.define("dctmw/overrides/csui/utils/impl/nls/fr/lang", {
  "errorContinueSession": "�chec de la poursuite de la session.",
  "errorHttpPrefix": "HTTP"
});

csui.define("dctmw/controls/list/impl/nls/fr/lang", {
  "SortableListLastColumnMandatory": "Au moins une colonne doit rester dans la grille",
  "emptyStateMessage": "Aucun �l�ment"
});

csui.define("dctmw/pages/app/impl/nls/fr/lang", {
  "defaultModuleErrorMessage": "�chec de chargement de l'application. Veuillez contacter l'administrateur.",
  "errorEmbedModeUnsupported": "Le mode Embed n'est pas pris en charge sur les appareils mobiles."
});

csui.define("dctmw/pages/error/impl/nls/fr/lang", {
  "reloadLabel": "Recharger",
  "signOutLabel": "Se d�connecter",
  "appLoadingError": "�chec de chargement de l'application. Veuillez contacter l'administrateur."
});

csui.define("dctmw/controls/signin/impl/nls/fr/localized.strings", {
  "signinButtonText": "Connexion",
  "signinForgotPassword": "Mot de passe oubli�?",
  "signinPlaceholderUsername": "Nom d'utilisateur",
  "signinPlaceholderPassword": "Mot de passe",
  "signinPlaceholderDomain": "Domaine",
  "signinPlaceholderApplication": "Application",
  "signinPlaceholderLocation": "Emplacement r�seau",
  "signinPlaceholderRepository": "R�f�rentiel",
  "signinInvalidUsernameOrPassword": "Le nom ou le mot de passe entr� n'est pas correct. Veuillez r�essayer.",
  "signinApplicationSelectionNotAllowedWithoutDefault": "Aucune s�lection d'application n'est autoris�e et aucune valeur par d�faut n'est sp�cifi�e.",
  "failedRepoConnection": "�chec de connexion au r�f�rentiel. Veuillez contacter l'administrateur.",
  "haveBeenLoggedOut": "Vous avez �t� d�connect�.",
  "closeBrowser": "Fermez compl�tement votre navigateur pour garantir la confidentialit� des donn�es r�cemment consult�es.",
  "closeMobileBrowser": "Fermez compl�tement votre navigateur mobile pour garantir la confidentialit� des donn�es r�cemment consult�es.",
  "loginPage": "Acc�der � la page de connexion",
  "repoNotAvailable": "La liste de r�f�rentiels n'a pas pu �tre r�cup�r�e. Veuillez contacter l'administrateur.",
  "defaultApplication": "Application par d�faut",
  "applicationFromURL": "Application � partir de l'URL",
  "retryButtonText": "R�essayer",
  "ssoUserNotValidForRepository": "Aucun compte utilisateur n'est disponible pour vous dans le r�f�rentiel s�lectionn�.",
  "ssoSigninFailed": "",
  "noAccountwithRepo": "Vous ne disposez d'aucun compte aupr�s du r�f�rentiel",
  "invalidRepoInUrl": "Nom de la base de documents fourni dans les param�tres non valide. Veuillez v�rifier l'URL.",
  "invalidApplicationInUrl": "Le param�tre d'URL de l'application ou le nom de l'application dans l'URL n'est pas valide.",
  "mobileHeaderName": "OpenText D2 Mobile CE 23.2"
});

csui.define("dctmw/pages/signin/impl/nls/fr/lang", {
  "copyrightMessage": "Copyright � 2023 Open Text. Tous droits r�serv�s. Les marques commerciales sont la propri�t� d'Open Text."
});

csui.define("dctmw/pages/signout/impl/nls/fr/lang", {
  "signOutLabel": "Se d�connecter",
  "message": "Connect� en tant que <b>{0}</b>"
});

csui.define("dctmw/server.adaptors/models/impl/nls/fr/lang", {
  "doclistWidgetUnavailable": "Le widget Liste de documents par d�faut est inaccessible. Soit il n'existe pas, soit vous ne disposez pas des autorisations n�cessaires pour y acc�der, soit sa configuration est incorrecte.",
  "typeColumnLabel": "Type",
  "d2VersionColumnLabel": "Version",
  "reservedColumnLabel": "�tat",
  "externalShareColumnLabel": "Partager",
  "favoriteColumnLabel": "Favori",
  "inlineRowActionsColumnLabel": "Actions",
  "vdmSequenceColumnLabel": "S�quence",
  "locationColumnLabel": "Emplacement",
  "nodeTypeRepository": "R�f�rentiel",
  "nodeTypeCabinet": "Armoire",
  "nodeTypeFolder": "Dossier",
  "nodeTypeDocument": "Document",
  "nodeTypeRendition": "Format",
  "nodeTypeTask": "T�che",
  "nodeTypeWorkflowStep": "�tape du workflow",
  "nodeTypeDQL": "DQL",
  "nodeTypeFavorites": "Favoris",
  "nodeTypeObject": "Objet",
  "nodeTypeUnreadTask": "T�che non lue",
  "nodeTypeReadTask": "T�che lue",
  "nodeTypeAcquiredTask": "T�che acquise",
  "nodeTypeDelegatedTask": "T�che d�l�gu�e",
  "nodeTypeRejectedTask": "T�che rejet�e",
  "nodeTypeWorkflow": "Workflow",
  "advanceSearch": "Recherche avanc�e",
  "advanceSearchForm": "Formulaire de recherche avanc�e",
  "advanceSearchGroup": "Cat�gorie",
  "queryFormSearch": "Formulaire de requ�te"
});

csui.define("dctmw/utils/icons/impl/nls/fr/localized.strings", {
  "NodeTypeDOC": "Microsoft Word",
  "NodeTypeIRMDOC": "Document Microsoft Word prot�g� par IRM",
  "NodeTypeIRMTemplateDOC": "Mod�le Microsoft Word prot�g� par IRM",
  "NodeTypePDF": "Format de document portable",
  "NodeTypeIRMPDF": "Document Portable Document Format prot�g� par IRM",
  "NodeTypePPT": "Microsoft Powerpoint",
  "NodeTypePresentation": "Pr�sentation",
  "NodeTypeXLS": "Microsoft Excel",
  "NodeTypeIRMXLS": "Document Microsoft Excel prot�g� par IRM",
  "NodeTypeSpreadsheet": "Feuille de calcul",
  "NodeTypeFormula": "Formule",
  "NodeTypePublisher": "Microsoft Publisher",
  "NodeTypeVisio": "Microsoft Visio",
  "NodeTypeMPP": "Microsoft Project",
  "NodeTypeONE": "Microsoft OneNote",
  "NodeTypeAccess": "Microsoft Access",
  "NodeTypeAI": "Adobe Illustrator",
  "NodeTypePhotoShop": "Adobe PhotoShop",
  "NodeTypeContentless": "Document sans contenu",
  "NodeTypeVirtualDoc": "Document virtuel",
  "NodeTypeVirtualSnapshot": "Instantan� de document virtuel",
  "NodeTypeVirtualDocContentless": "Document virtuel sans contenu",
  "NodeTypeXLSTemplate": "Mod�le Microsoft Excel",
  "NodeTypeXLSIRMTemplate": "Mod�le Microsoft Excel prot�g� par IRM",
  "NodeTypeHTML": "Document HTML",
  "NodeTypeInfoPath": "Microsoft InfoPath",
  "NodeTypeEmail": "E-mail",
  "NodeTypeXML": "Document XML",
  "NodeTypeAudio": "Audio",
  "NodeTypeCompressed": "Fichier compress�",
  "NodeTypeImage": "Image",
  "NodeTypeText": "Document de texte",
  "NodeTypeHtml": "Document HTML",
  "NodeTypeUnknown": "Inconnu",
  "NodeTypeVideo": "Vid�o",
  "NodeTypePPTTemplate": "Mod�le Microsoft Powerpoint",
  "NodeTypePPTME": "Macro Microsoft Powerpoint activ�e",
  "NodeTypeCabinet": "Armoire",
  "NodeTypeRepository": "R�f�rentiel",
  "NodeTypePPTIRM": "Document Microsoft Powerpoint prot�g� par IRM",
  "NodeTypePPTIRMTemplate": "Mod�le Microsoft Powerpoint prot�g� par IRM",
  "NodeTypeBusinessWorkspace": "Espace de travail professionnel",
  "NodeTypeFolder": "Dossier",
  "NodeTypeQueryForm": "Formulaire de requ�te",
  "NodeTypeEmcmf": "Emcmf",
  "NodeTypeEmcmfConverted": "E-mail Emcmf"
});

csui.define("dctmw/widgets/widgettile/impl/nls/fr/lang", {
  "tileTitle": "Widget de liste",
  "expandAria": "�tendre",
  "searchPlaceholder": "Rechercher des �l�ments",
  "searchAria": "Rechercher des �l�ments",
  "openView": "Ouvrir",
  "emptyListText": "Aucun �l�ment � afficher.",
  "loadingListText": "Chargement des r�sultats en cours...",
  "failedListText": "�chec du chargement des r�sultats.",
  "zeroResults": "Aucun r�sultat."
});

csui.define("dctmw/widgets/favorites/impl/nls/fr/lang", {
  "dialogTitle": "Favoris",
  "expandAria": "Ouvrir le widget Favoris",
  "searchPlaceholder": "Rechercher les favoris",
  "searchAria": "Rechercher les favoris",
  "parent_id": "Emplacement",
  "openView": "Ouvrir le widget Favoris"
});

csui.define("dctmw/widgets/favorites/impl/nls/fr/favorites.manifest", {
  "title": "Favoris",
  "description": "Affiche les objets favoris de l'utilisateur actuel."
});
