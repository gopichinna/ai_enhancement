csui.require.config({
bundles: {
  "dctmw/bundles/nls/fr/dctmw-all": [
    "dctmw/utils/nls/fr/lang",
    "dctmw/overrides/csui/utils/impl/nls/fr/lang",
    "dctmw/controls/list/impl/nls/fr/lang",
    "dctmw/pages/app/impl/nls/fr/lang",
    "dctmw/pages/error/impl/nls/fr/lang",
    "dctmw/controls/signin/impl/nls/fr/localized.strings",
    "dctmw/pages/signin/impl/nls/fr/lang",
    "dctmw/pages/signout/impl/nls/fr/lang",
    "dctmw/server.adaptors/models/impl/nls/fr/lang",
    "dctmw/utils/icons/impl/nls/fr/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/fr/lang",
    "dctmw/widgets/favorites/impl/nls/fr/lang",
    "dctmw/widgets/favorites/impl/nls/fr/favorites.manifest"
  ]
}
});