csui.require.config({
bundles: {
  "dctmw/bundles/nls/nl/dctmw-all": [
    "dctmw/utils/nls/nl/lang",
    "dctmw/overrides/csui/utils/impl/nls/nl/lang",
    "dctmw/controls/list/impl/nls/nl/lang",
    "dctmw/pages/app/impl/nls/nl/lang",
    "dctmw/pages/error/impl/nls/nl/lang",
    "dctmw/controls/signin/impl/nls/nl/localized.strings",
    "dctmw/pages/signin/impl/nls/nl/lang",
    "dctmw/pages/signout/impl/nls/nl/lang",
    "dctmw/server.adaptors/models/impl/nls/nl/lang",
    "dctmw/utils/icons/impl/nls/nl/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/nl/lang",
    "dctmw/widgets/favorites/impl/nls/nl/lang",
    "dctmw/widgets/favorites/impl/nls/nl/favorites.manifest"
  ]
}
});