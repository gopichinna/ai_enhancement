csui.define("dctmw/utils/nls/nl/lang", {
  "geolocationDisabledError": "U hebt geen toestemming om zich aan te melden omdat de browser uw locatie niet kan vinden.\n Werk uw privacyinstellingen bij om locatietoegang voor deze site toe te staan en meld u vervolgens aan.",
  "mobileGeolocationDisabledError": "U kunt zich niet aanmelden, omdat de locatieservices uitgeschakeld zijn.\n Schakel de locatie-instellingen in zodat u zich kunt aanmelden bij de toepassing \"D2 mobile\".",
  "authenticationError": "Authenticatie mislukt. Ongeldige verificatiegegevens opgegeven.",
  "InvalidRepositoryId": "De opslagplaats {0} bestaat niet.",
  "labelBannerDismissButton": "Verwerpen",
  "labelReloadLink": "Herlaad",
  "msgUpdateAvailable": "Er is een update beschikbaar. {0} de pagina om deze te installeren.",
  "msgUpdateInstalled": "Er is een update ge�nstalleerd. Herlaad de pagina om de toepassing te blijven gebruiken."
});

csui.define("dctmw/overrides/csui/utils/impl/nls/nl/lang", {
  "errorContinueSession": "Doorgaan met de sessie is mislukt.",
  "errorHttpPrefix": "HTTP"
});

csui.define("dctmw/controls/list/impl/nls/nl/lang", {
  "SortableListLastColumnMandatory": "Het raster moet minimaal ��n kolom bevatten",
  "emptyStateMessage": "Geen items"
});

csui.define("dctmw/pages/app/impl/nls/nl/lang", {
  "defaultModuleErrorMessage": "Laden van de toepassing is mislukt. Neem contact op met de beheerder.",
  "errorEmbedModeUnsupported": "Modus Embed wordt niet ondersteund op mobiele apparaten."
});

csui.define("dctmw/pages/error/impl/nls/nl/lang", {
  "reloadLabel": "Opnieuw laden",
  "signOutLabel": "Uitloggen",
  "appLoadingError": "Laden van de toepassing is mislukt. Neem contact op met de beheerder."
});

csui.define("dctmw/controls/signin/impl/nls/nl/localized.strings", {
  "signinButtonText": "Aanmelden",
  "signinForgotPassword": "Wachtwoord vergeten?",
  "signinPlaceholderUsername": "Gebruikersnaam",
  "signinPlaceholderPassword": "Wachtwoord",
  "signinPlaceholderDomain": "Domein",
  "signinPlaceholderApplication": "Toepassing",
  "signinPlaceholderLocation": "Netwerklocatie",
  "signinPlaceholderRepository": "Opslagplaats",
  "signinInvalidUsernameOrPassword": "U hebt een ongeldige gebruikersnaam of een ongeldig wachtwoord ingevoerd. Probeer het nogmaals.",
  "signinApplicationSelectionNotAllowedWithoutDefault": "Er mag geen toepassing worden geselecteerd en er is geen standaardwaarde opgegeven.",
  "failedRepoConnection": "Verbinding maken met de opslagplaats is mislukt. Neem contact op met de beheerder.",
  "haveBeenLoggedOut": "U bent afgemeld.",
  "closeBrowser": "Sluit uw webbrowser volledig af om de privacy van onlangs bekeken gegevens te garanderen.",
  "closeMobileBrowser": "Sluit uw webbrowser volledig af om de privacy van onlangs bekeken gegevens te garanderen.",
  "loginPage": "Ga naar de pagina Aanmelden",
  "repoNotAvailable": "De lijst met opslagplaatsen is niet opgehaald. Neem contact op met de beheerder.",
  "defaultApplication": "Standaard toepassing",
  "applicationFromURL": "Toepassing van URL",
  "retryButtonText": "Opnieuw proberen",
  "ssoUserNotValidForRepository": "De geselecteerde opslagplaats bevat geen gebruikersaccount voor u.",
  "ssoSigninFailed": "",
  "noAccountwithRepo": "U hebt geen account voor de opslagplaats",
  "invalidRepoInUrl": "Ongeldige docbase-naam in de parameters. Controleer de URL.",
  "invalidApplicationInUrl": "Ongeldige URL-parameter of toepassingsnaam in de URL.",
  "mobileHeaderName": "OpenText D2 Mobile CE 23.2"
});

csui.define("dctmw/pages/signin/impl/nls/nl/lang", {
  "copyrightMessage": "Copyright © 2023 Open Text. All rights reserved. Trademarks owned by Open Text."
});

csui.define("dctmw/pages/signout/impl/nls/nl/lang", {
  "signOutLabel": "Uitloggen",
  "message": "Ingelogd als <b>{0}</b>"
});

csui.define("dctmw/server.adaptors/models/impl/nls/nl/lang", {
  "doclistWidgetUnavailable": "De widget Standaarddocumentlijst kan niet worden geopend. Deze bestaat niet, u bent niet gemachtigd deze te openen of deze heeft een ongeldige configuratie.",
  "typeColumnLabel": "Type",
  "d2VersionColumnLabel": "Versie",
  "reservedColumnLabel": "Status",
  "externalShareColumnLabel": "Delen",
  "favoriteColumnLabel": "Favoriet",
  "inlineRowActionsColumnLabel": "Acties",
  "vdmSequenceColumnLabel": "Reeks",
  "locationColumnLabel": "Locatie",
  "nodeTypeRepository": "Opslagplaats",
  "nodeTypeCabinet": "Cabinet",
  "nodeTypeFolder": "Map",
  "nodeTypeDocument": "Document",
  "nodeTypeRendition": "Renditie",
  "nodeTypeTask": "Taak",
  "nodeTypeWorkflowStep": "Werkstroomstap",
  "nodeTypeDQL": "DQL",
  "nodeTypeFavorites": "Favorieten",
  "nodeTypeObject": "Object",
  "nodeTypeUnreadTask": "Ongelezen taak",
  "nodeTypeReadTask": "Gelezen taak",
  "nodeTypeAcquiredTask": "Verkregen taak",
  "nodeTypeDelegatedTask": "Gedelegeerde taak",
  "nodeTypeRejectedTask": "Afgewezen taak",
  "nodeTypeWorkflow": "Workflow",
  "advanceSearch": "Geavanceerd zoeken",
  "advanceSearchForm": "Geavanceerd zoekformulier",
  "advanceSearchGroup": "Categorie",
  "queryFormSearch": "Queryformulier"
});

csui.define("dctmw/utils/icons/impl/nls/nl/localized.strings", {
  "NodeTypeDOC": "Microsoft Word",
  "NodeTypeIRMDOC": "IRM-beveiligde Microsoft Word",
  "NodeTypeIRMTemplateDOC": "IRM-beveiligde Microsoft Word-sjabloon",
  "NodeTypePDF": "Portable Document Format",
  "NodeTypeIRMPDF": "IRM-beveiligde pdf",
  "NodeTypePPT": "Microsoft Powerpoint",
  "NodeTypePresentation": "Presentatie",
  "NodeTypeXLS": "Microsoft Excel",
  "NodeTypeIRMXLS": "IRM-beveiligde Microsoft Excel",
  "NodeTypeSpreadsheet": "Spreadsheet",
  "NodeTypeFormula": "Formule",
  "NodeTypePublisher": "Microsoft Publisher",
  "NodeTypeVisio": "Microsoft Visio",
  "NodeTypeMPP": "Microsoft Project",
  "NodeTypeONE": "Microsoft OneNote",
  "NodeTypeAccess": "Microsoft Access",
  "NodeTypeAI": "Adobe Illustrator",
  "NodeTypePhotoShop": "Adobe PhotoShop",
  "NodeTypeContentless": "Document zonder inhoud",
  "NodeTypeVirtualDoc": "Virtueel document",
  "NodeTypeVirtualSnapshot": "Momentopname van virtueel document",
  "NodeTypeVirtualDocContentless": "Inhoudsloos virtueel document",
  "NodeTypeXLSTemplate": "Microsoft Excel-sjabloon",
  "NodeTypeXLSIRMTemplate": "IRM-beveiligde Microsoft Excel-sjabloon",
  "NodeTypeHTML": "HTML-document",
  "NodeTypeInfoPath": "Microsoft InfoPath",
  "NodeTypeEmail": "E-mail",
  "NodeTypeXML": "XML-document",
  "NodeTypeAudio": "Audio",
  "NodeTypeCompressed": "Gecomprimeerd bestand",
  "NodeTypeImage": "Afbeelding",
  "NodeTypeText": "Tekstdocument",
  "NodeTypeHtml": "Html-document",
  "NodeTypeUnknown": "Onbekend",
  "NodeTypeVideo": "Video",
  "NodeTypePPTTemplate": "Microsoft PowerPoint-sjabloon",
  "NodeTypePPTME": "Microsoft PowerPoint macro's ingeschakeld",
  "NodeTypeCabinet": "Cabinet",
  "NodeTypeRepository": "Opslagplaats",
  "NodeTypePPTIRM": "IRM-beveiligde Microsoft PowerPoint",
  "NodeTypePPTIRMTemplate": "IRM-beveiligde Microsoft PowerPoint-sjabloon",
  "NodeTypeBusinessWorkspace": "Bedrijfswerkruimte",
  "NodeTypeFolder": "Map",
  "NodeTypeQueryForm": "Queryformulier",
  "NodeTypeEmcmf": "Emcmf",
  "NodeTypeEmcmfConverted": "Emcmf e-mail"
});

csui.define("dctmw/widgets/widgettile/impl/nls/nl/lang", {
  "tileTitle": "Widget weergeven",
  "expandAria": "Uitvouwen",
  "searchPlaceholder": "Items zoeken",
  "searchAria": "Zoeken naar items",
  "openView": "Openen",
  "emptyListText": "Er zijn geen items om weer te geven.",
  "loadingListText": "Resultaten laden...",
  "failedListText": "Het laden van de resultaten is mislukt.",
  "zeroResults": "Geen resultaten gevonden."
});

csui.define("dctmw/widgets/favorites/impl/nls/nl/lang", {
  "dialogTitle": "Favorieten",
  "expandAria": "Widget Favorieten openen",
  "searchPlaceholder": "Favorieten zoeken",
  "searchAria": "Favorieten zoeken",
  "parent_id": "Locatie",
  "openView": "Widget Favorieten openen"
});

csui.define("dctmw/widgets/favorites/impl/nls/nl/favorites.manifest", {
  "title": "Favorieten",
  "description": "Geeft favoriete objecten van de huidige gebruiker weer."
});
