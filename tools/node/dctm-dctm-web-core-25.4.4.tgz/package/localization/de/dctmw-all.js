csui.define("dctmw/utils/nls/de/lang", {
  "geolocationDisabledError": "Sie sind nicht berechtigt, sich anzumelden, da der Browser Ihren Standort nicht feststellen kann.\n Um sich anzumelden, aktualisieren Sie bitte Ihre Privatsph�re-Einstellungen, um dieser Seite einen Standortzugriff zu erlauben.",
  "mobileGeolocationDisabledError": "Sie k�nnen sich nicht anmelden, da die Standortdienste deaktiviert sind.\n F�r eine Anmeldung in der \"D2 mobile\" Anwendung aktivieren Sie bitte die Standorteinstellungen.",
  "authenticationError": "Die Authentifizierung ist fehlgeschlagen. Es wurden ung�ltige Authentifizierungsdaten bereitgestellt.",
  "InvalidRepositoryId": "Repository {0} ist nicht vorhanden.",
  "labelBannerDismissButton": "Ausblenden",
  "labelReloadLink": "neu laden",
  "msgUpdateAvailable": "Es ist eine Aktualisierung verf�gbar, Seite {0}, um sie zu installieren.",
  "msgUpdateInstalled": "Es wurde eine Aktualisierung installiert, laden Sie die Seite neu, um die Anwendung weiterhin zu verwenden."
});

csui.define("dctmw/overrides/csui/utils/impl/nls/de/lang", {
  "errorContinueSession": "Fortsetzen der Sitzung ist fehlgeschlagen.",
  "errorHttpPrefix": "HTTP"
});

csui.define("dctmw/controls/list/impl/nls/de/lang", {
  "SortableListLastColumnMandatory": "Mindestens eine Spalte muss im Raster verbleiben",
  "emptyStateMessage": "Keine Objekte"
});

csui.define("dctmw/pages/app/impl/nls/de/lang", {
  "defaultModuleErrorMessage": "Laden der Anwendung fehlgeschlagen. Bitte wenden Sie sich an den Administrator.",
  "errorEmbedModeUnsupported": "Der Embed-Modus wird auf Mobilger�ten nicht unterst�tzt."
});

csui.define("dctmw/pages/error/impl/nls/de/lang", {
  "reloadLabel": "Neu laden",
  "signOutLabel": "Abmelden",
  "appLoadingError": "Laden der Anwendung fehlgeschlagen. Bitte wenden Sie sich an den Administrator."
});

csui.define("dctmw/controls/signin/impl/nls/de/localized.strings", {
  "signinButtonText": "Anmelden",
  "signinForgotPassword": "Kennwort vergessen?",
  "signinPlaceholderUsername": "Benutzername",
  "signinPlaceholderPassword": "Kennwort",
  "signinPlaceholderDomain": "Dom�ne",
  "signinPlaceholderApplication": "Anwendung",
  "signinPlaceholderLocation": "Netzwerkstandort",
  "signinPlaceholderRepository": "Repository",
  "signinInvalidUsernameOrPassword": "Der eingegebene Benutzername oder das Kennwort ist ung�ltig. Versuchen Sie es erneut.",
  "signinApplicationSelectionNotAllowedWithoutDefault": "Keine Anwendungsauswahl gestattet und kein Standardwert angegeben.",
  "failedRepoConnection": "Verbindung zum Repository ist fehlgeschlagen. Wenden Sie sich an den Administrator.",
  "haveBeenLoggedOut": "Sie wurden abgemeldet.",
  "closeBrowser": "Schlie�en Sie Ihren Browser vollst�ndig, um den Schutz k�rzlich angezeigter Daten zu gew�hrleisten.",
  "closeMobileBrowser": "Schlie�en Sie Ihren Browser vollst�ndig, um den Schutz k�rzlich angezeigter Daten zu gew�hrleisten.",
  "loginPage": "Zur Anmeldeseite",
  "repoNotAvailable": "Repository-Liste konnte nicht abgerufen werden. Wenden Sie sich an Ihren Administrator.",
  "defaultApplication": "Standardanwendung",
  "applicationFromURL": "Anwendung �ber URL",
  "retryButtonText": "Wiederholen",
  "ssoUserNotValidForRepository": "Im ausgew�hlten Repository ist keine Benutzerkonto f�r Sie verf�gbar.",
  "ssoSigninFailed": "",
  "noAccountwithRepo": "Sie haben kein Konto mit dem Repository",
  "invalidRepoInUrl": "Ung�ltiger Docbase-Name in Parametern angegeben. Bitte URL �berpr�fen.",
  "invalidApplicationInUrl": "Ung�ltiger Anwendungs-URL-Parameter oder Anwendungsname in der URL.",
  "mobileHeaderName": "OpenText D2 Mobile CE 23.2"
});

csui.define("dctmw/pages/signin/impl/nls/de/lang", {
  "copyrightMessage": "Copyright � 2023 Open Text. Alle Rechte vorbehalten. Marken sind Eigentum von Open Text."
});

csui.define("dctmw/pages/signout/impl/nls/de/lang", {
  "signOutLabel": "Abmelden",
  "message": "Angemeldet als <b>{0}</b>"
});

csui.define("dctmw/server.adaptors/models/impl/nls/de/lang", {
  "doclistWidgetUnavailable": "Der Zugriff auf das Widget 'Standard-Doclist' ist nicht m�glich. Entweder ist es nicht vorhanden oder Sie haben keine Berechtigung f�r den Zugriff oder es verf�gt �ber eine ung�ltige Konfiguration.",
  "typeColumnLabel": "Typ",
  "d2VersionColumnLabel": "Version",
  "reservedColumnLabel": "Status",
  "externalShareColumnLabel": "Freigeben",
  "favoriteColumnLabel": "Favorit",
  "inlineRowActionsColumnLabel": "Aktionen",
  "vdmSequenceColumnLabel": "Reihenfolge",
  "locationColumnLabel": "Speicherort",
  "nodeTypeRepository": "Repository",
  "nodeTypeCabinet": "Ablage",
  "nodeTypeFolder": "Ordner",
  "nodeTypeDocument": "Dokument",
  "nodeTypeRendition": "Formatvariante",
  "nodeTypeTask": "Aufgabe",
  "nodeTypeWorkflowStep": "Workflow-Schritt",
  "nodeTypeDQL": "DQL",
  "nodeTypeFavorites": "Favoriten",
  "nodeTypeObject": "Objekt",
  "nodeTypeUnreadTask": "Ungelesen - Aufgabe",
  "nodeTypeReadTask": "Lesen - Aufgabe",
  "nodeTypeAcquiredTask": "Abgerufen - Aufgabe",
  "nodeTypeDelegatedTask": "Delegiert - Aufgabe",
  "nodeTypeRejectedTask": "Abgelehnt - Aufgabe",
  "nodeTypeWorkflow": "Workflow",
  "advanceSearch": "Erweiterte Suche",
  "advanceSearchForm": "Formular f�r die erweiterte Suche",
  "advanceSearchGroup": "Kategorie",
  "queryFormSearch": "Abfrageformular"
});

csui.define("dctmw/utils/icons/impl/nls/de/localized.strings", {
  "NodeTypeDOC": "Microsoft Word",
  "NodeTypeIRMDOC": "Microsoft Word � IRM-gesch�tzt",
  "NodeTypeIRMTemplateDOC": "Microsoft Word-Vorlage � IRM-gesch�tzt",
  "NodeTypePDF": "Portable Document Format (PDF)",
  "NodeTypeIRMPDF": "Portable Document Format � IRM-gesch�tzt",
  "NodeTypePPT": "Microsoft Powerpoint",
  "NodeTypePresentation": "Pr�sentation",
  "NodeTypeXLS": "Microsoft Excel",
  "NodeTypeIRMXLS": "Microsoft Excel � IRM-gesch�tzt",
  "NodeTypeSpreadsheet": "Arbeitsblatt",
  "NodeTypeFormula": "Formel",
  "NodeTypePublisher": "Microsoft Publisher",
  "NodeTypeVisio": "Microsoft Visio",
  "NodeTypeMPP": "Microsoft Project",
  "NodeTypeONE": "Microsoft OneNote",
  "NodeTypeAccess": "Microsoft Access",
  "NodeTypeAI": "Adobe Illustrator",
  "NodeTypePhotoShop": "Adobe PhotoShop",
  "NodeTypeContentless": "Dokument ohne Inhalt",
  "NodeTypeVirtualDoc": "Virtuelles Dokument",
  "NodeTypeVirtualSnapshot": "Snapshot von virtuellem Dokument",
  "NodeTypeVirtualDocContentless": "Virtuelles Dokument ohne Inhalt",
  "NodeTypeXLSTemplate": "Microsoft Excel-Vorlage",
  "NodeTypeXLSIRMTemplate": "Microsoft Excel-Vorlage � IRM-gesch�tzt",
  "NodeTypeHTML": "HTML-Dokument",
  "NodeTypeInfoPath": "Microsoft InfoPath",
  "NodeTypeEmail": "E-Mail",
  "NodeTypeXML": "XML-Dokument",
  "NodeTypeAudio": "Audio",
  "NodeTypeCompressed": "Komprimierte Datei",
  "NodeTypeImage": "Bild",
  "NodeTypeText": "Textdokument",
  "NodeTypeHtml": "HTML-Dokument",
  "NodeTypeUnknown": "Unbekannt",
  "NodeTypeVideo": "Video",
  "NodeTypePPTTemplate": "Microsoft Powerpoint-Vorlage",
  "NodeTypePPTME": "Microsoft Powerpoint-Makro aktiviert",
  "NodeTypeCabinet": "Ablage",
  "NodeTypeRepository": "Repository",
  "NodeTypePPTIRM": "Microsoft Powerpoint � IRM-gesch�tzt",
  "NodeTypePPTIRMTemplate": "Microsoft Powerpoint-Vorlage � IRM-gesch�tzt",
  "NodeTypeBusinessWorkspace": "Gesch�ftsarbeitsbereich",
  "NodeTypeFolder": "Ordner",
  "NodeTypeQueryForm": "Abfrageformular",
  "NodeTypeEmcmf": "Emcmf",
  "NodeTypeEmcmfConverted": "Emcmf E-Mail"
});

csui.define("dctmw/widgets/widgettile/impl/nls/de/lang", {
  "tileTitle": "Widget auflisten",
  "expandAria": "Einblenden",
  "searchPlaceholder": "Elemente durchsuchen",
  "searchAria": "Nach Elementen suchen",
  "openView": "�ffnen",
  "emptyListText": "Es sind keine anzeigbaren Objekte verf�gbar.",
  "loadingListText": "Ergebnisse werden geladen...",
  "failedListText": "Laden der Ergebnisse fehlgeschlagen.",
  "zeroResults": "Keine Ergebnisse gefunden."
});

csui.define("dctmw/widgets/favorites/impl/nls/de/lang", {
  "dialogTitle": "Favoriten",
  "expandAria": "Favorigen-Widget �ffnen",
  "searchPlaceholder": "Favoriten suchen",
  "searchAria": "Favoriten suchen",
  "parent_id": "Speicherort",
  "openView": "Favorigen-Widget �ffnen"
});

csui.define("dctmw/widgets/favorites/impl/nls/de/favorites.manifest", {
  "title": "Favoriten",
  "description": "Zeigt Favoriten-Objekte des aktuellen Benutzers an."
});
