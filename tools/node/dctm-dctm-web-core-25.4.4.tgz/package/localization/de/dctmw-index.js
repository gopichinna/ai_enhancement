csui.require.config({
bundles: {
  "dctmw/bundles/nls/de/dctmw-all": [
    "dctmw/utils/nls/de/lang",
    "dctmw/overrides/csui/utils/impl/nls/de/lang",
    "dctmw/controls/list/impl/nls/de/lang",
    "dctmw/pages/app/impl/nls/de/lang",
    "dctmw/pages/error/impl/nls/de/lang",
    "dctmw/controls/signin/impl/nls/de/localized.strings",
    "dctmw/pages/signin/impl/nls/de/lang",
    "dctmw/pages/signout/impl/nls/de/lang",
    "dctmw/server.adaptors/models/impl/nls/de/lang",
    "dctmw/utils/icons/impl/nls/de/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/de/lang",
    "dctmw/widgets/favorites/impl/nls/de/lang",
    "dctmw/widgets/favorites/impl/nls/de/favorites.manifest"
  ]
}
});