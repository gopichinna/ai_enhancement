csui.require.config({
bundles: {
  "dctmw/bundles/nls/zh/dctmw-all": [
    "dctmw/utils/nls/zh/lang",
    "dctmw/overrides/csui/utils/impl/nls/zh/lang",
    "dctmw/controls/list/impl/nls/zh/lang",
    "dctmw/pages/app/impl/nls/zh/lang",
    "dctmw/pages/error/impl/nls/zh/lang",
    "dctmw/controls/signin/impl/nls/zh/localized.strings",
    "dctmw/pages/signin/impl/nls/zh/lang",
    "dctmw/pages/signout/impl/nls/zh/lang",
    "dctmw/server.adaptors/models/impl/nls/zh/lang",
    "dctmw/utils/icons/impl/nls/zh/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/zh/lang",
    "dctmw/widgets/favorites/impl/nls/zh/lang",
    "dctmw/widgets/favorites/impl/nls/zh/favorites.manifest"
  ]
}
});