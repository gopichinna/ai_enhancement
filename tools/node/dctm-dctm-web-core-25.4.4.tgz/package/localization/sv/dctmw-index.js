csui.require.config({
bundles: {
  "dctmw/bundles/nls/sv/dctmw-all": [
    "dctmw/utils/nls/sv/lang",
    "dctmw/overrides/csui/utils/impl/nls/sv/lang",
    "dctmw/controls/list/impl/nls/sv/lang",
    "dctmw/pages/app/impl/nls/sv/lang",
    "dctmw/pages/error/impl/nls/sv/lang",
    "dctmw/controls/signin/impl/nls/sv/localized.strings",
    "dctmw/pages/signin/impl/nls/sv/lang",
    "dctmw/pages/signout/impl/nls/sv/lang",
    "dctmw/server.adaptors/models/impl/nls/sv/lang",
    "dctmw/utils/icons/impl/nls/sv/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/sv/lang",
    "dctmw/widgets/favorites/impl/nls/sv/lang",
    "dctmw/widgets/favorites/impl/nls/sv/favorites.manifest"
  ]
}
});