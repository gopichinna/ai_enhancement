csui.define("dctmw/utils/nls/sv/lang", {
  "geolocationDisabledError": "Du till�ts inte att logga in eftersom webbl�saren inte kan tillhandah�lla din plats.\n F�r att logga in m�ste du uppdatera dina sekretessinst�llningar och till�ta positions�tkomst f�r den h�r webbplatsen.",
  "mobileGeolocationDisabledError": "Du kan inte logga in eftersom platstj�nsten �r avst�ngd.\n F�r att logga in till \"D2 mobile\"-programmet m�ste du aktivera platsinst�llningarna.",
  "authenticationError": "Autentiseringen misslyckades. Ogiltiga autentiseringsdata har angetts.",
  "InvalidRepositoryId": "Lagringsplatsen {0} finns inte.",
  "labelBannerDismissButton": "Avvisa",
  "labelReloadLink": "ladda om",
  "msgUpdateAvailable": "En uppdatering �r tillg�nglig, {0} sidan f�r att installera den.",
  "msgUpdateInstalled": "En uppdatering har installerats. Ladda om sidan f�r att forts�tta anv�nda programmet."
});

csui.define("dctmw/overrides/csui/utils/impl/nls/sv/lang", {
  "errorContinueSession": "Det gick inte att forts�tta sessionen.",
  "errorHttpPrefix": "HTTP"
});

csui.define("dctmw/controls/list/impl/nls/sv/lang", {
  "SortableListLastColumnMandatory": "�tminstone en kolumn m�ste �terst� i rutn�tet",
  "emptyStateMessage": "Inga objekt"
});

csui.define("dctmw/pages/app/impl/nls/sv/lang", {
  "defaultModuleErrorMessage": "Det gick inte att l�sa in programmet. Kontakta administrat�ren.",
  "errorEmbedModeUnsupported": "Embed-l�get st�ds inte p� mobila enheter."
});

csui.define("dctmw/pages/error/impl/nls/sv/lang", {
  "reloadLabel": "Ladda om",
  "signOutLabel": "Logga ut",
  "appLoadingError": "Det gick inte att l�sa in programmet. Kontakta administrat�ren."
});

csui.define("dctmw/controls/signin/impl/nls/sv/localized.strings", {
  "signinButtonText": "Logga in",
  "signinForgotPassword": "Gl�mt l�senordet?",
  "signinPlaceholderUsername": "Anv�ndarnamn",
  "signinPlaceholderPassword": "L�senord",
  "signinPlaceholderDomain": "Dom�n",
  "signinPlaceholderApplication": "Program",
  "signinPlaceholderLocation": "N�tverksplats",
  "signinPlaceholderRepository": "Databas",
  "signinInvalidUsernameOrPassword": "Du har angivit ett ogiltigt anv�ndarnamn eller l�senord. F�rs�k igen.",
  "signinApplicationSelectionNotAllowedWithoutDefault": "Inga av programvalen �r till�tna och inget standardv�rde har angetts.",
  "failedRepoConnection": "Det gick inte att ansluta till lagringsplatsen. Kontakta administrat�ren.",
  "haveBeenLoggedOut": "Du har loggats ut.",
  "closeBrowser": "St�ng ned din webbl�sare helt f�r att s�kerst�lla att de data som nyligen visades f�rblir privata.",
  "closeMobileBrowser": "St�ng ned din webbl�sare helt f�r att s�kerst�lla att de data som nyligen visades f�rblir privata.",
  "loginPage": "G� till inloggningssidan",
  "repoNotAvailable": "Det gick inte att h�mta listan �ver lagringsplatser. Kontakta administrat�ren.",
  "defaultApplication": "Standardprogram",
  "applicationFromURL": "Program fr�n URL",
  "retryButtonText": "Nytt f�rs�k",
  "ssoUserNotValidForRepository": "Det finns inget anv�ndarkonto som tillh�r dig i den valda databasen.",
  "ssoSigninFailed": "",
  "noAccountwithRepo": "Du har inte n�got konto i databasen",
  "invalidRepoInUrl": "Ett ogiltigt docbase-namn har angetts i parametrarna. Kontrollera URL:en.",
  "invalidApplicationInUrl": "Ogiltig parameter f�r program-URL eller programnamn i URL:en.",
  "mobileHeaderName": "OpenText D2 Mobile CE 23.2"
});

csui.define("dctmw/pages/signin/impl/nls/sv/lang", {
  "copyrightMessage": "Copyright � 2023 Open Text. Med ensamr�tt. Varum�rken �gs av Open Text."
});

csui.define("dctmw/pages/signout/impl/nls/sv/lang", {
  "signOutLabel": "Logga ut",
  "message": "Inloggad som <b>{0}</b>"
});

csui.define("dctmw/server.adaptors/models/impl/nls/sv/lang", {
  "doclistWidgetUnavailable": "Det gick inte att komma �t widgeten Standarddokumentlista. Antingen existerar den inte, eller s� har du inte �tkomstbeh�righet, eller s� har den en ogiltig konfiguration.",
  "typeColumnLabel": "Typ",
  "d2VersionColumnLabel": "Version",
  "reservedColumnLabel": "L�ge",
  "externalShareColumnLabel": "Dela",
  "favoriteColumnLabel": "Favorit",
  "inlineRowActionsColumnLabel": "�tg�rder",
  "vdmSequenceColumnLabel": "Sekvens",
  "locationColumnLabel": "Plats",
  "nodeTypeRepository": "Databas",
  "nodeTypeCabinet": "Sk�p",
  "nodeTypeFolder": "Mapp",
  "nodeTypeDocument": "Dokument",
  "nodeTypeRendition": "Rendering",
  "nodeTypeTask": "Uppgift",
  "nodeTypeWorkflowStep": "Arbetsfl�dessteg",
  "nodeTypeDQL": "DQL",
  "nodeTypeFavorites": "Favoriter",
  "nodeTypeObject": "Objekt",
  "nodeTypeUnreadTask": "Ol�st uppgift",
  "nodeTypeReadTask": "L�st uppgift",
  "nodeTypeAcquiredTask": "Inf�rskaffad uppgift",
  "nodeTypeDelegatedTask": "Delegerad uppgift",
  "nodeTypeRejectedTask": "Avvisad uppgift",
  "nodeTypeWorkflow": "Arbetsfl�de",
  "advanceSearch": "Avancerad s�kning",
  "advanceSearchForm": "Formul�r f�r avancerad s�kning",
  "advanceSearchGroup": "Kategori",
  "queryFormSearch": "Fr�geformul�r"
});

csui.define("dctmw/utils/icons/impl/nls/sv/localized.strings", {
  "NodeTypeDOC": "Microsoft Word",
  "NodeTypeIRMDOC": "IRM-skyddad Microsoft Word",
  "NodeTypeIRMTemplateDOC": "IRM-skyddad Microsoft Word-mall",
  "NodeTypePDF": "Portable Document Format",
  "NodeTypeIRMPDF": "IRM-skyddad Portable Document Format",
  "NodeTypePPT": "Microsoft Powerpoint",
  "NodeTypePresentation": "Presentation",
  "NodeTypeXLS": "Microsoft Excel",
  "NodeTypeIRMXLS": "IRM-skyddad Microsoft Excel",
  "NodeTypeSpreadsheet": "Kalkylblad",
  "NodeTypeFormula": "Formel",
  "NodeTypePublisher": "Microsoft Publisher",
  "NodeTypeVisio": "Microsoft Visio",
  "NodeTypeMPP": "Microsoft Project",
  "NodeTypeONE": "Microsoft OneNote",
  "NodeTypeAccess": "Microsoft Access",
  "NodeTypeAI": "Adobe Illustrator",
  "NodeTypePhotoShop": "Adobe PhotoShop",
  "NodeTypeContentless": "Inneh�llsl�st dokument",
  "NodeTypeVirtualDoc": "Virtuellt dokument",
  "NodeTypeVirtualSnapshot": "�gonblicksbild av virtuellt dokument",
  "NodeTypeVirtualDocContentless": "Virtuellt dokument utan inneh�ll",
  "NodeTypeXLSTemplate": "Microsoft Excel-mall",
  "NodeTypeXLSIRMTemplate": "IRM-skyddad Microsoft Excel-mall",
  "NodeTypeHTML": "HTML-dokument",
  "NodeTypeInfoPath": "Microsoft InfoPath",
  "NodeTypeEmail": "E-post",
  "NodeTypeXML": "XML-dokument",
  "NodeTypeAudio": "Audio",
  "NodeTypeCompressed": "Komprimerad fil",
  "NodeTypeImage": "Bild",
  "NodeTypeText": "Textdokument",
  "NodeTypeHtml": "HTML-dokument",
  "NodeTypeUnknown": "Ok�nd",
  "NodeTypeVideo": "Video",
  "NodeTypePPTTemplate": "Microsoft Powerpoint-mall",
  "NodeTypePPTME": "Makroaktiverad Microsoft Powerpoint",
  "NodeTypeCabinet": "Sk�p",
  "NodeTypeRepository": "Databas",
  "NodeTypePPTIRM": "IRM-skyddad Microsoft Powerpoint",
  "NodeTypePPTIRMTemplate": "IRM-skyddad Microsoft Powerpoint-mall",
  "NodeTypeBusinessWorkspace": "Aff�rsarbetsomr�de",
  "NodeTypeFolder": "Mapp",
  "NodeTypeQueryForm": "Fr�geformul�r",
  "NodeTypeEmcmf": "Emcmf",
  "NodeTypeEmcmfConverted": "Emcmf-e-post"
});

csui.define("dctmw/widgets/widgettile/impl/nls/sv/lang", {
  "tileTitle": "Listwidget",
  "expandAria": "Expandera",
  "searchPlaceholder": "S�k objekt",
  "searchAria": "S�k efter objekt",
  "openView": "�ppna",
  "emptyListText": "Det finns inga objekt att visa.",
  "loadingListText": "H�mtar resultat...",
  "failedListText": "Kunde inte h�mta resultat.",
  "zeroResults": "Inga resultat hittades."
});

csui.define("dctmw/widgets/favorites/impl/nls/sv/lang", {
  "dialogTitle": "Favoriter",
  "expandAria": "�ppna widgeten Favoriter",
  "searchPlaceholder": "S�k favoriter",
  "searchAria": "S�k favoriter",
  "parent_id": "Plats",
  "openView": "�ppna widgeten Favoriter"
});

csui.define("dctmw/widgets/favorites/impl/nls/sv/favorites.manifest", {
  "title": "Favoriter",
  "description": "Visar den aktuella anv�ndarens favoritobjekt."
});
