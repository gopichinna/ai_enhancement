csui.require.config({
bundles: {
  "dctmw/bundles/nls/ar/dctmw-all": [
    "dctmw/utils/nls/ar/lang",
    "dctmw/overrides/csui/utils/impl/nls/ar/lang",
    "dctmw/controls/list/impl/nls/ar/lang",
    "dctmw/pages/app/impl/nls/ar/lang",
    "dctmw/pages/error/impl/nls/ar/lang",
    "dctmw/controls/signin/impl/nls/ar/localized.strings",
    "dctmw/pages/signin/impl/nls/ar/lang",
    "dctmw/pages/signout/impl/nls/ar/lang",
    "dctmw/server.adaptors/models/impl/nls/ar/lang",
    "dctmw/utils/icons/impl/nls/ar/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/ar/lang",
    "dctmw/widgets/favorites/impl/nls/ar/lang",
    "dctmw/widgets/favorites/impl/nls/ar/favorites.manifest"
  ]
}
});