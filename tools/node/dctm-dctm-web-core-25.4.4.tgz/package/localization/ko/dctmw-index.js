csui.require.config({
bundles: {
  "dctmw/bundles/nls/ko/dctmw-all": [
    "dctmw/utils/nls/ko/lang",
    "dctmw/overrides/csui/utils/impl/nls/ko/lang",
    "dctmw/controls/list/impl/nls/ko/lang",
    "dctmw/pages/app/impl/nls/ko/lang",
    "dctmw/pages/error/impl/nls/ko/lang",
    "dctmw/controls/signin/impl/nls/ko/localized.strings",
    "dctmw/pages/signin/impl/nls/ko/lang",
    "dctmw/pages/signout/impl/nls/ko/lang",
    "dctmw/server.adaptors/models/impl/nls/ko/lang",
    "dctmw/utils/icons/impl/nls/ko/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/ko/lang",
    "dctmw/widgets/favorites/impl/nls/ko/lang",
    "dctmw/widgets/favorites/impl/nls/ko/favorites.manifest"
  ]
}
});