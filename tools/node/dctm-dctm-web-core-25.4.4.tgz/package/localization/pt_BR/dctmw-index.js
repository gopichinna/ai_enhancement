csui.require.config({
bundles: {
  "dctmw/bundles/nls/pt/dctmw-all": [
    "dctmw/utils/nls/pt/lang",
    "dctmw/overrides/csui/utils/impl/nls/pt/lang",
    "dctmw/controls/list/impl/nls/pt/lang",
    "dctmw/pages/app/impl/nls/pt/lang",
    "dctmw/pages/error/impl/nls/pt/lang",
    "dctmw/controls/signin/impl/nls/pt/localized.strings",
    "dctmw/pages/signin/impl/nls/pt/lang",
    "dctmw/pages/signout/impl/nls/pt/lang",
    "dctmw/server.adaptors/models/impl/nls/pt/lang",
    "dctmw/utils/icons/impl/nls/pt/localized.strings",
    "dctmw/widgets/widgettile/impl/nls/pt/lang",
    "dctmw/widgets/favorites/impl/nls/pt/lang",
    "dctmw/widgets/favorites/impl/nls/pt/favorites.manifest"
  ]
}
});