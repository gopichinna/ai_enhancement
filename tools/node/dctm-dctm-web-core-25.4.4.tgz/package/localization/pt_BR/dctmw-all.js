csui.define("dctmw/utils/nls/pt/lang", {
  "geolocationDisabledError": "Voc� n�o tem permiss�o para fazer login porque o navegador n�o consegue fornecer o local.\n Para fazer login, atualize suas configura��es de privacidade para permitir o acesso local a esse site.",
  "mobileGeolocationDisabledError": "Voc� n�o pode fazer login porque os servi�os de local est�o desativados.\n Para fazer login no aplicativo \"D2 mobile\", habilite as configura��es do local.",
  "authenticationError": "Houve falha na autentica��o. Dados de autentica��o inv�lidos fornecidos.",
  "InvalidRepositoryId": "O reposit�rio {0} n�o existe.",
  "labelBannerDismissButton": "Ignorar",
  "labelReloadLink": "recarregar",
  "msgUpdateAvailable": "Uma atualiza��o est� dispon�vel, {0} a p�gina para instal�-la.",
  "msgUpdateInstalled": "Uma atualiza��o foi instalada, recarregue a p�gina para continuar a usar o aplicativo."
});

csui.define("dctmw/overrides/csui/utils/impl/nls/pt/lang", {
  "errorContinueSession": "Falha ao continuar a sess�o.",
  "errorHttpPrefix": "HTTP"
});

csui.define("dctmw/controls/list/impl/nls/pt/lang", {
  "SortableListLastColumnMandatory": "Pelo menos uma coluna deve permanecer na grade",
  "emptyStateMessage": "Sem itens"
});

csui.define("dctmw/pages/app/impl/nls/pt/lang", {
  "defaultModuleErrorMessage": "Falha ao carregar o aplicativo. Entre em contato com o administrador.",
  "errorEmbedModeUnsupported": "O modo Embed n�o � compat�vel com dispositivos m�veis."
});

csui.define("dctmw/pages/error/impl/nls/pt/lang", {
  "reloadLabel": "Recarregar",
  "signOutLabel": "Sair",
  "appLoadingError": "Falha ao carregar o aplicativo. Entre em contato com o administrador."
});

csui.define("dctmw/controls/signin/impl/nls/pt/localized.strings", {
  "signinButtonText": "Fazer login",
  "signinForgotPassword": "Esqueceu a senha?",
  "signinPlaceholderUsername": "Nome do usu�rio",
  "signinPlaceholderPassword": "Senha",
  "signinPlaceholderDomain": "Dom�nio",
  "signinPlaceholderApplication": "Aplicativo",
  "signinPlaceholderLocation": "Local da rede",
  "signinPlaceholderRepository": "Reposit�rio",
  "signinInvalidUsernameOrPassword": "Voc� inseriu um nome de usu�rio ou senha inv�lidos. Tente novamente.",
  "signinApplicationSelectionNotAllowedWithoutDefault": "Nenhuma sele��o de aplicativos permitida, e nenhum valor padr�o especificado.",
  "failedRepoConnection": "Falha ao conectar ao reposit�rio. Entre em contato com o administrador.",
  "haveBeenLoggedOut": "Voc� foi desconectado.",
  "closeBrowser": "Feche completamente o seu navegador para garantir a privacidade dos dados visualizados recentemente.",
  "closeMobileBrowser": "Feche completamente o navegador m�vel para garantir a privacidade dos dados visualizados recentemente.",
  "loginPage": "Acessar p�gina de login",
  "repoNotAvailable": "Falha ao recuperar a lista de reposit�rios. Entre em contato com o administrador.",
  "defaultApplication": "Aplicativo padr�o",
  "applicationFromURL": "Aplicativo a partir da URL",
  "retryButtonText": "Tente novamente",
  "ssoUserNotValidForRepository": "N�o h� uma conta de usu�rio para voc� no reposit�rio selecionado.",
  "ssoSigninFailed": "",
  "noAccountwithRepo": "Voc� n�o tem uma conta no reposit�rio",
  "invalidRepoInUrl": "Nome inv�lido de docbase fornecido nos par�metros. Confira a URL.",
  "invalidApplicationInUrl": "Par�metro de URL de aplicativo ou nome do aplicativo inv�lido na URL.",
  "mobileHeaderName": "OpenText D2 Mobile CE 23.2"
});

csui.define("dctmw/pages/signin/impl/nls/pt/lang", {
  "copyrightMessage": "Copyright � 2023 Open Text. Todos os direitos reservados. Marcas comerciais de propriedade da Open Text."
});

csui.define("dctmw/pages/signout/impl/nls/pt/lang", {
  "signOutLabel": "Sair",
  "message": "Fazer login como <b>{0}</b>"
});

csui.define("dctmw/server.adaptors/models/impl/nls/pt/lang", {
  "doclistWidgetUnavailable": "N�o foi poss�vel acessar o widget Doclist. Ele n�o existe, voc� n�o tem permiss�o para acess�-lo ou ele possui configura��o inv�lida.",
  "typeColumnLabel": "Tipo",
  "d2VersionColumnLabel": "Vers�o",
  "reservedColumnLabel": "Estado",
  "externalShareColumnLabel": "Compartilhar",
  "favoriteColumnLabel": "Favorito",
  "inlineRowActionsColumnLabel": "A��es",
  "vdmSequenceColumnLabel": "Sequ�ncia",
  "locationColumnLabel": "Local",
  "nodeTypeRepository": "Reposit�rio",
  "nodeTypeCabinet": "Gabinete",
  "nodeTypeFolder": "Pasta",
  "nodeTypeDocument": "Documento",
  "nodeTypeRendition": "Representa��o",
  "nodeTypeTask": "Tarefa",
  "nodeTypeWorkflowStep": "Etapa do fluxo de trabalho",
  "nodeTypeDQL": "DQL",
  "nodeTypeFavorites": "Favoritos",
  "nodeTypeObject": "Objeto",
  "nodeTypeUnreadTask": "Tarefa n�o lida",
  "nodeTypeReadTask": "Ler tarefa",
  "nodeTypeAcquiredTask": "Tarefa adquirida",
  "nodeTypeDelegatedTask": "Tarefa delegada",
  "nodeTypeRejectedTask": "Tarefa rejeitada",
  "nodeTypeWorkflow": "Fluxo de trabalho",
  "advanceSearch": "Pesquisa avan�ada",
  "advanceSearchForm": "Formul�rio de pesquisa avan�ada",
  "advanceSearchGroup": "Categoria",
  "queryFormSearch": "Formul�rio de consulta"
});

csui.define("dctmw/utils/icons/impl/nls/pt/localized.strings", {
  "NodeTypeDOC": "Microsoft Word",
  "NodeTypeIRMDOC": "Microsoft Word protegido por IRM",
  "NodeTypeIRMTemplateDOC": "Modelo do Microsoft Word protegido por IRM",
  "NodeTypePDF": "Formato de documento port�til",
  "NodeTypeIRMPDF": "Formato de documento port�til protegido por IRM",
  "NodeTypePPT": "Microsoft Powerpoint",
  "NodeTypePresentation": "Apresenta��o",
  "NodeTypeXLS": "Microsoft Excel",
  "NodeTypeIRMXLS": "Microsoft Excel protegido por IRM",
  "NodeTypeSpreadsheet": "Planilha",
  "NodeTypeFormula": "F�rmula",
  "NodeTypePublisher": "Microsoft Publisher",
  "NodeTypeVisio": "Microsoft Visio",
  "NodeTypeMPP": "Microsoft Project",
  "NodeTypeONE": "Microsoft OneNote",
  "NodeTypeAccess": "Microsoft Access",
  "NodeTypeAI": "Adobe Illustrator",
  "NodeTypePhotoShop": "Adobe PhotoShop",
  "NodeTypeContentless": "Documento sem conte�do",
  "NodeTypeVirtualDoc": "Documento virtual",
  "NodeTypeVirtualSnapshot": "Instant�neo de documento virtual",
  "NodeTypeVirtualDocContentless": "Documento virtual sem conte�do",
  "NodeTypeXLSTemplate": "Modelo do Microsoft Excel",
  "NodeTypeXLSIRMTemplate": "Modelo do Microsoft Excel protegido por IRM",
  "NodeTypeHTML": "Documento HTML",
  "NodeTypeInfoPath": "Microsoft InfoPath",
  "NodeTypeEmail": "E-mail",
  "NodeTypeXML": "Documento XML",
  "NodeTypeAudio": "�udio",
  "NodeTypeCompressed": "Arquivo compactado",
  "NodeTypeImage": "Imagem",
  "NodeTypeText": "Documento de texto",
  "NodeTypeHtml": "Documento Html",
  "NodeTypeUnknown": "Desconhecido",
  "NodeTypeVideo": "V�deo",
  "NodeTypePPTTemplate": "Modelo do Microsoft Powerpoint",
  "NodeTypePPTME": "Macro do Microsoft Powerpoint habilitada",
  "NodeTypeCabinet": "Gabinete",
  "NodeTypeRepository": "Reposit�rio",
  "NodeTypePPTIRM": "Microsoft Powerpoint protegido por IRM",
  "NodeTypePPTIRMTemplate": "Modelo do Microsoft Powerpoint protegido por IRM",
  "NodeTypeBusinessWorkspace": "�rea de trabalho comercial",
  "NodeTypeFolder": "Pasta",
  "NodeTypeQueryForm": "Formul�rio de consultas",
  "NodeTypeEmcmf": "Emcmf",
  "NodeTypeEmcmfConverted": "E-mail Emcmf"
});

csui.define("dctmw/widgets/widgettile/impl/nls/pt/lang", {
  "tileTitle": "Widget de lista",
  "expandAria": "Expandir",
  "searchPlaceholder": "Pesquisar itens",
  "searchAria": "Pesquisar por itens",
  "openView": "Abrir",
  "emptyListText": "N�o h� nenhum item a ser exibido.",
  "loadingListText": "Carregando resultados...",
  "failedListText": "Falha no carregamento dos resultados.",
  "zeroResults": "Nenhum resultado encontrado."
});

csui.define("dctmw/widgets/favorites/impl/nls/pt/lang", {
  "dialogTitle": "Favoritos",
  "expandAria": "Abrir o widget Favorites",
  "searchPlaceholder": "Pesquisar Favoritos",
  "searchAria": "Pesquisar Favoritos",
  "parent_id": "Local",
  "openView": "Abrir o widget Favorites"
});

csui.define("dctmw/widgets/favorites/impl/nls/pt/favorites.manifest", {
  "title": "Favoritos",
  "description": "Exibe os objetos favoritos do usu�rio atual."
});
