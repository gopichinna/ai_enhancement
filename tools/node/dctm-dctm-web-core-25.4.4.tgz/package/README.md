# Documentum Web Core

Umbrella web application built using OT SVF. 
Purpose of this project is to provide generalized setup logic at both development time and runtime for creating pure JS 
client web-apps based on OT SVF for Documentum and related server stacks.

## Setup

### Pre-requisites
* NodeJS (>=20).
* Git client.
* Git CLI configured to work in SSH mode and authenticated with `gitlab.otxlab.net`.
* At least 'Reporter' access granted to following repositories
    * [Documentum Web Core](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-core)

### Steps
* Open a command prompt inside a directory of choice.
* `$git clone git@gitlab.otxlab.net:dctmw/sv/infra/dctm-web-core.git`
* `$cd dctm-web-core/`
* `$npm install`
* `$npm run build`

### Keeping things always up to date
This project depends on several OT SVF projects. To make sure that we are
always catching up with recent developments -
* Open a git bash terminal in `dctm-web-core` directory
* Execute `git pull` to get latest from other team members.
* Execute `npm update`

## Hands on
* Edit `server.conf.js` and provide a value for `APP_SERVER_URL`. The supplied URL should point to a deployed D2-Smartview/D2-REST or DCTM-REST instance.
* Open a terminal in `dctm-web-core` directory.
* Execute command `npm start`
* Open URL http://localhost:6989/ui/pages/debug/app.html in your browser.
  Or alternatively, open http://localhost:6989/ui/pages/release/app.html after executing `npm run build` from the terminal.

## Contribution
Please go through the [Contribution Guideline](./CONTRIBUTING.md).

## Contact
jayantad@opentext.com
