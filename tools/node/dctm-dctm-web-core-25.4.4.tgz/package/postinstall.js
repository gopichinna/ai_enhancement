'use strict';

const {ensureSymlinkSync} = require('fs-extra');
const {join, resolve} = require('path');
const selfDir = __dirname;

function getParentProjectDir() {
  const rCurrDir = resolve(selfDir);
  return rCurrDir.substring(0, rCurrDir.indexOf('node_modules'));
}

function ensureDirectoryLink(source, target) {
  console.debug(`Ensuring sym-link ${source} => ${target}`);
  ensureSymlinkSync(source, target, 'junction');
}

ensureDirectoryLink(resolve(join(getParentProjectDir(), 'lib/src/dctmw')), resolve(join(selfDir, 'src')));
ensureDirectoryLink(resolve(join(getParentProjectDir(), 'lib')), resolve(join(selfDir, 'lib')));
