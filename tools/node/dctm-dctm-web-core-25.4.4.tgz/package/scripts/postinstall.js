'use strict';

const
  csuiDepsInstaller = require('@smartui/csui-dependency-installer'),
  { join, resolve, dirname } = require('path'),
  {readFile, ensureDir, writeFile, existsSync, ensureSymlinkSync, copySync} = require('fs-extra'),
  rimraf = require('rimraf'),
  cwd = __dirname,
  selfDir = resolve(join(cwd, '..')),
  csuiDependencies = [
    'csui:25.4.7',
    'esoc:25.4.0'
  ],
  isRunningAsMainProject = isAsMainProject(),
  depInstallDir = isRunningAsMainProject ? selfDir : getParentProjectDir();

csuiDepsInstaller.installDependencies({
  projectDirectory: depInstallDir,
  dependencies: csuiDependencies,
  languages: [],
  verbose: true
})
.then(()=>{
  return new Promise((resolve)=> {
    const deps = ['csui', 'esoc'];
    const depIterator = () => {
      if(deps.length) {
        const depName = deps.shift();
        overwriteDepModuleFiles(depName, depIterator);
      } else {
        resolve();
      }
    };
    depIterator();
  });
})
.then(async () => {
  if(!isRunningAsMainProject) {
    console.log('Linking dependencies...');
    ensureSymLink(`${getParentProjectDir()}/lib`, `${selfDir}/lib`);
    
    console.log(`Copying linter config files...`);
    const parentProjDir = getParentProjectDir();
    const filesToBeCopied = [
      '.stylelintrc.yml',
      '.eslintrc.yml',
      '.eslintrc-html.yml'
    ];
    filesToBeCopied.forEach((fileName) => {
      const srcFilePath = `${selfDir}/${fileName}`;
      const destFilePath = `${parentProjDir}/${fileName}`;
      if (!existsSync(destFilePath)) {
        copySync(srcFilePath, destFilePath);
      } else {
        console.log(`Lint configuration: "${destFilePath}" already exist.`);
      }
    });
    
    if(existsSync(`${selfDir}/.npmignore`)) {
      console.log(`copying .gitignore`);
      copySync(`${selfDir}/.npmignore`, `${parentProjDir}/.gitignore`);
    }
  } else {
    console.log(`Running as main project.`);
    
    await copyUAErrorPage(
      `${selfDir}/ua.error.page.source.translation.json`,
      `${selfDir}/lib/src/csui/pages/ie-not-supported/ie-not-supported.html`,
      `${selfDir}/ua.error.page.target.translations.json`,
      `${selfDir}/pages/error`
    );
  }
})
.catch(fail);

function fail(error) {
  console.error('  ' + (error.message || error));
  process.exitCode = 1;
}

function copyUAErrorPage(srcLangFile, srcPage, targetLangFile, targetDirectory) {
  console.log(`Copy user agent error page: ${srcPage}`);
  const srcLangJSON = require(srcLangFile).en;
  const targetLangJSON = require(targetLangFile);

  return new Promise((resolve) => {
      const pathPattern = join(targetDirectory, '*.html');
      console.log(`Removing '${pathPattern}'`);
      rimraf(pathPattern, resolve);
    })
    .then(() => {
      return readFile(srcPage, 'utf-8');
    })
    .then(srcFileContent => {
      return Promise.all(Object.keys(targetLangJSON).map(langKey => {
        let targetContent = srcFileContent;
        const currentTranslations = targetLangJSON[langKey];
        Object.keys(currentTranslations).forEach(translationKey => {
          if(srcLangJSON[translationKey] !== currentTranslations[translationKey]) {
            targetContent = targetContent.replace(srcLangJSON[translationKey], currentTranslations[translationKey]);
          }
        });
        targetContent = targetContent.replace(/lang="en"/, `lang="${langKey}"`);
        console.log(`Copying UA error page for language: ${langKey}`);
        return writeFileContent(join(targetDirectory, `ua-unsupported_${langKey}.html`), targetContent);
      }));
    });
}

function writeFileContent(targetFile, content) {
  console.log(`Writing to ${targetFile}`);
  const dir = dirname(targetFile);
  return ensureDir(dir)
    .then(() => {
      return writeFile(targetFile, content, 'utf-8');
    });
}

function isAsMainProject() {
  const dirNodeModules = resolve(selfDir);
  return dirNodeModules.indexOf('node_modules') < 0;
}

function getParentProjectDir() {
  const rCurrDir = resolve(selfDir);
  return rCurrDir.substring(0, rCurrDir.indexOf('node_modules'));
}

function ensureSymLink(source, target) {
  console.log(`Creating symbolic link ${source} -> ${target}`);
  ensureSymlinkSync(resolve(source), resolve(target), 'junction');
}

function overwriteDepModuleFiles(name, callback) {
  const src = join(depInstallDir, 'lib/src/' + name),
    debug = join(depInstallDir, 'lib/debug/' + name),
    release = join(depInstallDir, 'lib/release/' + name);
  
  if (name === 'csui') {
    const search = /(['"]csui\/utils\/contexts\/factories\/search\.box\.factory['"],)/g,
      replace = '$1"csui/models/widget/search.results/search.response.mixin","csui/models/widget/search.results/search.facets",';
    updateFile(debug + '/bundles/csui-app-index.js', search, replace, function () {
      updateFile(debug + '/bundles/csui-app-index.json', search, replace, function () {
        updateFile(release + '/bundles/csui-app-index.js', search, replace, function () {
          updateFile(release + '/bundles/csui-app-index.json', search, replace, callback);
        });
      });
    });
  } else {
    callback && callback();
  }
}

function updateFile(file, search, replace, callback) {
  if(existsSync(file)) {
    console.log(`Updating file : ${file}`);
    readFile(file, 'utf8', function (err, data) {
      if (err) {
        return fail(err);
      }
      
      const result = data.replace(search, replace);
      writeFile(file, result, 'utf8', function (err) {
        if (err) {
          return fail(err);
        }
        if (callback) {
          callback();
        }
      });
    });
  } else {
    console.warn(`Could not update non-existing file : ${file}`);
    callback && callback();
  }
}
