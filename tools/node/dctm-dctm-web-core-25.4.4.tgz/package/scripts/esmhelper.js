'use strict';

const { preprocessor: originalPreprocessor } = require('requirejs-esm-preprocessor');
const { normalizeConfigLocation, inferPrefix } = require('@smartui/grunt-support/utils/load.config');
const { isScript: defaultIsScript, getScriptRules } = require('@smartui/grunt-support/utils/is.script');
const parseBuildConfig = require('@smartui/grunt-support/utils/parse.build.config');
const { isAbsolute, normalize, join } = require('path');
const nonSVFPackages = require(join(process.cwd(), 'node_modules', '@dctm/dctm-web-tools/utils/svf.helper')).getNonSVFPackages();

let configCache = {};
let componentCache = {};

function loadBuildConfig ({ srcDir, configName, configPath, verbose } = {}) {
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));

  if(configCache[configPath]) return configCache[configPath];

  if (verbose) console.log(`Loading build config "${configPath}".`);
  const config = parseBuildConfig(configPath);

  if (!config.prefix) config.prefix = inferPrefix(srcDir);
  configCache[configPath] = config;

  return config;
}

function loadComponentsDescriptors ({ rootDir, srcDir, configName, configPath, verbose } = {}) {
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));

  if(componentCache[configPath]) return componentCache[configPath];

  verbose && console.log('Loading component descriptors.');
  const { paths: compPaths } = loadBuildConfig({ configPath, verbose });

  // Relative paths in Node.js modules are resolved against the script
  // source directory; not against the process current directory, where
  // the Smart UI components are installed.
  if (!isAbsolute(srcDir)) srcDir = `${process.cwd()}/${srcDir}`;
  if (!rootDir) rootDir = `${srcDir}/..`;

  const components = {};
  for (const compPrefix in compPaths) {
    const compPath = compPaths[compPrefix];
    const compModule = normalize(compPath === 'empty:'
      ? `${rootDir}/lib/src/${compPrefix}/component`
      : `${srcDir}/${compPath}/component`);
    // The paths configuration can point to directories with pre-bundled
    // libraries, which are no Smart UI projects.
    try {
      require.resolve(compModule);
      verbose && console.log(`  "${compPrefix}" is a Smart UI component`);
    } catch (error) {
      verbose && console.warn(`  "${compPrefix}" is not a Smart UI component`);
      continue;
    }

    try {
      components[compPrefix] = require(compModule);
    } catch (error) {
      console.warn(`Loading "${compModule}" failed:`);
      console.warn(error);
    }
  }

  componentCache[configPath] = components;

  return components;
}

function cutQuery (url) {
  const questionMark = url.indexOf('?');
  return questionMark > 0 ? url.substring(0, questionMark) : url;
}

function esmPreprocessor(options = {}) {
  let { isScript, srcDir, configName, configPath, verbose, root } = options;

  if (!(srcDir || configPath)) srcDir = 'src';
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));
  const components = loadComponentsDescriptors({ srcDir, configPath, verbose, rootDir: root });
  const { prefix } = loadBuildConfig({ configPath, verbose });
  if (verbose) {
    console.log('Script recognition:');
    console.log(JSON.stringify(getScriptRules(components, prefix), undefined, 2));
  }

  const finalIsScript = path => {
    const isViewer = nonSVFPackages.some((n) => path.indexOf(`/${n}/`) >= 0);
    return !isViewer && defaultIsScript(components, path, prefix) && (!isScript || isScript(path));
  };
  return originalPreprocessor({
    ...options,
    isScript: path => finalIsScript(cutQuery(path))
  });
}

module.exports = {
  normalizeConfigLocation,
  inferPrefix,
  loadBuildConfig,
  loadComponentsDescriptors,
  esmPreprocessor
};
