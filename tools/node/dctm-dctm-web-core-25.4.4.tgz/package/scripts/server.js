#!/usr/bin/env node

'use strict';

const
  {resolve, join: pathJoin} = require('path'),
  http = require('http'),
  https = require('https'),
  url = require('url'),
  compression = require('compression'),
  connect = require('connect'),
  cors = require('cors'),
  {readFileSync, existsSync} = require('fs-extra'),
  parseUrl = require('parseurl'),
  { isWebUri } = require('valid-url'),
  morgan = require('morgan'),
  staticFiles = require('serve-static'),
  _ = require('underscore'),
  cwd = process.cwd(),
  currDir = __dirname,
  selfDir = pathJoin(currDir, '..');

console.log(`CWD: ${resolve(cwd)}`);

const
  launchConfig = require(pathJoin(cwd, 'node_modules', '@dctm/dctm-web-tools/utils/svf.helper')).getLaunchConfig(),
  {esmPreprocessor} = require(pathJoin(currDir, 'esmhelper')),
  proxy = require('@dctm/dctm-web-tools/packer/node/utils/proxy');

let serverConfig = {};
if(existsSync(`${cwd}/server.conf.js`)) {
  serverConfig = require(`${cwd}/server.conf`);
}
const
  defaultRequestInterceptor = (req, res, next) => {next();},
  {requestInterceptor = defaultRequestInterceptor} = serverConfig;

const { APP_SERVER_URL = serverConfig.APP_SERVER_URL } = process.env,
  enableProxy = serverConfig.APP_SERVER_IS_PROXIED === true && !!isWebUri(APP_SERVER_URL),
  { host: proxyHost, path: proxyPath, protocol: proxyProtocol } = enableProxy ? url.parse(APP_SERVER_URL) : {};

const host = process.env.SERVER_HOST || '0.0.0.0',
  browserHost = host === '0.0.0.0' ? 'localhost' : host,
  port = parseInt(process.env.SERVER_PORT || serverConfig.LOCAL_HTTP_PORT || 6989),
  securePort = parseInt(process.env.SERVER_SECURE_PORT || serverConfig.LOCAL_HTTPS_PORT || 9698),
  secureOptions = {
    key: readFileSync(`${require.resolve('@dctm/dctm-web-tools/packer/node/ssl-key.pem')}`),
    cert: readFileSync(`${require.resolve('@dctm/dctm-web-tools/packer/node/ssl-certificate.pem')}`)
  },
  corsOptions = {
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['origin', 'authorization', 'x-targetbaseurl'],
    exposedHeaders: ['content-length', 'authorization'],
    maxAge: 1728000
  },
  staticOptions = {
    etag: false,
    maxAge: 0 //31536000
  },
  staticRoutes = {
    '_default_': staticFiles(selfDir, staticOptions),
    '_lib_': staticFiles(cwd, staticOptions)
  },
  pluginEsmHandlers = {},
  verboseEsmHandlers = false;

launchConfig['app_server_url'] = enableProxy ? proxyPath : APP_SERVER_URL;

let pluginData = {};
for (var pKey in launchConfig.packages) {
  if (launchConfig.packages.hasOwnProperty(pKey)) {
    const plugin = launchConfig.packages[pKey];
    let pluginPath = plugin.path || cwd;
    pluginData[pKey] = plugin;
    staticRoutes[pKey] = staticFiles(pluginPath, staticOptions);
    pluginEsmHandlers[pKey] = esmPreprocessor({
      scriptsOnly: true,
      verbose: verboseEsmHandlers,
      configPath: pathJoin(pluginPath, 'src', 'config-build.js'),
      root: pluginPath,
      isScript: serverConfig.isESM
    });
  }
}
const serializedPluginData = JSON.stringify(pluginData);

const
  serverStartTime = new Date().getTime(),
  esmPreprocessHandler = esmPreprocessor({
    scriptsOnly: true,
    verbose: verboseEsmHandlers,
    isScript: function (uri) {
      if (uri?.endsWith('smart/bundles/cropperjs/cropper.js')) {
        return false;
      }
      return serverConfig.isESM.apply(this, arguments);
    },
    configPath: `${selfDir}/src/config-build.js`,
    root: selfDir
  }),
  server = connect();

server
  .use(morgan('short', {
    skip: function (req, res) {
      return res.statusCode < 300;
    }
  }))
  .use(compression())
  .use(requestInterceptor)
  .use(function (req, res, next) {
    if (req.url === '/favicon.ico') {
      req.url = '/pages' + req.url;
    } else if (req.url.indexOf('/ui') !== 0) {
      next();
      return;
    } else {
      req.url = req.url.substring(req.url.indexOf('/', 1));
      let userAgent = req.headers['user-agent'],
        aLanguage = req.headers['accept-language'],
        pageLang = aLanguage ? aLanguage.split(',')[0].split('-')[0] : 'en',
        errorPageName = `ua-unsupported_${pageLang}.html`;

      if(!existsSync(resolve(`./pages/error/${errorPageName}`))) {
        errorPageName = 'ua-unsupported_en.html';
      }

      if(userAgent.match(/Trident/i) && !req.url.endsWith(errorPageName)) {
        res.writeHead(301, {
          'Location': `/ui/pages/error/${errorPageName}`
        });
        res.end();
        return;
      }

      let
        subPath = req.url.substring(req.url.indexOf('/', 5)),
        prefix = subPath.substring(1, subPath.indexOf('/', 1)),
        pluginPath = pluginData[prefix];
      if (pluginPath) {
        //req.url = req.url.substring(req.url.indexOf('/', 1));
        pluginEsmHandlers[prefix](req, res, () => {
          return staticRoutes[prefix](req, res, next);
        });
        return;
      } else if (req.url.indexOf('/pages/') === 0 || req.url.indexOf('/out-page/') === 0) {
        let reqPath = parseUrl(req).pathname, path = `${selfDir}${reqPath}`;
        if(req.url.indexOf('.html') > 0) {
          if(reqPath.endsWith('oauth2-login-cb.html')) {
            path = `${selfDir}${reqPath.substring(0, reqPath.indexOf('/', 1))}/oauth2-login-cb.html`;
          }
          // Replace "pluginData" placeholder in development HTML files
          let body = readFileSync(path, {encoding: 'utf8'});
          body = body.replace(/\$_pluginData_/, serializedPluginData);
          res.end(body);
          return;
        } else if(req.url.endsWith('/service-worker.js')) {
          res.setHeader('Service-Worker-Allowed', '/');
          res.setHeader('Content-Type', 'application/javascript; charset=UTF-8');
          let swContent = readFileSync(path, {encoding: 'utf8'});
          swContent = swContent.replace(/\${__tVersion__}/, serverStartTime);
          res.end(swContent);
          return;
        } else if(req.url.endsWith('/launcher.json')) {
          res.end(JSON.stringify(launchConfig));
          return;
        }
      }

      esmPreprocessHandler(req, res, () => {
        return staticRoutes[req.url.startsWith('/lib') ? '_lib_' : '_default_'](req, res, next);
      });
      return;
    }

    return staticRoutes['_default_'](req, res, next);
  });

// CORS Proxy
if (enableProxy) {
  server
    .use(proxy({
      targetBaseUrl: `${proxyProtocol}//${proxyHost}`,
      corsOptions: corsOptions,
      httpsOptions: {
        allowUnsecure: serverConfig.PROXIED_APP_SERVER_ALLOWS_SELF_SIGNED_HTTPS
      }
    }))
    .use(cors(function (request, callback) {
      const methods = _.unique(corsOptions.methods.concat(request.headers['access-control-request-method'])),
        requestedHeaders = request.headers['access-control-request-headers'],
        allowedHeaders = _.unique(_.compact(
          corsOptions.allowedHeaders.concat((requestedHeaders || '').split(/\s*,\s*/))));
      callback(null, {
        origin: true,
        methods: methods.join(','),
        allowedHeaders: allowedHeaders.join(','),
        exposedHeaders: corsOptions.allowedHeaders.join(','),
        maxAge: corsOptions.maxAge
      });
    }));
}

console.log('Web server worker', process.pid, `is serving at http://${browserHost}:${port}/ui/pages/debug/app.html`);
http.createServer(server).listen(port, host);

console.log('Web server worker', process.pid, `is serving at https://${browserHost}:${securePort}/ui/pages/debug/app.html`);
https.createServer(secureOptions, server).listen(securePort, host);
