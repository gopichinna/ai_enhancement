(function () {
  'use strict';
  
  jasmine.DEFAULT_TIMEOUT_INTERVAL = 30000;
  
  const args = window.__karma__.config.args,
    isDebug = args && (args.indexOf('debug') >= 0),
    {logLevel='WARN'} = window.__karma__.config,
    {
      packages: pluginData,
      packageUnderTest,
      bundlesUnderTest
    } = window.__karma__.config?.dctmLaunchConfig,
    {
      paths: rPaths={},
      shim: rShim={},
      map: rMap={},
      config: rConfig={}
    } = window.__karma__.config?.requireJsConfig || {},
    globalConfig = window.__karma__.config?.globalConfig || {},
    buildMode = (isDebug ? 'src' : 'release'),
    baseUrl = '/base',
    specs = [],
    specsRegex = new RegExp('\\.spec\\.js$');
  
  if (isDebug) {
    window.csui.require = require;
    window.csui.requirejs = requirejs;
  } else {
    window.define = window.csui.define;
    window.require = window.csui.require;
    window.requirejs = window.csui.requirejs;
  }
  
  window.csui.supportPath = '/lib/' + buildMode;
  define('prepare-test-page', function () {
    document.body.classList.add('binf-widgets');
  });
  
  let commonSpecFiles=[];
  for (const file in window.__karma__.files) {
    if (window.__karma__.files.hasOwnProperty(file)) {
      if (specsRegex.test(file)) {
        if(file.endsWith('common.spec.js')) {
          (logLevel === 'DEBUG') && console.log(`Common spec :: ${file}`);
          commonSpecFiles.push(file);
        } else if(file.startsWith(baseUrl + '/src')) {
          (logLevel === 'DEBUG') && console.log(`Test spec :: ${file}`);
          specs.push(file);
        }
      }
    }
  }
  
  window.sv = {
    freezeInitConfigBeforeInit: false,
    config: {
      devMode: true,
      buildMode: buildMode,
      baseLocation: baseUrl,
      otherBundlesLocation: '/lib/' + buildMode,
      pluginData: pluginData,
      ...globalConfig
    }
  };
  
  const deps = [
    ...bundlesUnderTest.map(b => `${packageUnderTest}/bundles/${b}`)
  ], requireConfig = {
    'nuc/lib/jquery.mockjax': {
      settings: {
        logging: false,
        responseTime: 0,
        throwUnmocked: false
      }
    },
    'nuc/contexts/factories/connector': {
      connection: {
        url: '//server/dctm',
        supportPath: '/'
      }
    },
    'dctmw/utils/geolocation.utils': {
      disableLocationTracking: true
    },
    ...rConfig
  };
  
  window.sv.config.connection = requireConfig['nuc/contexts/factories/connector'].connection;
  
  window.csui.require.config({
    waitSeconds: 60,
    paths: {...rPaths},
    shim: {...rShim},
    map: {...rMap},
    config: requireConfig,
    
    deps: ['require'],
    
    callback: function (require) {
      document.addEventListener('dctmw:loaded', ()=>{
        require([...deps, 'prepare-test-page'], ()=>{
          require([...commonSpecFiles], ()=>{
            require(specs, window.__karma__.start);
          });
        });
      });
    }
  });
}());
