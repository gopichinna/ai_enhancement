define([
  'nuc/lib/jquery'
], function ($) {
  'use strict';

  const xhrQueue = [];
  $(document).ajaxSend(function (event, jqxhr/*, settings*/) {
    xhrQueue.push(jqxhr);
  });
  $(document).ajaxComplete(function (event, jqxhr/*, settings*/) {
    const i = $.inArray(jqxhr, xhrQueue);
    if (i > -1) {
      xhrQueue.splice(i, 1);
    }
  });

  window.hasOngoingAjaxCalls = function () {
    for (let i = 0; i < xhrQueue.length; i++) {
      if (xhrQueue[i].readyState !== 4) {
        return true;
      }
    }
    return false;
  };

  window.execAfterAjaxCallsDone = function (callback) {
    if (window.hasOngoingAjaxCalls()) {
      setTimeout(function () {
        window.execAfterAjaxCallsDone(callback);
      }, 500);
      return;
    }
    setTimeout(callback, 1000);
  };

  afterEach(function () {
    for (let i = 0; i < xhrQueue.length; i++) {
      if(xhrQueue[i].readyState !== 4) {
        const {url, data} = xhrQueue[i].settings || {};
        console.warn('Aborting unfinished AJAX request with status ' + xhrQueue[i].readyState
          + ': ' + (url ? url : undefined) + `${data ? `: ${data}` : ''}`);
        xhrQueue[i].abort();
      }
    }
    xhrQueue.splice(0, xhrQueue.length);
  });

});
