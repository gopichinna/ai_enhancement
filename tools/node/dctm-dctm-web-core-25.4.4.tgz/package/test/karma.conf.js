'use strict';

module.exports = function (config) {
  const
    {setConfig, isDebugMode} = require('./karma.base.conf'),
    isDebug = isDebugMode(config),
    {dctmKarmaConf={}} = config,
    {files: optFiles=[]} = dctmKarmaConf;
  
  dctmKarmaConf.bundlesToTest = ['dctmw-all', 'dctmw-test'];
  
  dctmKarmaConf.client = {
    requireJsConfig: {
      paths: {
        "extModule1": "/base/src/testModules/ext1",
        "extModule2": "/base/src/testModules/ext2",
        "extModule3": "/base/src/testModules/ext3"
      },
      config: {
        'dctmw/models/module.collection': {
          moduleOrder: {
            extModule1: 1,
            extModule2: 2,
            extModule3: 3
          },
          'modules': {
            extModule2: {
              title: 'Module Two',
              version: '1.2'
            },
            extModule1: {
              title: 'Module One',
              version: '1.0'
            },
            extModule3: {
              title: 'Module Three',
              version: '2.2'
            }
          }
        },
        'dctmw/utils/landingpage/default.widget.types.map': {
          'extensions': {
            'tst': [
              'dctmw/test/test.default.widget.types.data'
            ]
          }
        },
        'dctmw/utils/perspectives/app.scope.perspectives': {
          'extensions': {
            'tst': [
              'dctmw/test/test.app.scope.perspectives.data'
            ]
          }
        }
      }
    }
  };
  
  if(isDebug) {
    dctmKarmaConf.files = [
      {pattern: 'lib/src/dctmw/test/*.?(mock|data).js', included: false, nocache: true},
      {pattern: 'lib/src/esoc/**/*.js', included: false, nocache: true},
      {pattern: 'src/testModules/**/*.*', included: false, nocache: true},
      ...optFiles
    ];
  } else {
    dctmKarmaConf.files = [
      `lib/release/esoc/bundles/esoc-all.js`
    ];
  }
  
  config.dctmKarmaConf = dctmKarmaConf;
  setConfig(config);
};
