'use strict';

const
  environment = process.env,
  which = require('which'),
  {resolve, join} = require('path'),
  {existsSync, readdirSync} = require('fs-extra'),
  { createKarmaPreprocessors } = require('@smartui/grunt-support/test'),
  isDocker = require('is-docker')(),
  generateCoberturaReport = environment.COBERTURA_REPORT === 'true';

if (process.platform === 'linux') {
  try {
    which.sync('google-chrome-unstable');
  } catch (error) {
    try {
      environment.CHROME_CANARY_BIN = which.sync('google-chrome-beta');
    } catch (error) {
    }
  }
}

let browsers = environment.KARMA_BROWSERS || (isDocker ? 'ChromeHeadlessNoSandbox' : 'ChromeHeadless');
if (browsers === 'ALL') {
  switch (process.platform) {
    case 'darwin':
      browsers = ['Chrome', 'Firefox', 'Safari'];
      break;
    case 'linux':
      browsers = ['Chrome', 'Firefox'];
      break;
    case 'win32':
      browsers = ['Chrome', 'Edge', 'Firefox', 'IE'];
      break;
    default:
      throw new Error(`Unrecognized OS platform: ${process.platform}`);
  }
} else {
  browsers = browsers.split(',');
}

const singleRun = environment.KARMA_SINGLERUN !== 'false';

const colors = environment.KARMA_COLORS !== 'false';

const symbols = environment.KARMA_SYMBOLS !== 'false' ? undefined : {
  success: '+',
  info: '#',
  warning: '?',
  error: '!'
};

const specPatterns = process.argv.length ? (()=>{
  const patterns = process.argv.find(a => a.indexOf('--spec-patterns=') === 0);
  if(patterns) {
    return patterns.substring(16).split(',');
  }
  return ['**/test/*.spec.js'];
})() : ['**/test/*.spec.js'];

const srcSpecPatterns = specPatterns.map(pat => ({pattern: `src/${pat}`, included: false, nocache: false}));

function setConfig(config) {
  const
    isDebug = isDebugMode(config),
    {dctmKarmaConf={}} = config,
    {
      client: optClient={},
      preprocessors: optPreprocessors,
      reporters: optReporters=[],
      files: optFiles=[],
      basePath: optBasePath='..',
      frameworks: optFrameworks=[],
      browserNoActivityTimeout: optBrowserNoActivityTimeout=60000,
      port: optPort=9876,
      browsers: optBrowsers=[],
      htmlReporter: optHtmlReporter,
      coverageReporter: optCoverageReporter,
      bundlesToTest: optBundlesToTest=[],
      customLaunchers: optCustomLaunchers,
      singleRun: optSingleRun
    } = dctmKarmaConf,
    isSingleRun = (typeof optSingleRun === 'boolean' ? optSingleRun : singleRun);
  
  const
    projDir = resolve(optBasePath),
    isRunningAsMainProject = existsSync(join(projDir, 'test/karma.base.conf.js')),
    svfHelperModulePath = '@dctm/dctm-web-tools/utils/svf.helper',
    localSVFHelperModulePath = isRunningAsMainProject ? svfHelperModulePath : join(projDir, 'node_modules', svfHelperModulePath),
    launchConfig = require(localSVFHelperModulePath).getLaunchConfig(),
    {packages: svfPackages} = launchConfig,
    addlSvfPackages = svfPackages ? Object.keys(svfPackages) : [],
    relCoreProjDir = 'node_modules/@dctm/dctm-web-core',
    commonDirPrefix = `${isRunningAsMainProject ? '' : `${relCoreProjDir}/`}`,
    {svf: {name: svfName}} = require(join(projDir, 'package.json'));
  
  if(!optBundlesToTest.length) {
    readdirSync(join(projDir, 'src/bundles'), {withFileTypes: true}).forEach(entry => {
      if(entry.isFile() && entry.name.endsWith('.js') && entry.name.startsWith(svfName)) {
        optBundlesToTest.push(entry.name.substring(0, entry.name.length - 3));
      }
    });
  }
  
  launchConfig.packageUnderTest = svfName;
  launchConfig.bundlesUnderTest = optBundlesToTest;
  if(isDebug && svfPackages) {
    for(const k in Object.keys(svfPackages)) {
      if(k === svfName) {
        svfPackages[k]['basePath'] = '/src';
      }
    }
  }
  
  const logLevel = config['LOG_' + (environment.KARMA_LOGLEVEL || 'INFO')];
  
  let reporters = environment.KARMA_REPORTERS || ('mocha,html' + (isDebug && isSingleRun === true ? ',coverage' : ''));
  reporters = [...reporters.split(','), ...optReporters];
  
  const mandatoryPreprocessor = {};
  mandatoryPreprocessor[`lib/src/${svfName}/!(bundles|test|lib|overrides)/**/!(test)/*.js`] = ['coverage'];
  mandatoryPreprocessor[`lib/src/${svfName}/!(bundles|test|lib|overrides)/*.js`] = ['coverage'];
  
  const preprocessors = reporters.indexOf('coverage') < 0 ? {...optPreprocessors} : {
    ...mandatoryPreprocessor,
    ...optPreprocessors
  };
  
  let files;
  if (isDebug) {
    const addlFiles = addlSvfPackages.length ? [
      {pattern: `lib/src/?(${addlSvfPackages.join('|')})/*.js`, included: false, nocache: false},
      {pattern: `lib/src/?(${addlSvfPackages.join('|')})/**/!(test)/*.js`, included: false, nocache: false},
      //{pattern: `lib/src/?(${addlSvfPackages.join('|')})/**/test/*!(.spec).js`, included: false, nocache: false},
      {pattern: `lib/src/?(${addlSvfPackages.join('|')})/**/test/*.mock.js`, included: false, nocache: false},
      {pattern: `lib/src/?(${addlSvfPackages.join('|')})/**/*.?(json|hbs|html|css|txt|svg|ttf|woff|woff2)`, included: false, nocache: true}
    ] : [];
    files = [
      'lib/src/nuc/lib/require.js',
      'lib/src/nuc/config.js',
      `${commonDirPrefix}test/test.require.config.js`,
      {pattern: `${commonDirPrefix}test/common.spec.js`, included: false, nocache: true},
      `${commonDirPrefix}pages/config.js`,
      `${commonDirPrefix}pages/*.html`,
      'node_modules/karma-requirejs/lib/adapter.js',
      {pattern: `${commonDirPrefix}lib/src/dctmw/utils/load-extensions/load-extensions.js`, included: false, nocache: false},
      {pattern: 'src/**/test/*.?(mock|common|data|datamanager).js', included: false, nocache: true},
      {pattern: 'src/**/test/*.?(json|hbs|html|css|txt)', included: false, nocache: true},
      {pattern: 'lib/src/?(dctmw|nuc|csui|esoc)/**/!(test)/*.js', included: false, nocache: false},
      {pattern: 'lib/src/smart/bundles/otwc/icons_action.js', included: true, nocache: true},
      {pattern: 'lib/src/smart/!(bundles|test)/**/*.js', included: false, nocache: false},
      {pattern: 'lib/src/smart/bundles/otwc/*.?(js|json|css)', included: false, nocache: false},
      ...optFiles,
      ...addlFiles,
      {pattern: 'lib/src/?(dctmw|nuc|smart|csui|esoc)/**/*.?(json|hbs|html|css|txt|svg|ttf|woff|woff2)', included: false, nocache: true},
      ...srcSpecPatterns
    ];
  } else {
    const compiledCodeMode = 'release';
    const addlRelFiles = addlSvfPackages.length ? [
      {pattern: `lib/${compiledCodeMode}/?(${addlSvfPackages.join('|')})/**/*.?(js|map|css|json|svg|ttf|woff|woff2)`, included: false, nocache: true}
    ] : [];
    files = [
      `lib/${compiledCodeMode}/nuc/bundles/nuc-loader.js`,
      `lib/${compiledCodeMode}/nuc/bundles/nuc-index.js`,
      `lib/${compiledCodeMode}/smart/bundles/smart-index.js`,
      `lib/${compiledCodeMode}/smart/bundles/otwc/icons_action.js`,
      `lib/${compiledCodeMode}/csui/bundles/csui-app-index.js`,
      `lib/${compiledCodeMode}/esoc/bundles/esoc-index.js`,
      `lib/${compiledCodeMode}/dctmw/bundles/dctmw-index.js`,
      `lib/${compiledCodeMode}/dctmw/bundles/dctmw-all.js`,
      `${commonDirPrefix}test/test.require.config.js`,
      {pattern: `${commonDirPrefix}test/common.spec.js`, included: false, nocache: true},
      `${commonDirPrefix}pages/config.js`,
      `${commonDirPrefix}pages/*.html`,
      'node_modules/karma-requirejs/lib/adapter.js',
      {pattern: 'src/**/test/*.?(json|hbs|html|css|txt)', included: false, nocache: true},
      {pattern: 'src/**/test/*.?(mock|common|data|datamanager).js', included: false, nocache: true},
      ...optFiles,
      ...addlRelFiles,
      {pattern: `lib/${compiledCodeMode}/?(dctmw|nuc|smart|csui|esoc)/**/*.?(js|map|css|json|svg|ttf|woff|woff2)`, included: false, nocache: true},
      ...srcSpecPatterns
    ];
  }
  
  let defaultSettings = isDebug ? createKarmaPreprocessors({
    srcDir: '../src',
    preprocessors,
    verbose: (logLevel === config.LOG_DEBUG)
  }) : {}, {jasmine: jasmineClientConf = {random: false}} = optClient;

  Object.assign(defaultSettings, {
    basePath: optBasePath || '..',
    
    frameworks: ['jasmine', ...optFrameworks],
    
    client: {
      dctmLaunchConfig: launchConfig,
      logLevel: logLevel,
      jasmine: jasmineClientConf,
      ...optClient
    },
    
    customLaunchers: {
      ChromeHeadlessNoSandbox: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox']
      },
      ChromeHeadlessCustom: {
        base: 'ChromeHeadless',
        flags: ['--disable-gpu', '--no-sandbox']
      },
      ...optCustomLaunchers
    },
    
    mochaReporter: {
      symbols: symbols
    },
    
    /*browserDisconnectTimeout: 3000,*/
    /*browserDisconnectTolerance: 3,*/
    browserNoActivityTimeout: optBrowserNoActivityTimeout,
    
    port: optPort,
    
    logLevel: logLevel,
    
    colors: colors,
    
    autoWatch: (isSingleRun === false),
    
    browsers: optBrowsers.length ? optBrowsers : browsers,
    
    singleRun: isSingleRun,
    
    files: files,
    
    reporters: reporters,
    
    htmlReporter: {
      outputDir: `../out-test/${isDebug ? 'debug' : 'release'}/results`,
      ...optHtmlReporter
    }
  });
  
  if (isDebug) {
    const testReporters = [{
      type: 'html',
      subdir: function (browser) {
        return browser.toLowerCase().split(/[ /-]/)[0];
      },
      watermarks: {
        // higher than default for statements/lines
        statements: [50, 90],
        lines: [50, 90],
        functions: [50, 90],
        branches: [50, 90]
      }
    }, {
      type: 'json-summary',
      subdir: '.'
    }, {
      type: 'text-summary'
    }];
    
    if(generateCoberturaReport) {
      testReporters.push({type: 'cobertura', subdir: '.'});
    }
    
    defaultSettings.coverageReporter = {
      dir: 'out-test/debug/coverage',
      reporters: testReporters,
      instrumenterOptions: {
        istanbul: {noCompact: false}
      },
      ...optCoverageReporter
    };
  }

  config.set({...config, ...defaultSettings});
}

function isDebugMode(config) {
  let isDebug = false, args = config.client.args;
  if (args) {
    isDebug = (args.indexOf('debug') >= 0);
  }
  return isDebug;
}

module.exports = {setConfig: setConfig, isDebugMode: isDebugMode};