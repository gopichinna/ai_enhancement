'use strict';

const chalk = require('chalk');
const https = require('https');
const AdmZip = require('adm-zip');
const fs = require('fs');
const { sync: rimrafSync } = require('rimraf');
const { getNonSVFPackages } = require('./svf.helper');
const { getSVFModuleVersionMap } = require('./svf.module.version.resolver');
const { readdirSync, copySync, ensureDirSync, pathExistsSync } = require('fs-extra');
const { join } = require('path');
const langMap = {
  ar: {
    svfLesLangKey: 'ARA',
    svfLesCoreKey: 'arabic',
    svfLangKey: 'ar'
  },
  de: {
    svfLesLangKey: 'GER',
    svfLesCoreKey: 'german',
    svfLangKey: 'de'
  },
  es: {
    svfLesLangKey: 'ESP',
    svfLesCoreKey: 'spanish',
    svfLangKey: 'es'
  },
  fr: {
    svfLesLangKey: 'FRA',
    svfLesCoreKey: 'french',
    svfLangKey: 'fr'
  },
  it: {
    svfLesLangKey: 'ITA',
    svfLesCoreKey: 'italian',
    svfLangKey: 'it'
  },
  iw: {
    svfLesLangKey: 'HEB',
    svfLesCoreKey: 'hebrew',
    svfLangKey: 'he'
  },
  ja: {
    svfLesLangKey: 'JPN',
    svfLesCoreKey: 'japanese',
    svfLangKey: 'ja'
  },
  ko: {
    svfLesLangKey: 'KOR',
    svfLesCoreKey: 'korean',
    svfLangKey: 'ko-kr'
  },
  nl: {
    svfLesLangKey: 'DUT',
    svfLesCoreKey: 'dutch',
    svfLangKey: 'nl'
  },
  pt_BR: {
    svfLesLangKey: 'PTB',
    svfLesCoreKey: 'portuguese',
    svfLangKey: 'pt',
    dctmSVLangKey: 'pt'
  },
  ru: {
    svfLesLangKey: 'RUS',
    svfLesCoreKey: 'russian',
    svfLangKey: 'ru-ru'
  },
  sv: {
    svfLesLangKey: 'SWE',
    svfLesCoreKey: 'swedish',
    svfLangKey: 'sv'
  },
  zh: {
    svfLesLangKey: 'CHT',
    svfLesCoreKey: 'traditional_chinese',
    svfLangKey: 'zh-tw'
  }
};
const artifactoryLangRoot = 'https://artifactory.opentext.net/artifactory/OT/released/comp';

function validateAndResolveLangCodes (lpBundleLangCodes) {
  if (lpBundleLangCodes.length === 0) {
    return;
  }
  const allLangCodes = Object.keys(langMap);
  if (lpBundleLangCodes.length === 1 && lpBundleLangCodes[0] === 'ALL') {
    lpBundleLangCodes = allLangCodes;
  }

  const mismatchLang = Array.prototype.filter.call(lpBundleLangCodes, (lang) => {
    return (Array.prototype.indexOf.call(allLangCodes, lang) === -1);
  });

  if (mismatchLang.length > 0) {
    throw new Error(`Unsupported language code provisioned: ${chalk.redBright(mismatchLang)}".`);
  }
  return lpBundleLangCodes;
}

// Utility functions to Prepare LP bundle as per SVF Structure
function prepareLocalizationBundle (options) {
  let { lpBundleLangCodes = [] } = options;
  const { refDirRoot = process.cwd(), verbose = false } = options;
  const rootLangPath = join(refDirRoot, 'lang');
  const langArtiPath = join(refDirRoot, 'artifacts');
  const langArtiLangPath = join(langArtiPath, 'lang');
  const localizationPath = join(refDirRoot, 'localization');
  const nodeModuleRootPath = join(refDirRoot, 'node_modules');
  let { svfModuleVersionMap } = options;

  if (!svfModuleVersionMap) {
    svfModuleVersionMap = getSVFModuleVersionMap(options);
  }
  const generateLocalization = async function () {
    const resolvedLangCodes = validateAndResolveLangCodes(lpBundleLangCodes);
    if (!resolvedLangCodes) {
      console.log('Prepare Localization Bundle task skipped.');
      return;
    }
    lpBundleLangCodes = resolvedLangCodes;

    console.log(`Preparing LP bundle for language codes: ${chalk.greenBright(lpBundleLangCodes)}`);
    rimrafSync(rootLangPath);
    await generateSVFLocalization();
    await generateDCTMSVLocalization();
    console.log(`Prepared LP bundle for language codes: ${chalk.greenBright(lpBundleLangCodes)}`);
  };

  const generateSVFLocalization = function () {
    return new Promise(function (resolve, reject) {
      rimrafSync(langArtiPath);
      ensureDirSync(langArtiLangPath);
      downloadSVFLocalizationBundleFromArtifactory().then(() => {
        extractSVFLocalizationBundle();
        generateLangBundleForSVF();
        rimrafSync(langArtiPath);
        resolve();
      }).catch(reject);
    });
  };

  const downloadSVFLocalizationBundleFromArtifactory = async function () {
    await downloadSVFWebLocalizationBundleFromArtifactory();
    await downloadSVFMobLocalizationBundleFromArtifactory();
  };

  const downloadSVFWebLocalizationBundleFromArtifactory = async function () {
    let promise = Promise.resolve();
    lpBundleLangCodes.forEach((lang) => {
      promise = promise.then(() => downloadSVFLocalizationBundleForLang(lang));
    });
    return promise;
  };

  const downloadSVFMobLocalizationBundleFromArtifactory = async function () {
    const csMobVersion = svfModuleVersionMap['mobile'].relVersion;
    const langArtiUrl = `${artifactoryLangRoot}/cs.core.ui.mobile/${csMobVersion}/MSWin32/obj.zip`;
    const langArtiFilePath = join(langArtiLangPath, 'svf-mob-lang.zip');
    verbose && console.log(`Downloading SVF Mobile LP Bundle URL: ${chalk.greenBright(langArtiUrl)}`);
    await downloadSVFBundle(langArtiUrl, langArtiFilePath, 'csmob');
  };

  const downloadSVFLocalizationBundleForLang = async function (lang) {
    const lesCoreKey = langMap[lang].svfLesCoreKey;
    const lesLangKey = langMap[lang].svfLesLangKey;
    const csuiVersion = svfModuleVersionMap['csui'].relVersion;
    const langArtiUrl = `${artifactoryLangRoot}/les.core.${lesCoreKey}/${csuiVersion}/MSWin32_64/dist/LES_LANG_${lesLangKey}.zip`;
    const langArtiFilePath = join(langArtiLangPath, `svf-lang-${lang}.zip`);

    await downloadSVFBundle(langArtiUrl, langArtiFilePath, lang);
  };

  const downloadSVFBundle = function (langArtiUrl, langArtiFilePath, key) {
    return new Promise(function (resolve, reject) {
      verbose && console.log(`Downloading SVF LP bundle for ${chalk.greenBright(key)}`);
      verbose && console.log(`SVF LP Bundle URL: ${chalk.greenBright(langArtiUrl)}`);

      https.get(langArtiUrl).on('response', function (res) {
        if (res.statusCode === 200) {
          const totalBytes = parseInt(res.headers['content-length'], 10);
          const fileStream = fs.createWriteStream(langArtiFilePath);
          let receivedBytes = 0;
          res.pipe(fileStream);
          fileStream.on('finish', () => {
            fileStream.close();
            verbose && console.log(`Downloaded SVF LP bundle for ${chalk.greenBright(key)}`);
            resolve();
          });
          fileStream.on('error', () => {
            fileStream.close();
            reject(new Error(`SVF LP bundle download failed for ${chalk.redBright(key)} from ${chalk.redBright(langArtiUrl)}`));
          });
          res.on('data', function (chunk) {
            receivedBytes += chunk.length;
            const percentage = Math.round((receivedBytes * 100) / totalBytes);
            verbose && console.log(`${chalk.greenBright(key)}: Downloaded ${receivedBytes} bytes out of ${totalBytes} bytes (${percentage} %).`);
          });
        } else {
          reject(new Error(`SVF LP Bundle Download failed for ${chalk.redBright(key)} from ${chalk.redBright(langArtiUrl)}`));
        }
      });
    });
  };

  const extractBundleZip = function (path) {
    const zipPath = `${path}.zip`;
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(path, true);
  };

  const extractSVFLocalizationBundle = function () {
    lpBundleLangCodes.forEach((lang) => {
      verbose && console.log(`Extract SVF LP bundle for language code ${chalk.greenBright(lang)}`);
      const zipPath = join(langArtiLangPath, `svf-lang-${lang}`);
      extractBundleZip(zipPath);
    });

    verbose && console.log('Extract SVF Mob LP bundle for language code');
    // Extracts Level 1 Zip obj.zip
    const l1ZipPath = join(langArtiLangPath, 'svf-mob-lang');
    extractBundleZip(l1ZipPath);
    // Extracts Level 2 Zip mobile-release.zip
    const l2ZipPath = join(l1ZipPath, 'mobile-release');
    extractBundleZip(l2ZipPath);
    // Extracts Level 3 Zip mobile-release.zip
    const l3ZipPath = join(l2ZipPath, 'mobile');
    extractBundleZip(l3ZipPath);
  };

  const generateLangBundleForSVF = function () {
    lpBundleLangCodes.forEach((lang) => {
      const lesLangKey = langMap[lang].svfLesLangKey;
      const extractedLangPath = join(langArtiLangPath, `svf-lang-${lang}`);
      const extractedLangRootPath = join(extractedLangPath, `internal/SRCDIR/pkg/LES_LANG_${lesLangKey}/lang_overlay/support`);
      const svfLangKey = langMap[lang].svfLangKey;
      const dctmSVLangKey = langMap[lang].dctmSVLangKey || lang;

      const nucSource = `${extractedLangRootPath}/csui/nucleus/bundles/nls/${svfLangKey}`;
      const smartSource = `${extractedLangRootPath}/csui/smart/bundles/nls/${svfLangKey}`;
      const csuiSource = `${extractedLangRootPath}/csui/bundles/nls/${svfLangKey}`;
      const esocSource = `${extractedLangRootPath}/socialfeed/app/bundles/nls/${svfLangKey}`;
      const csmobSource = join(langArtiLangPath, 'svf-mob-lang', 'mobile-release', 'mobile', 'mobile', 'bundles', 'nls');
      const nucTarget = `${rootLangPath}/nuc/bundles/nls/${dctmSVLangKey}`;
      const smartTarget = `${rootLangPath}/smart/bundles/nls/${dctmSVLangKey}`;
      const csuiTarget = `${rootLangPath}/csui/bundles/nls/${dctmSVLangKey}`;
      const esocTarget = `${rootLangPath}/esoc/bundles/nls/${dctmSVLangKey}`;
      const csmobTarget = `${rootLangPath}/mobile/bundles/nls/${dctmSVLangKey}`;

      // Copy SVF language bundle to root lang folder.
      copySync(nucSource, nucTarget, { overwrite: true });
      copySync(smartSource, smartTarget, { overwrite: true });
      copySync(csuiSource, csuiTarget, { overwrite: true });
      copySync(esocSource, esocTarget, { overwrite: true });
      copySync(csmobSource, csmobTarget, { overwrite: true });

      // Replacing dctmSVLang key from svfLangKey
      if (svfLangKey !== dctmSVLangKey) {
        replaceLangKeyInSvfLangBundle(nucTarget, svfLangKey, dctmSVLangKey);
        replaceLangKeyInSvfLangBundle(smartTarget, svfLangKey, dctmSVLangKey);
        replaceLangKeyInSvfLangBundle(csuiTarget, svfLangKey, dctmSVLangKey);
        replaceLangKeyInSvfLangBundle(esocTarget, svfLangKey, dctmSVLangKey);
        replaceLangKeyInSvfLangBundle(csmobSource, svfLangKey, dctmSVLangKey);
      }

      verbose && console.log(`Generated LP bundle for SVF Framework language code ${chalk.greenBright(lang)}`);
    });
  };

  const replaceLangKeyInSvfLangBundle = function (bundlePath, svfLangKey, dctmSVLangKey) {
    verbose && console.log(`Replacing lang key (${chalk.greenBright(svfLangKey)} ==> ${chalk.greenBright(dctmSVLangKey)}) in SVF bundle ${chalk.greenBright(bundlePath)}`);
    readdirSync(bundlePath, { withFileTypes: true }).forEach(dir => {
      if (dir.isFile()) {
        const filePath = join(bundlePath, dir.name);
        const fileContent = fs.readFileSync(filePath, { encoding: 'utf8' });
        const svfKeyRegex = new RegExp(`/nls/${svfLangKey}`, 'g');
        const updatedContent = fileContent.replace(svfKeyRegex, `/nls/${dctmSVLangKey}`);
        fs.writeFileSync(filePath, updatedContent, { encoding: 'utf8', overwrite: true });
      }
    });
  };

  const generateDCTMSVLocalization = function () {
    return new Promise(function (resolve, reject) {
      const nonSvfModules = getNonSVFPackages();
      const excludeLibModules = ['nuc', 'smart', 'csui', 'esoc', 'mobile', ...nonSvfModules];

      Object.keys(svfModuleVersionMap).forEach((moduleName) => {
        const moduleVersionData = svfModuleVersionMap[moduleName];
        const nodeModuleName = moduleVersionData.moduleName;

        if (Array.prototype.indexOf.call(excludeLibModules, moduleName) === -1) {
          lpBundleLangCodes.forEach((lang) => {
            const dctmSVLangKey = langMap[lang].dctmSVLangKey || lang;
            const moduleLocalizationPath = (moduleVersionData.origModule === true) ? `${localizationPath}/${lang}` : `${nodeModuleRootPath}/${nodeModuleName}/localization/${lang}`;
            if (pathExistsSync(moduleLocalizationPath) === false) {
              reject(new Error(`Language ${chalk.redBright(lang)} is not available in ${chalk.redBright(moduleName)}.`));
            }
            copySync(moduleLocalizationPath, `${rootLangPath}/${moduleName}/bundles/nls/${dctmSVLangKey}`, { overwrite: true });
            verbose && console.log(`Generated LP bundle DCTM SV Module ${chalk.greenBright(moduleName)} for lang: ${chalk.greenBright(lang)}`);
          });
        }
      });
      resolve();
    });
  };

  return new Promise(function (resolve, reject) {
    generateLocalization().then(resolve).catch((error) => {
      rimrafSync(rootLangPath);
      rimrafSync(langArtiPath);
      reject(error);
    });
  });
}

// Utility functions to Finalize LP bundle
function finalizeLocalizationBundle (options) {
  let { lpBundleLangCodes = [] } = options;
  const { refDirRoot = process.cwd() } = options;
  const rootLangPath = join(refDirRoot, 'lang');
  const distPublicPath = join(refDirRoot, 'dist/app/public');
  const distUIBundlePath = join(distPublicPath, 'ui');
  const distUIDebugBundlePath = join(distPublicPath, 'ui-debug');
  const resolvedLangCodes = validateAndResolveLangCodes(lpBundleLangCodes);
  if (!resolvedLangCodes) {
    console.log('Finalize Localization Bundle task is skipped.');
    return;
  }
  lpBundleLangCodes = resolvedLangCodes;
  console.log(`Finalizing LP bundle for language codes: ${chalk.greenBright(lpBundleLangCodes)}`);

  readdirSync(rootLangPath, { withFileTypes: true }).forEach(dir => {
    const dirName = dir.name;
    if ((dir.isDirectory() || dir.isSymbolicLink()) && dirName !== '.builds') {
      lpBundleLangCodes.forEach((lang) => {
        const dctmSVLangKey = langMap[lang].dctmSVLangKey || lang;

        copySync(`${rootLangPath}/${dirName}/bundles/nls/${dctmSVLangKey}`, `${distUIBundlePath}/${dirName}/bundles/nls/${dctmSVLangKey}`, { overwrite: true });
        copySync(`${rootLangPath}/${dirName}/bundles/nls/${dctmSVLangKey}`, `${distUIDebugBundlePath}/${dirName}/bundles/nls/${dctmSVLangKey}`, { overwrite: true });
      });
    }
  });
  rimrafSync(rootLangPath);
  console.log(`Finalized LP bundle for language codes: ${chalk.greenBright(lpBundleLangCodes)}`);
}

module.exports = {
  prepareLocalizationBundle,
  finalizeLocalizationBundle
};
