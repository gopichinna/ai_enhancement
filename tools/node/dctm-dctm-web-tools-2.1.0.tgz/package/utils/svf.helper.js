'use strict';

const { join: pathJoin } = require('path');
const { existsSync, readdirSync } = require('fs-extra');
const _ = require('underscore');
const projDir = require('./dir.util').getProjectDirectory();
const { version: pkgVersion, svf: { name: svfName } } = require(pathJoin(projDir, 'package.json'));
const PATTERN_VERSION = /\d+\.\d+\.\d+/;
let normalizedVersion;
const nonSVFPkgs = [];
const completeDependencies = [];
const immediateDependencies = [];
let generatedLaunchConfig = {};

(function discoverPackages () {
  const origLaunchConfigPath = pathJoin(projDir, 'launcher.json');
  if (existsSync(origLaunchConfigPath)) {
    const origLaunchConfig = require(origLaunchConfigPath);
    generatedLaunchConfig = { ...origLaunchConfig };
  }

  const pkgMap = {};
  const srcDirPath = pathJoin(projDir, 'lib/src');

  readdirSync(srcDirPath, { withFileTypes: true }).forEach(d => {
    if (d.isDirectory() || d.isSymbolicLink()) {
      const componentPath = pathJoin(srcDirPath, d.name, 'component.js');
      const initScriptName = `${d.name}-init.js`;
      const initScriptPath = pathJoin(srcDirPath, d.name, initScriptName);
      if (existsSync(componentPath)) {
        const compJs = require(componentPath);
        pkgMap[d.name] = { dependencies: _.isFunction(compJs.getSVFDependencies) ? compJs.getSVFDependencies() : [] };
        if (existsSync(initScriptPath)) {
          pkgMap[d.name]['initScript'] = initScriptName;
        }
      } else {
        nonSVFPkgs.push(d.name);
      }
    }
  });

  // apply ranking
  let presentRank = 0;
  const deps = [];

  if (svfName && pkgMap[svfName]) {
    pkgMap[svfName].rank = presentRank;
    const nDeps = [...pkgMap[svfName].dependencies].reverse();
    Array.prototype.push.apply(deps, nDeps);
    Array.prototype.push.apply(immediateDependencies, pkgMap[svfName].dependencies);
  } else {
    Array.prototype.push.apply(deps, Object.keys(pkgMap));
  }

  while (deps.length !== 0) {
    const dep = deps.shift();
    pkgMap[dep].rank = --presentRank;
    if (pkgMap[dep]) {
      const nDeps = [...pkgMap[dep].dependencies].reverse();
      Array.prototype.push.apply(deps, nDeps);
    }
  }

  const svfPkgs = Object.keys(pkgMap)
    .filter(k => pkgMap[k].rank !== undefined)
    .sort((a, b) => {
      return pkgMap[a].rank - pkgMap[b].rank;
    });

  Array.prototype.push.apply(completeDependencies, (svfName && pkgMap[svfName]) ? svfPkgs.slice(0, svfPkgs.length - 1) : svfPkgs);

  const addlIndex = svfPkgs.indexOf('dctmw');
  if (addlIndex < 0) {
    throw new Error('Not using DCTM SVF framework');
  }

  generatedLaunchConfig.version = getVersion();
  const addlPackages = {};
  let order = 0;
  for (let i = addlIndex + 1; i < svfPkgs.length; i++) {
    const pkg = svfPkgs[i];
    const pkgDescriptor = { order: ++order };
    if (pkgMap[pkg].initScript) {
      pkgDescriptor.initScript = pkgMap[pkg].initScript;
    }
    addlPackages[pkg] = pkgDescriptor;
  }
  generatedLaunchConfig.packages = addlPackages;
})();

function getLaunchConfig () {
  return generatedLaunchConfig;
}

function getNonSVFPackages () {
  return [...nonSVFPkgs];
}

function getCompleteSVFDependencies () {
  return [...completeDependencies];
}

function getImmediateSVFDependencies () {
  return [...immediateDependencies];
}

function getVersion () {
  if (normalizedVersion) {
    return normalizedVersion;
  }

  const match = pkgVersion.match(PATTERN_VERSION);

  if (!match) {
    throw new Error(`Unconventional package version : ${pkgVersion}, semvar compatible version is expected.`);
  }

  normalizedVersion = match[0];
  return normalizedVersion;
}

module.exports = {
  getVersion,
  getLaunchConfig,
  getNonSVFPackages,
  getImmediateSVFDependencies,
  getCompleteSVFDependencies
};
