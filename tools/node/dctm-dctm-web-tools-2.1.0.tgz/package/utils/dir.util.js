'use strict';

const { dirname, normalize, join: pathJoin } = require('path');
const { existsSync } = require('fs-extra');
let projectDir;

function getProjectDirectoryInternal () {
  if (process.env['npm_package_json']) {
    return dirname(process.env['npm_package_json']);
  }

  let scanPath = normalize(process.cwd());
  while (scanPath) {
    if (existsSync(pathJoin(scanPath, 'package.json'))) {
      return scanPath;
    }
    const pDir = dirname(scanPath);
    scanPath = (pDir === scanPath) ? null : pDir;
  }

  throw new Error('Not running in context of NPM project');
}

function getProjectDirectory () {
  if (projectDir === undefined) {
    projectDir = getProjectDirectoryInternal();
  }

  return projectDir;
}

module.exports = {
  getProjectDirectory
};
