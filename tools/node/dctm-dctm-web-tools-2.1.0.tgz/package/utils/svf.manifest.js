'use strict';

const chalk = require('chalk');
const { join, resolve } = require('path');
const { outputJsonSync, readdirSync, ensureDirSync } = require('fs-extra');
const { getSVFModuleVersionMap } = require('./svf.module.version.resolver');

const UNKNOWN_VERSION = 'unknown';

function createManifest (options = {}) {
  const { refDirRoot = process.cwd(), outputDir = process.cwd(), excludedPackages = [], verbose = false } = options;
  let { svfModuleVersionMap } = options;

  if (!svfModuleVersionMap) {
    svfModuleVersionMap = getSVFModuleVersionMap(options);
  }
  if (verbose) {
    console.log(`Processing root directory: ${chalk.cyanBright(resolve(refDirRoot))}`);
    console.log(`Output directory: ${chalk.cyanBright(resolve(outputDir))}`);
    console.log(`Packages to be excluded: ${chalk.cyanBright(excludedPackages)}`);
  }

  const exclusionList = ['csrviewer', 'igc', ...excludedPackages];
  const manifestContent = {};
  readdirSync(join(refDirRoot, 'lib/release'), { withFileTypes: true }).forEach(d => {
    if ((d.isDirectory() || d.isSymbolicLink()) && !exclusionList.includes(d.name)) {
      if (svfModuleVersionMap && svfModuleVersionMap[d.name] && svfModuleVersionMap[d.name].version) {
        manifestContent[d.name] = svfModuleVersionMap[d.name].version;
      } else {
        manifestContent[d.name] = UNKNOWN_VERSION;
      }
    }
  });

  const finalManifestContent = { builds: manifestContent };
  const manifestFilePath = join(outputDir, 'svf-manifest.json');
  ensureDirSync(outputDir);
  verbose && console.log(`Manifest content : ${chalk.greenBright(JSON.stringify(finalManifestContent, undefined, 2))}`);
  console.log(`Writing manifest to : ${chalk.cyanBright(manifestFilePath)}`);
  outputJsonSync(manifestFilePath, finalManifestContent, { spaces: 2 });
}

module.exports = {
  createManifest
};
