'use strict';

const chalk = require('chalk');
const { join, resolve } = require('path');
const { existsSync, readJsonSync, readdirSync, readFileSync } = require('fs-extra');
const propertiesReader = require('properties-reader');
const viewerBundle = ['csrviewer', 'igc'];
const UNKNOWN_VERSION = 'unknown';
const PATTERN_VERSION = /^\d+\.\d+\.\d+(-next\.\d+)*/;
const knownSVFModuleMap = {
  csui: { name: 'csui', type: 'static' },
  esoc: { name: 'esoc', type: 'static' },
  aie: { name: 'aie', type: 'static' },
  mobile: { name: 'mobile', type: 'static' },
  nuc: { name: '@smartui/nucleus', type: 'node' },
  smart: { name: '@smartui/smart-controls', type: 'node' },
  dctmw: { name: '@dctm/dctm-web-core', type: 'node' },
  d2: { name: '@dctm/dctm-web-d2', type: 'node' },
  d2mob: { name: '@dctm/dctm-web-d2-mobile', type: 'node' }
};

function getSVFModuleVersionMap (options = {}) {
  const { refDirRoot = process.cwd(), excludedPackages = [], verbose = false } = options;
  const appPkgJsonPath = join(refDirRoot, 'package.json');
  const exclusionList = [...viewerBundle, ...excludedPackages];
  const unresolvedPackages = [];
  let appPackageJson = {};
  const resolvedNodeModules = {};
  const svfModuleVersionMap = {};

  const resolveStaticModuleVersionData = function (moduleName) {
    const svfModuleVersionData = {};
    const versionFilePath = join(refDirRoot, `lib/.builds/${moduleName}.txt`);
    if (existsSync(versionFilePath)) {
      const versionFileContent = readFileSync(versionFilePath, { encoding: 'utf8' });
      const properties = propertiesReader().read(versionFileContent);
      svfModuleVersionData.version = properties.get('build');
      svfModuleVersionData.relVersion = properties.get('version');
      if (!svfModuleVersionData.version && !svfModuleVersionData.relVersion) {
        const result = versionFileContent.match(PATTERN_VERSION);
        if (result && result.length > 0) {
          svfModuleVersionData.version = result[0];
          svfModuleVersionData.relVersion = result[0];
        } else {
          svfModuleVersionData.version = UNKNOWN_VERSION;
          svfModuleVersionData.relVersion = UNKNOWN_VERSION;
        }
      }
    } else {
      svfModuleVersionData.version = UNKNOWN_VERSION;
    }
    return svfModuleVersionData;
  };
  const resolveNodePackageJson = function (nodeModuleName) {
    const pJsonPath = join(refDirRoot, `node_modules/${nodeModuleName}/package.json`);
    if (existsSync(pJsonPath)) {
      return readJsonSync(pJsonPath);
    }
  };
  const resolveNodeModuleVersionData = function (pJson) {
    const svfModuleVersionData = {};
    if (pJson) {
      svfModuleVersionData.moduleName = pJson.name;
      svfModuleVersionData.version = pJson.version;
      resolvedNodeModules[pJson.name] = true;
    } else {
      svfModuleVersionData.version = UNKNOWN_VERSION;
    }
    return svfModuleVersionData;
  };
  const resolveNodeModuleDependencies = function (pJson) {
    let nodeModulesDependency = {};
    const { dependencies = {}, devDependencies = {}, peerDependencies = {} } = pJson;
    const allDeps = { ...dependencies, ...devDependencies, ...peerDependencies };
    Object.keys(allDeps).forEach(dep => {
      if (!resolvedNodeModules[dep]) {
        const depPJson = resolveNodePackageJson(dep);
        const svfName = depPJson?.svf?.name;
        if (svfName && Array.prototype.indexOf.call(unresolvedPackages, svfName) > -1) {
          nodeModulesDependency[svfName] = resolveNodeModuleVersionData(depPJson);
          const depNodeModuleDependency = resolveNodeModuleDependencies(depPJson);
          if (depNodeModuleDependency) {
            nodeModulesDependency = { ...nodeModulesDependency, ...depNodeModuleDependency };
          }
        }
      }
    });
    return nodeModulesDependency;
  };

  if (verbose) {
    console.log(`Processing root directory: ${chalk.cyanBright(resolve(refDirRoot))}`);
    console.log(`Packages to be excluded: ${chalk.cyanBright(excludedPackages)}`);
  }

  if (existsSync(appPkgJsonPath)) {
    appPackageJson = readJsonSync(appPkgJsonPath);
  } else {
    console.warn(`Missing root package.json at ${chalk.red(refDirRoot)}`);
  }

  readdirSync(join(refDirRoot, 'lib/release'), { withFileTypes: true }).forEach(d => {
    if ((d.isDirectory() || d.isSymbolicLink()) && !exclusionList.includes(d.name)) {
      if (d.name === appPackageJson?.svf?.name) {
        svfModuleVersionMap[d.name] = resolveNodeModuleVersionData(appPackageJson);
        svfModuleVersionMap[d.name].origModule = true;
      } else {
        const knownSVFModule = knownSVFModuleMap[d.name];
        if (knownSVFModule) {
          if (knownSVFModule.type === 'static') {
            svfModuleVersionMap[d.name] = resolveStaticModuleVersionData(knownSVFModule.name);
          } else {
            const pJson = resolveNodePackageJson(knownSVFModule.name);
            svfModuleVersionMap[d.name] = resolveNodeModuleVersionData(pJson);
          }
        } else {
          unresolvedPackages.push(d.name);
        }
      }
    }
  });

  if (unresolvedPackages.length > 0) {
    const nodeModulesDependencies = resolveNodeModuleDependencies(appPackageJson);
    unresolvedPackages.forEach(pkgName => {
      if (nodeModulesDependencies[pkgName]) {
        svfModuleVersionMap[pkgName] = nodeModulesDependencies[pkgName];
      } else {
        svfModuleVersionMap[pkgName] = UNKNOWN_VERSION;
      }
    });
  }
  return svfModuleVersionMap;
}

module.exports = {
  getSVFModuleVersionMap
};
