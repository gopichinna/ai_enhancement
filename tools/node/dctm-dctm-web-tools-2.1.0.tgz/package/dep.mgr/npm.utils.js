'use strict';

const { join } = require('path');
const chalk = require('chalk');
const REPOSITORY_URL = 'https://artifactory.opentext.net/artifactory/api/npm/npm_virt/';

function getNPMPackageMetadata ({ pkgName, debug }) {
  return import('node-fetch')
    .then(({ default: fetch }) => {
      debug && console.log(`Fetching metadata for ${chalk.cyan(pkgName)} from ${chalk.cyan(REPOSITORY_URL)}`);
      return fetch(join(REPOSITORY_URL, pkgName))
        .then(response => response.json());
    });
}

module.exports = { getNPMPackageMetadata };
