#!/usr/bin/env node

'use strict';

const { Command } = require('commander');
const program = new Command();
const removeDep = require('./dep.remove');

program
  .name('dctmw-dep-remove')
  .description('Remove a DCTM SVF dependency from current project')
  .version(require('../package.json').version)
  .option('-d, --debug', 'Output verbose logging')
  .argument('<pkgNames>', 'DCTM SVF package name of the dependency to be removed.')
  .action(async (pkgNames, opts) => {
    await removeDep({ pkgNames, debug: opts.debug, forceRemove: opts.force });
  });

program.parse();
