'use strict';

const chalk = require('chalk');
const { join: pathJoin } = require('path');
const { existsSync } = require('fs-extra');
const { execSync } = require('child_process');
const { getNPMPackageMetadata } = require('./npm.utils');

const knownRemotePackages = [
  '@dctm/dctm-web-core',
  '@dctm/dctm-web-d2',
  '@dctm/dctm-web-d2-mobile'
];

function getRemotePkgMeta (options = {}) {
  const svfPkgsKnownSoFar = [];
  return Promise
    .all(knownRemotePackages.map(pkgName => getNPMPackageMetadata({ pkgName, debug: options.debug })))
    .then((metadata) => {
      return metadata.map(pkgMeta => {
        const { name: npmName, versions, 'dist-tags': distTags } = pkgMeta;
        const { svf: { name: svfName, deps: svfDeps } } = versions[distTags.next];
        svfPkgsKnownSoFar.push(svfName);
        const resolves = svfDeps.filter(d => !svfPkgsKnownSoFar.includes(d));
        Array.prototype.push.apply(svfPkgsKnownSoFar, resolves);
        svfPkgsKnownSoFar.push(svfName);
        resolves.push(svfName);
        const pkg = {
          npmName,
          svfName,
          resolves
        };

        const nextTagValue = distTags.next || 'next';
        const nextMatch = Object.keys(distTags).find(k => (k !== 'next' && k.indexOf('next') > 0 && distTags[k] === nextTagValue));
        pkg.distTags = {
          dev: nextMatch || 'next',
          rel: distTags.latest
        };
        options.debug && console.log(`SVF PKG: ${chalk.cyan(JSON.stringify(pkg))}`);
        return pkg;
      });
    });
}

function getLocalPkgMeta (options = {}) {
  const { refDir, debug } = options;
  const selfPackageJson = require(pathJoin(refDir, 'package.json'));
  const selfNpmDependencies = { ...selfPackageJson.dependencies, ...selfPackageJson.devDependencies, ...selfPackageJson.peerDependencies };

  const allNpmDepsPresent = Object.keys(selfNpmDependencies).every(d => existsSync(pathJoin(refDir, 'node_modules', d)));
  if (!allNpmDepsPresent) {
    execSync('npm install', { stdio: 'inherit', cwd: refDir });
  }

  const directSvfNpmPackages = {};
  Object.keys(selfNpmDependencies).forEach(d => {
    if (existsSync(pathJoin(refDir, 'node_modules', d, 'src/component.js'))) {
      debug && console.log(`NPM package ${chalk.cyan(d)} is found as a direct SVF package.`);
      const { svf: { name: svfName, deps: svfDeps } } = require(pathJoin(refDir, 'node_modules', d, 'package.json'));
      directSvfNpmPackages[svfName] = {
        npmName: d,
        svfName,
        svfDeps
      };
    }
  });

  return Promise.resolve(directSvfNpmPackages);
}

module.exports = { getRemotePkgMeta, getLocalPkgMeta };
