#!/usr/bin/env node

'use strict';

const { Command } = require('commander');
const program = new Command();
const addDep = require('./dep.add');

program
  .name('dctmw-dep-add')
  .description('Add DCTM SVF packages as direct NPM dependencies to current project')
  .version(require('../package.json').version)
  .option('-d, --debug', 'Output verbose logging')
  .option('--save-dev', 'NPM dependencies to be added as devDependencies. Defaults to false, indicating addition as dependencies')
  .option('--release-only', 'Only add relesed version of dependencies. Defaults to false, indicating installation of present in-development version')
  .argument('[pkgNames...]', 'DCTM SVF package name of the dependency to be added. Supports space separated multiple values.')
  .action(async (pkgNames, opts) => {
    await addDep({ pkgNames, debug: opts.debug, saveDev: opts.saveDev, useRelease: opts.releaseOnly });
  });

program.parse();
