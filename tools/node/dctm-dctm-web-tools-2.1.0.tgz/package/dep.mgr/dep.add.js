'use strict';

const { join: pathJoin } = require('path');
const chalk = require('chalk');
const { outputJsonSync } = require('fs-extra');
const { execSync } = require('child_process');
const projDir = require('../utils/dir.util').getProjectDirectory();
const { getImmediateSVFDependencies, getCompleteSVFDependencies } = require('../utils/svf.helper');
const selfPackageJsonPath = pathJoin(projDir, 'package.json');

module.exports = async function (options = {}) {
  const selfPackageJson = require(selfPackageJsonPath);
  const { svf: { name: svfName } } = selfPackageJson;
  const { getRemotePkgMeta } = require('./known.pkg.map');
  const completeDependencies = getCompleteSVFDependencies();
  const immediateDependencies = getImmediateSVFDependencies();
  let { pkgNames, debug, saveDev, useRelease } = options;

  if (debug) {
    console.log(`Complete dependencies [${chalk.cyan(completeDependencies.length ? completeDependencies : 'none')}] at present`);
    console.log(`Immediate dependencies [${chalk.cyan(immediateDependencies.length ? immediateDependencies : 'none')}] at present`);
  }

  if (typeof pkgNames === 'string') {
    pkgNames = [pkgNames];
  }

  const filteredOutPackageNames = [];
  pkgNames = pkgNames.filter(pName => {
    if (pName === svfName) {
      console.log(chalk.red(`Can not add self(${svfName}) as a dependency`));
      return false;
    }

    if (completeDependencies.includes(pName)) {
      filteredOutPackageNames.push(pName);
      return false;
    }

    return true;
  });

  filteredOutPackageNames.length && console.log(`Ignored adding dependencies [${chalk.yellow(filteredOutPackageNames)}] as they are already available in project path`);

  if (pkgNames.length) {
    const pkgMap = {};
    const pkgMetadata = await getRemotePkgMeta({ debug });
    pkgMetadata.forEach(({ npmName, svfName, resolves, distTags }) => {
      resolves.forEach(r => {
        pkgMap[r] = { npmName, svfName, distTags };
      });
    });

    const resolvedNPMDeps = {};
    const resolvedPackages = [];
    const unresolvedPackages = [];
    pkgNames.forEach(svfPkgName => {
      const npmDep = pkgMap[svfPkgName];
      if (npmDep) {
        if (!resolvedPackages.includes(npmDep.svfName)) {
          resolvedPackages.push(npmDep.svfName);
        }
        resolvedNPMDeps[npmDep.npmName] = useRelease === true ? `^${npmDep.distTags.rel}` : npmDep.distTags.dev;
      } else {
        unresolvedPackages.push(svfPkgName);
      }
    });
    unresolvedPackages.length && console.log(`${chalk.yellow(`Can't add unknown SVF dependencies [${unresolvedPackages}]`)}`);
    debug && resolvedPackages.length && console.log(`SVF packages to add [${chalk.green(resolvedPackages)}] through NPM dependencies ${chalk.green(JSON.stringify(resolvedNPMDeps))}`);

    if (Object.keys(resolvedNPMDeps).length) {
      const selfSvf = selfPackageJson.svf;
      const deps = Array.isArray(selfSvf.deps) ? selfSvf.deps : [];
      selfSvf.deps = deps;
      Array.prototype.push.apply(deps, resolvedPackages);
      const packageDependencies = saveDev === true ? selfPackageJson.devDependencies : selfPackageJson.dependencies;
      Object.assign(packageDependencies, resolvedNPMDeps);
      selfPackageJson[saveDev === true ? 'devDependencies' : 'dependencies'] = packageDependencies;
      debug && console.log(`Final package.json ${chalk.green(JSON.stringify(selfPackageJson, undefined, 2))}`);

      console.log(`Updating ${chalk.cyan(selfPackageJsonPath)}`);
      outputJsonSync(selfPackageJsonPath, selfPackageJson, { spaces: 2 });

      console.log('Installing dependencies...');
      execSync('npm install', { stdio: 'inherit', cwd: projDir });
    }
  } else {
    console.log(chalk.yellow('No additional dependencies to be added'));
  }
};
