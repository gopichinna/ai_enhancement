# [2.1.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v2.0.0...v2.1.0) (2024-09-20)


### Bug Fixes

* [DTWO-120825](https://jira.opentext.com/browse/DTWO-120825): Updated the supported node engine version as 20 LTS. ([8b8d60a](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/8b8d60a745848c950156f957f6a262446059f0fe))



# [2.0.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.12.1...v2.0.0) (2024-07-18)


### Bug Fixes

* [DTWO-118513](https://jira.opentext.com/browse/DTWO-118513): Restoring the latest version of grunt support in dctm-web-tools. ([660e502](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/660e50260f67f3dd7be834d193c9dd02cc37f28d))



## [1.12.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.12.0...v1.12.1) (2024-07-18)


### Bug Fixes

* [DTWO-118506](https://jira.opentext.com/browse/DTWO-118506): Reverting grunt support to 3.x version in order to resolve unanticipated version compatibility problem. ([c5969f1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/c5969f15327ac32d09f9bb89ba4685d03519237d))



# [1.12.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.11.1...v1.12.0) (2024-07-05)


### Bug Fixes

* [DTWO-114882](https://jira.opentext.com/browse/DTWO-114882): Fixed manifest file generation issue for dependencies installed using csui-dependency-installer ([b65c1cb](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/b65c1cbf46b3d45b517efb60d24637a711187559))



## [1.11.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.11.0...v1.11.1) (2024-04-10)


### Bug Fixes

* [DTWO-114489](https://jira.opentext.com/browse/DTWO-114489): Application packer was not stamping service worker with version stamp ([5910e5d](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/5910e5db4a08efbe2447c1b43e08caa138901aee))



# [1.11.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.10.2...v1.11.0) (2023-09-08)


### Bug Fixes

* [DTWO-105739](https://jira.opentext.com/browse/DTWO-105739): Enable debug mode for node and minimal deployments ([db7b54b](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/db7b54b622aadfb06c5aedb84b89592eaa4c6e70))


### Features

* [DTWO-101410](https://jira.opentext.com/browse/DTWO-101410): DCTM SVF dependency manager ([f48e9f3](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/f48e9f3e1264c844de2e3fa8e40efe6e4ebf67df))



## [1.10.2](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.10.1...v1.10.2) (2023-08-21)


### Bug Fixes

* [DTWO-101412](https://jira.opentext.com/browse/DTWO-101412): Unranked packages are not to be considered in launch config generation - SDK usecase ([756f669](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/756f6697ae12d47301e52603cc4c9cfc7b1c7817))



## [1.10.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.10.0...v1.10.1) (2023-08-18)



# [1.10.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.9.0...v1.10.0) (2023-08-17)


### Features

* [DTWO-103903](https://jira.opentext.com/browse/DTWO-103903): Added automated LP builder for DCTM SV. ([77e7f73](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/77e7f73651b4546bf1815a8b00a441fc2ea3d8da))
* [DTWO-103903](https://jira.opentext.com/browse/DTWO-103903): Added automated LP builder for DCTM SV. Fixed DCTMSV LP Bundle. ([0cb6abb](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/0cb6abbe85e9109e87124379162b80d634182fa5))
* [DTWO-103903](https://jira.opentext.com/browse/DTWO-103903): Added automated LP builder for DCTM SV. Fixed lint error ([01426e4](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/01426e4a3bf9bc3b9d03dafb3e2492ffcaee5951))



# [1.9.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.8.4...v1.9.0) (2023-08-13)


### Features

* [DTWO-101415](https://jira.opentext.com/browse/DTWO-101415): Create SVF manifest while bundling an application distribution ([d46b2cc](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/d46b2cc1cba55cac6bac528e0bcaba26d2993e71))



## [1.8.4](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.8.3...v1.8.4) (2023-08-09)


### Bug Fixes

* [DTWO-104765](https://jira.opentext.com/browse/DTWO-104765): changed to directory lookup based logic while detecting closest DCTM SVF project ([a349b42](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/a349b4292c4f4df2afb6a9857ebb21adc3e3b770))



## [1.8.3](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.8.2...v1.8.3) (2023-08-01)


### Bug Fixes

* Always refresh symbolic link target for DCTM SVF project while being installed directly or indirectly ([7d6e0d2](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/7d6e0d28da69fddf981b6493b14e5baf173d21e1))



## [1.8.2](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.8.1...v1.8.2) (2023-07-29)


### Bug Fixes

* exclude test bundles from application bundle ([c179f7a](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/c179f7ad250e3089726dd25f6325c7329d57ca47))
* output directory name is not version appended incase of --no-compress option ([c11b500](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/c11b5008d31082b6dd75e41853b0a4b09103828a))



## [1.8.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.8.0...v1.8.1) (2023-07-28)


### Bug Fixes

* app bundle generator can work even if a launcher.json does not exist in root project ([b820728](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/b820728933413f292109182f6dcf27ce3ca75ced))
* package exclusions & re-ordering for generated launch config ([131cf7f](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/131cf7f212697258e66abecfba7873c5535ed355))
* Prints directory name only incase no-compress option was specified for app bundler ([f6b9197](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/f6b9197f1534ae951f85386faccd5039d008930a))
* SVF helper dependency detection mechanism changed to work for even non-SVF root project ([75e4650](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/75e46509ac32f7eb357118882efdf8c03712fdbd))



# [1.8.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.7.0...v1.8.0) (2023-07-28)


### Features

* Accept build version number as part of options ([106e5f3](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/106e5f35a0970df3435d3f1b26fbcd5fefc88698))



# [1.7.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.6.1...v1.7.0) (2023-07-27)


### Features

* More option for bundle generator to exclude SVF package and directory as final output ([da69bc4](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/da69bc4e6ea4999558e75a1c10cd434ea076a5a9))



## [1.6.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.6.0...v1.6.1) (2023-07-25)


### Bug Fixes

* Updated root project detection logic ([074da4e](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/074da4e09da26ad51d7911324cead45a79385cdb))



# [1.6.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.5.1...v1.6.0) (2023-07-25)


### Features

* Bundle generator to auto generate launch config ([2907f9b](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/2907f9b1c0f4da9ddbe71175be41106134fecfc2))



## [1.5.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.5.0...v1.5.1) (2023-07-25)


### Bug Fixes

* Parent project detection logic change for SVF helper ([2ec3ff2](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/2ec3ff2eaa4c9d5ccfd15793812d04c73a026389))



# [1.5.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.4.0...v1.5.0) (2023-07-25)


### Features

* SVF helper to discover dependencies and auto generate launch config ([4a2b50f](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/4a2b50f7d5b815b35980b1bad802e0fa9871ca2b))



# [1.4.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.3.0...v1.4.0) (2023-07-23)


### Features

* Grunt task to convert json coverage report into CSV ([386d08f](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/386d08fdc058dcc070c939bede5f350a9fb2c8ab))



# [1.3.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.2.3...v1.3.0) (2023-07-11)


### Features

* Optional parameter to provide file name for dctmw-pack command ([6107aae](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/6107aae0560c08a46cb8da8c819804b5b4956768))
* Working Java packaging type based on d2-unity-web ([3b073dc](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/3b073dced66a7c9549d4fedbcda864aedfbd8fa8))



## [1.2.3](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.2.2...v1.2.3) (2023-07-10)


### Bug Fixes

* Minimum client-side handling for error page redirection on MS IE ([8e6b9fb](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/8e6b9fb2ad05e0761c42d88701b56d2492ef4274))



## [1.2.2](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.2.1...v1.2.2) (2023-07-09)


### Bug Fixes

* Error handling while directory sym-link creation fails during passive installation of DCTM SVF projects ([872141a](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/872141a9b7ef6774b7af8bb9ae8796a056f82102))



## [1.2.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.2.0...v1.2.1) (2023-07-09)


### Bug Fixes

* Self liking for current project was not working ([2dc3a60](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/2dc3a60f1a1ac8a59ee7bc94811974de10596150))



# [1.2.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.1.1...v1.2.0) (2023-07-09)


### Features

* Added basic support for passive dependency linking for DCTM SVF projects ([84da796](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/84da796c97ab52e9250ec6c69dcd580a068ddece))



## [1.1.1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.1.0...v1.1.1) (2023-06-19)


### Bug Fixes

* app server url having a trailing slash was malfunctioning for node distribution ([aaddebd](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/aaddebdd4bc4a776ba77433724b974784dda90c3))
* default repository inclusion to make java packaging possible from any workstation ([e1a8b07](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/e1a8b07179e6027dd4ff667eaaef3ccf91917d60))



# [1.1.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/v1.0.0...v1.1.0) (2023-06-19)


### Bug Fixes

* miminal distribution corrected to contain static application runnable on any webserver ([97b0cf0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/97b0cf0c589677baf8c902777165dfdbfb608688))
* node distribution corrected with auto versioning ([41e0f24](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/41e0f249bbe7cd8d931a0c4610cbf6969dfd1192))


### Features

* complete java distribution based on d2fs-rest-web.war ([9069e57](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/9069e57acafaf960c4e0750543b0f1db6ed14987))



# [1.0.0](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/compare/0a0648c3da6ee7b149dd4b7403db5bc5340730a0...v1.0.0) (2023-06-15)


### Features

* Added grunt tasks for directory symlink, build config generator & css injector for bundles ([0a0648c](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/0a0648c3da6ee7b149dd4b7403db5bc5340730a0))
* packer for minimal & node deployments ([a2260d1](https://gitlab.otxlab.net/dctmw/sv/infra/dctm-web-tools/commit/a2260d19bf56c5a1c5981e66a9bb52d14691204e))



