# Documentum Web Tools

Set of utility scripts used across Documentum SVF projects to facilitate build/distribution.

## Grunt tasks

### smartuiEnsureDirSymlink 
Task to facilitate directory symbolic link creation. `src` will be linked to `dest` through a directory junction link.
#### task options
* (Boolean) ensureSrcDir - whether to ensure `src` exists or not. `src` directory will be created if `ensureDir` is set to `true` and the resolved `src` directory doesn't exist yet.

#### Usage
```
// In project's src/Gruntfile.js

...
grunt.initConfig({
    smartuiEnsureDirSymlink: {
      source: {
        options: {
          ensureSrcDir: false
        },
        src: '.',
        dest: `../lib/src/${svfName}`
      },
      debug: {
        src: '../out-debug',
        dest: `../lib/debug/${svfName}`
      },
      release: {
        src: '../out-release',
        dest: `../lib/release/${svfName}`
      }
    }
});
...

grunt.loadNpmTasks('@dctm/dctm-web-tools');

...
grunt.registerTask('default', ['smartuiEnsureDirSymlink']);
```

### smartuiGenerateBuildConfig
Generates RequireJS build configuration file for DCTM SVF projects.
#### task options
* (String) prefix - SVF prefix name for the current project.
* (String[]) dependencies - Names of other SVF packages the current project depends on.
* (String) rootDir - Root directory location w.r.t CWD.
* (String) srcDir - Source code directory location w.r.t CWD.
* (Boolean) verbose - Whether to output more logging information while executing.
* (String) outputFile - Name of the file to store generated build configuration.
* (Boolean) removeCsuiProxyModules - Whether to remove mapped modules that were originally distributed in `csui` but later got moved to `nuc` package.
* (Object) paths - RequireJS path configuration to use in addition to default path settings.

#### Usage
```
// In project's src/Gruntfile.js

...
grunt.initConfig({
    smartuiGenerateBuildConfig: {
      all: {
        options: {
          rootDir: '..',
          srcDir: '../src',
          prefix: svfName,
          dependencies: ['nuc', 'smart', 'csui', 'esoc', 'dctmw']
        }
      }
    }
});

...

grunt.loadNpmTasks('@dctm/dctm-web-tools');

...

grunt.registerTask('default', ['smartuiGenerateBuildConfig']);
```

### smartuiInjectCssBundle
Injects bundle specific CSS loading code into all the bundles linked to all the generated index files for a DCTM SVF project. 
Task should be executed only after bundles are compiled with @smartui/grunt-support.
#### task options
* (String) prefix - SVF prefix name for the current project.
* (String) dirDebug - Location of debug bunles output directory.

#### Usage
```
// In project's src/Gruntfile.js

...
grunt.initConfig({

    smartuiCompile: {
      all: {
        options: {
          ...
        }
      }
    },
    
    smartuiInjectCssBundle: {
      options: {
        prefix: svfName
      }
    }
});

...
grunt.loadNpmTasks('@smartui/grunt-support');
grunt.loadNpmTasks('@dctm/dctm-web-tools');

...

grunt.registerTask('default', ['smartuiCompile', 'smartuiInjectCssBundle']);
```

### smartuiTestCovJsonToCSV
Converts a JSON code-coverage report into CSV format along with a macro enabled spreadsheet. During unit tests run on a
DCTM SVF project, a JSON coverage report is always generated. This task helps to covert that JSON report into CSV.
This task should be executed after a project's unit test is run on as-is source code.
#### task options
* (String) src - The original JSON coverage report path. Defaults to `out-test/debug/coverage/coverage-summary.json`.
* (String) dest - Directory where the CSV and related file will be created. Defaults to `out-test/debug/coverage`.
#### Usage
```
// In project's test/Gruntfile.js

...
grunt.initConfig({
    karma: {
        debug: {
            client: {
                args: ['debug']
            }
        }
    },
    
    smartuiTestCovJsonToCSV: {}

});

...

grunt.loadNpmTasks('@dctm/dctm-web-tools');
...

grunt.registerTask('debug', ['karma:debug', 'smartuiTestCovJsonToCSV']);
...
```

## CLI Tools

### dctmw-pack
Packages a DCTM SVF application for deployment.
#### CLI options
* -d, --debug : Generate verbose output
* -t, --type &lt;type&gt; : Type of deployment package to create. One of `minimal`(default), `node`, `java`.
* --no-compress : Do not compress the final output into a zip file, produced output is a directory and its name is not version qualified. Not applicable for `java` type of distribution.
* -x, --exclude [excludes...] : Exclude these packages from final output. Accepts space separated multiple values.
* -n, --name [name] : File name of the produced output file. Version number is always appended.
* -l, --languages [languages...] : Languages to pack in the output. Supports space separated multiple values. Accepted lang codes are: ar(Arabic ),de(German),es(Spanish),fr(French),it(Italian),iw(Hebrew),ja(Japanese),ko(Korean),nl(Dutch),pt_BR(Portuguese-Brazil),sv(Swedish),zh(Chinese). For including all the supported language packs, "ALL" need to be passed as value in "languages" argument.
* -vt --vtag [vtag] : Tag the output with given version number. Defaults to an autogenerated value calculated based on current DCTM SVF project's version number.
* -h, --help : Displays help
#### Types
* minimal - Bundles a static web-application that can be deployed on any application server.
* node - Complete web application (minimal+server setup scripts) that runs on NodeJS and connects to a foreign D2-REST/D2SV deployment.
* java - Complete Java web application (minimal + D2-REST) that can be readily deployed on Tomcat.
#### NOTE
To use `java` type of packager, it is required that Apache Maven(>=3.8.1) is installed and correctly configured to run from command line. 
#### Usage
Can be invoked through command prompt. Or alternatively, can be configured to run as an NPM script for automation.
```
// In package.json of your DCTM SVF project
{
    "scripts": {
        "distribute": "dctmw-pack -t node"
    }
}

$npm run distribute
```
##### Enabling Localization support in DCTM SVF Project
For enabling the localization support in DCTM SVF Project,
* <b>localization</b> folder need to be added in project root directory and add the supported language bundle in the same folder.
* <b>localization</b> folder in the "files" configuration DCTM SV module's package.json. So that, the <b>localization</b> folder will be included NPM module and same will available in NPM registry. 
```
// Recommended Folder structure.
+---<DCTM_SVF_PROJECT_PROJECT_ROOT>   
|   +---localization
|   |   +---<LANG_CODE>
|   |   |       <JS_WITH_LANG_TRANSLATION>
```

```
// Sample language bundle folder structure.
+---DCTM SV Custom App (Project Root folder)
|   +---localization
|   |   +---de
|   |   |       custom-app-index.js
|   |   |       custom-app-index.json
|   |   |       custom-app.js
|   |   |       
|   |   +---fr
|   |   |       custom-app-index.js
|   |   |       custom-app-index.json
|   |   |       custom-app.js
|   |   |       
|   |   +---iw
|   |   |       custom-app-index.js
|   |   |       custom-app-index.json
|   |   |       custom-app.js
|   |   |       
|   |   +---ko
|   |   |       custom-app-index.js
|   |   |       custom-app-index.json
|   |   |       custom-app.js

```


### dctmw-link
Link a DCTM SVF package as dependency to another DCTM SVF project.
#### CLI options
* -h, --help : Display help
#### CLI arguments
* pkgName : NPM package name of the DCTM SVF package to be linked as dependency
#### Usage
Any DCTM SVF project that wants to be used as a dependency by some other DCTM SVF package,
should use this as part of their postinstall.
```
//In package.json of the project that wants to be used by other projects
{
    "name": "@dctm/my-package",
    "scripts": {
        "postinstall": "dctmw-link @dctm/my-package"
    }
}
```

### dctmw-dep-add
Installs other DCTM SVF packages as dependencies to current DCTM SVF project.
#### CLI options
* --save-dev : NPM dependencies corresponding to SVF packages are to be added as part of devDependencies.
* --release-only : Only link released version of NPM dependencies corresponding to SVF packages being added.
* -d, --debug : Output verbose logging
* -h, --help : Display help
#### CLI arguments
* pkgNames : DCTM SVF packages to install. Supports space separated multiple values.
#### Usage
Should be used at the root directory of a DCTM SVF project through a command prompt. If `@dctm/dctm-web-tools` is
installed globally, the command can be executed directly. Otherwise, current project needs to put a reference
of `dctmw-dep-add` in `scripts` of its `package.json`.

```
//In package.json of your DCTM SVF project

{
    "name": "@dctm/my-package",
    "scripts: {
        "dctmw-dep-add": "dctmw-dep-add"
    }
}

//In terminal opened at project root directory
$ npm run dctmw-dep-add -- -d d2 d2mob

```

### dctmw-dep-remove
Uninstalls an already installed DCTM SVF package from current DCTM SVF project.
#### CLI options
* -d, --debug : Output verbose logging
* -h, --help : Display help
#### CLI arguments
* pkgNames : Name of the DCTM SVF package to be removed. Does not support multiple values.
#### Usage
Should be used at the root directory of a DCTM SVF project through a command prompt. If `@dctm/dctm-web-tools` is
installed globally, the command can be executed directly. Otherwise, current project needs to put a reference
of `dctmw-dep-remove` in `scripts` of its `package.json`.
```
//In package.json of your DCTM SVF project

{
    "name": "@dctm/my-package",
    "scripts: {
        "dctmw-dep-remove": "dctmw-dep-remove"
    }
}

//In terminal opened at project root directory
$ npm run dctmw-dep-remove -- -d d2mob

```

## Contact
jayantad@opentext.com