#!/usr/bin/env node

'use strict';

const { Command, Option } = require('commander');
const program = new Command();
const pack = require('./pack');

program
  .name('dctmw-pack')
  .version(require('../package.json').version)
  .allowUnknownOption()
  .addOption(new Option('-t, --type <type>', 'Packaging type').choices(['minimal', 'node', 'java']).default('minimal', 'Creates a static client application zip.'))
  .option('--no-compress', 'Do not compress final output, not applicable for java distribution')
  .option('-vt, --vtag [vtag]', 'Tag the output with given version number')
  .option('-x, --exclude [excludes...]', 'Exclude these packages from final output. Supports space separated multiple values.')
  .option('-n, --name [name]', 'Name of the output file')
  .option('-l, --languages [languages...]', 'Languages to pack in the output. Supports space separated multiple values. Accepted lang codes are: ar(Arabic ),de(German),es(Spanish),fr(French),it(Italian),iw(Hebrew),ja(Japanese),ko(Korean),nl(Dutch),pt_BR(Portuguese-Brazil),sv(Swedish),zh(Chinese). For including all the supported language packs, "ALL" need to be passed as value in "languages" argument.')
  .option('-d, --debug', 'Output verbose logging')
  .action((opts) => {
    pack({ type: opts.type, compress: opts.compress, versionNumber: opts.vtag, excludePackages: opts.exclude, name: opts.name, verbose: opts.debug === true, languages: opts.languages });
  });

program.parse();
