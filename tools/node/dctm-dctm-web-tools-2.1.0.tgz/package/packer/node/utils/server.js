#!/usr/bin/env node

'use script';

const
  { join: pathJoin } = require('path');
const http = require('http');
const https = require('https');
const compression = require('compression');
const connect = require('connect');
const cors = require('cors');
const { readFileSync } = require('fs-extra');
const parseUrl = require('parseurl');
const { isWebUri } = require('valid-url');
const morgan = require('morgan');
const staticFiles = require('serve-static');
const _ = require('underscore');
const cwd = process.cwd();
const webDir = pathJoin(cwd, 'public');
const proxy = require('./proxy');
const serverConfig = require('../server.conf');
const defaultRequestInterceptor = (req, res, next) => { next(); };
const { requestInterceptor = defaultRequestInterceptor } = serverConfig;

if (serverConfig && _.isString(serverConfig.APP_SERVER_URL) && serverConfig.APP_SERVER_URL.endsWith('/')) {
  serverConfig.APP_SERVER_URL = serverConfig.APP_SERVER_URL.substring(0, serverConfig.APP_SERVER_URL.length - 1);
}

const { APP_SERVER_URL = serverConfig.APP_SERVER_URL } = process.env;
const enableProxy = serverConfig.APP_SERVER_IS_PROXIED === true && !!isWebUri(APP_SERVER_URL);
const { host: proxyHost, path: proxyPath, protocol: proxyProtocol } = parseUrl({ url: APP_SERVER_URL });
const deploymentContextPath = proxyPath;
const host = process.env.SERVER_HOST || '0.0.0.0';
const browserHost = host === '0.0.0.0' ? 'localhost' : host;
const port = parseInt(process.env.SERVER_PORT || serverConfig.LOCAL_HTTP_PORT || 6989);
const securePort = parseInt(process.env.SERVER_SECURE_PORT || serverConfig.LOCAL_HTTPS_PORT || 9698);
const secureOptions = {
  key: readFileSync('ssl-key.pem'),
  cert: readFileSync('ssl-certificate.pem')
};
const corsOptions = {
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['origin', 'authorization', 'x-targetbaseurl'],
  exposedHeaders: ['content-length', 'authorization'],
  maxAge: 1728000
};
const staticOptions = {
  etag: false,
  maxAge: 31536000
};
const staticRoutes = {
  _default_: staticFiles(webDir, staticOptions)
};

const launchConfig = require(pathJoin(webDir, 'ui/launcher.json'));
launchConfig['app_server_url'] = enableProxy ? proxyPath : APP_SERVER_URL;

const server = connect();

server
  .use(morgan('short', {
    skip: (req, res) => (res.statusCode < 300)
  }))
  .use(compression())
  .use(requestInterceptor)
  .use((req, res, next) => {
    if (req.url === '/favicon.ico') {
      req.url = `${deploymentContextPath}/ui${req.url}`;
    }

    if (!req.url.startsWith(deploymentContextPath)) {
      res.writeHead(301, {
        Location: `${deploymentContextPath}`
      });
      res.end();
      return;
    }

    req.url = req.url.substring(deploymentContextPath.length);
    if (req.url.charAt(0) !== '/') {
      req.url = `/${req.url}`;
    }

    if (req.url.startsWith('/ui-debug')) {
      req.url = `/ui-debug${req.url.substring(req.url.indexOf('/', 1))}`;
    } else if (req.url.startsWith('/ui')) {
      req.url = `/ui${req.url.substring(req.url.indexOf('/', 1))}`;
    }

    if (req.url === '/ui/launcher.json') {
      res.end(JSON.stringify(launchConfig));
      return;
    }

    const nextHandler = () => {
      if (req.url.startsWith('/ui-debug/')) {
        req.url = `/ui${req.url.substring(req.url.indexOf('/', 1))}`;
        staticRoutes._default_(req, res, nextHandler);
      } else {
        req.url = `${deploymentContextPath}${req.url}`;
        next();
      }
    };

    staticRoutes._default_(req, res, nextHandler);
  });

if (enableProxy) {
  server
    .use(proxy({
      targetBaseUrl: `${proxyProtocol}//${proxyHost}`,
      corsOptions,
      httpsOptions: {
        allowUnsecure: serverConfig.PROXIED_APP_SERVER_ALLOWS_SELF_SIGNED_HTTPS
      }
    }))
    .use(cors(function (request, callback) {
      const methods = _.unique(corsOptions.methods.concat(request.headers['access-control-request-method']));
      const requestedHeaders = request.headers['access-control-request-headers'];
      const allowedHeaders = _.unique(_.compact(
        corsOptions.allowedHeaders.concat((requestedHeaders || '').split(/\s*,\s*/))));
      callback(null, {
        origin: true,
        methods: methods.join(','),
        allowedHeaders: allowedHeaders.join(','),
        exposedHeaders: corsOptions.allowedHeaders.join(','),
        maxAge: corsOptions.maxAge
      });
    }));
}

console.log('Web server worker', process.pid, `is serving at http://${browserHost}:${port}${deploymentContextPath}`);
http.createServer(server).listen(port, host);

console.log('Web server worker', process.pid, `is serving at https://${browserHost}:${securePort}${deploymentContextPath}`);
https.createServer(secureOptions, server).listen(securePort, host);
