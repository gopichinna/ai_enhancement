'use strict';

const http = require('http');
const https = require('https');
const parseUrl = require('parseurl');
const _ = require('underscore');

module.exports = function (options) {
  const { targetBaseUrl, corsOptions, httpsOptions } = options;

  return function (request, response, next) {
    const headers = request.headers;
    const origin = headers.origin;
    let proxyTarget = targetBaseUrl || process.env.CORS_PROXY_TARGET;

    // Proxy only if enabled
    if (!proxyTarget) {
      return next();
    }

    // Support CORS pre-flighting regardless the target service
    if (request.method === 'OPTIONS' && origin) {
      return preflight();
    }

    const protoIdx = proxyTarget.indexOf('://');
    let proxyTargetProtocol;

    if (protoIdx > 0) {
      proxyTargetProtocol = proxyTarget.substring(0, protoIdx + 1);
      proxyTarget = proxyTarget.substring(protoIdx + 3);
    }

    const proxyTargetTokens = proxyTarget.split(':');
    const proxyTargetHost = proxyTargetTokens[0];
    const proxyTargetPort = proxyTargetTokens[1];

    // Conceal, that the request has been made to a different host
    delete headers.host;
    delete headers.origin;
    delete headers.referer;
    const targetUrlObj = parseUrl(request);
    const isHttps = (proxyTargetProtocol || targetUrlObj.protocol) === 'https:';
    const target = isHttps ? https : http;
    const agentOptions = (isHttps && httpsOptions.allowUnsecure === true) ? { agent: new https.Agent({ rejectUnauthorized: false }) } : {};
    const targetRequest = target
      .request({
        method: request.method,
        host: proxyTargetHost,
        port: proxyTargetPort,
        path: targetUrlObj.path,
        headers,
        ...agentOptions
      }, forwardResponse)
      .on('error', forwardError);
    request.pipe(targetRequest);

    function preflight () {
      response.writeHead(204, getCorsHeaders(
        request.headers['access-control-request-method'],
        request.headers['access-control-request-headers']));
      response.end('No Content');
    }

    function forwardResponse (targetResponse) {
      const headers = Object.assign({}, targetResponse.headers,
        origin && getCorsHeaders(request.method));
      response.statusCode = targetResponse.statusCode;
      Object.keys(headers)
        .forEach(function (name) {
          const value = headers[name];
          if (/* name !== 'www-authenticate' && */ value != null) {
            response.setHeader(name, value);
          }
        });
      targetResponse.pipe(response);
    }

    function forwardError (error) {
      console.error(error);
      response.writeHead(500, {
        'content-type': 'application/json'
      });
      response.end(JSON.stringify({
        error: error.message
      }));
    }

    function getCorsHeaders (method, requestedHeaders) {
      const methods = _.unique(corsOptions.methods.concat(method));
      const allowedHeaders = _.unique(_.compact(
        corsOptions.allowedHeaders.concat(
          (requestedHeaders || '').split(/\s*,\s*/))));
      return {
        'access-control-allow-origin': origin,
        'access-control-allow-methods': methods.join(','),
        'access-control-allow-headers': allowedHeaders.join(','),
        'access-control-expose-headers': corsOptions.exposedHeaders.join(','),
        'access-control-max-age': corsOptions.maxAge
      };
    }
  };
};
