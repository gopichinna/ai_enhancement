'use strict';

const chalk = require('chalk');
const grunt = require('grunt');
const { join, resolve } = require('path');
const { existsSync, readJsonSync, outputJsonSync, renameSync } = require('fs-extra');
const { sync: rimrafSync } = require('rimraf');
const generateBuildNumber = require('@smartui/grunt-support/utils/generate.build.number');
const PATTERN_VERSION = /\d+\.\d+\.\d+/;

module.exports = function (opts) {
  const { type = 'minimal', compress = true, versionNumber, excludePackages = [], name, verbose = false, languages = [] } = opts;
  const { getLaunchConfig } = require('../utils/svf.helper');
  const { createManifest } = require('../utils/svf.manifest');
  const { getSVFModuleVersionMap } = require('../utils/svf.module.version.resolver');
  const { prepareLocalizationBundle, finalizeLocalizationBundle } = require('../utils/language.helper');
  const cwd = process.cwd();
  const appPackageJson = require(join(cwd, 'package.json'));
  let { version } = appPackageJson;
  const match = version.match(PATTERN_VERSION);
  const svfModuleVersionMap = getSVFModuleVersionMap();
  if (!match) {
    throw new Error(`Unconventional package version : ${version}, semvar compatible version is expected.`);
  }

  version = match[0];
  const generatedVersion = versionNumber || generateBuildNumber(version);

  let coreDir = 'node_modules/@dctm/dctm-web-core';
  if (!existsSync(coreDir)) {
    if (appPackageJson.name === '@dctm/dctm-web-core') {
      coreDir = cwd;
    } else {
      throw new Error('Could not detect a DCTM-WEB project');
    }
  }

  coreDir = resolve(coreDir);
  console.log(`Creating a ${chalk.greenBright(type)} distribution of : ${chalk.greenBright(appPackageJson.description || appPackageJson.name)}`);
  verbose && console.log(`CWD: ${chalk.greenBright(cwd)}, CoreDir: ${chalk.greenBright(coreDir)}`);

  const { svf: { name: svfName } } = appPackageJson;
  const distDir = 'dist';
  const appBuildDir = `${distDir}/app`;
  const title = `${appPackageJson.description}`;
  const distName = name || `${svfName}-app-${type}`;
  const distFinalName = compress ? `${distName}-${version}` : distName;
  const archiveLocation = `${distDir}/${distFinalName}.${type === 'java' ? 'war' : 'zip'}`;
  const patternExcludeBundles = excludePackages.map(p => `!${p}/**`);

  grunt.task.init = () => {};
  grunt.initConfig({
    clean: {
      options: {
        force: true
      },
      auto_app: appBuildDir,
      java_index: [`${join(appBuildDir, 'public/index.html')}`, `${join(appBuildDir, 'public/ui/index.html')}`]
    },

    copy: {
      auto_app: {
        files: [
          { dest: join(appBuildDir, 'public/ui'), expand: true, cwd: join(cwd, 'lib/release'), src: ['*/**', ...patternExcludeBundles, '!d2/bundles/d2-test*', '!d2mob/bundles/d2mob-test*'] },
          { dest: join(appBuildDir, 'public/ui'), expand: true, cwd: join(coreDir, 'pages'), src: ['error/*.html'] },
          { dest: join(appBuildDir, 'public/ui'), expand: true, cwd: join(coreDir, 'out-page'), src: ['*.css', '*.html', '*.ico', '*.json', 'config.js', 'initialize.js', '!service-worker.js'] },
          { dest: join(appBuildDir, 'public/ui-debug'), expand: true, cwd: join(cwd, 'lib/debug'), src: [(type === 'minimal' ? '*/**' : '*/bundles/**'), ...patternExcludeBundles, '!d2/bundles/d2-test*', '!d2mob/bundles/d2mob-test*'] }
        ]
      },
      auto_node: {
        expand: true,
        cwd: join(__dirname, 'node'),
        src: ['**', '!package.json'],
        dest: appBuildDir
      },
      auto_java: {
        expand: true,
        cwd: join(appBuildDir, 'target'),
        src: ['*.war'],
        dest: distDir
      }
    },

    compress: {
      auto_minimal: {
        options: {
          archive: archiveLocation,
          level: 9
        },
        expand: true,
        cwd: join(appBuildDir, 'public'),
        src: ['**/*'],
        dest: '/'
      },
      auto_node: {
        options: {
          archive: archiveLocation,
          level: 9
        },
        expand: true,
        cwd: appBuildDir,
        src: ['**/*'],
        dest: '/'
      }
    },

    replace: {
      options: {
        force: true
      },
      auto_app: {
        options: {
          patterns: [
            {
              match: /C_VERSION\s*=\s*"[\d.]+"/i,
              replacement: `C_VERSION = "${generatedVersion}"`
            }
          ]
        },
        expand: true,
        cwd: join(coreDir, 'out-page'),
        src: ['service-worker.js'],
        dest: join(appBuildDir, 'public/ui')
      },
      auto_minimal: {
        options: {
          patterns: [
            { match: '__NAME__', replacement: distName },
            { match: '__VERSION__', replacement: version },
            { match: '__VERSION_FINE__', replacement: generatedVersion },
            { match: '__TITLE__', replacement: title }
          ]
        },
        expand: true,
        cwd: join(__dirname, 'minimal'),
        src: ['**'],
        dest: appBuildDir
      },
      auto_node: {
        options: {
          patterns: [
            { match: /"name": ""/g, replacement: `"name": "${distName}"` },
            { match: /"version": ""/g, replacement: `"version": "${generatedVersion}"` },
            { match: /"description": ""/g, replacement: `"description": "${title}"` }
          ]
        },
        expand: true,
        cwd: join(__dirname, 'node'),
        src: 'package.json',
        dest: appBuildDir
      },
      auto_java: {
        options: {
          patterns: [
            { match: '__NAME__', replacement: distName },
            { match: '__FINAL_NAME_', replacement: distFinalName },
            { match: '__VERSION__', replacement: version },
            { match: '__TITLE__', replacement: title }
          ]
        },
        expand: true,
        cwd: join(__dirname, 'java'),
        src: ['**'],
        dest: appBuildDir
      }
    },

    exec: {
      build_java: {
        cmd: 'mvn clean package',
        stdin: true,
        stdout: true,
        stderr: true,
        sync: false,
        options: {
          cwd: appBuildDir
        }
      }
    }
  });

  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-compress');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-exec');
  grunt.loadNpmTasks('grunt-replace');

  grunt.registerTask('prepareLPBundle', 'Generate language pack bundle for the distribution', function () {
    const done = this.async();
    prepareLocalizationBundle({ lpBundleLangCodes: languages, verbose, svfModuleVersionMap }).then(done);
  });

  grunt.registerTask('finalizeLPBundle', 'Merge language pack bundle for the distribution', function () {
    finalizeLocalizationBundle({ lpBundleLangCodes: languages, verbose });
  });

  grunt.registerTask('createLauncher', 'Creates a launch configuration for the distribution', function () {
    const generatedLaunchConfig = getLaunchConfig();
    grunt.verbose.writeln(`Generated launch config: ${JSON.stringify(generatedLaunchConfig)}`);
    Object.keys(generatedLaunchConfig.packages)
      .filter(pkg => {
        if (excludePackages.includes(pkg)) {
          delete generatedLaunchConfig.packages[pkg];
          return false;
        }
        return true;
      })
      .sort((a, b) => (generatedLaunchConfig.packages[a].order - generatedLaunchConfig.packages[b].order))
      .forEach((pkg, index) => {
        generatedLaunchConfig.packages[pkg].order = index + 1;
      });

    grunt.verbose.writeln(`Generated launch config post processing exclusions: ${JSON.stringify(generatedLaunchConfig)}`);

    const launcherFileName = 'launcher.json';
    const launcherSrcFile = resolve(join(cwd, launcherFileName));
    const launcherTargetFile = resolve(join(appBuildDir, `public/ui/${launcherFileName}`));
    grunt.verbose.writeln(`${this.name}: Reading from : ${launcherSrcFile}`);
    let launcherContent = {};
    if (existsSync(launcherSrcFile)) {
      launcherContent = readJsonSync(launcherSrcFile);
    } else {
      grunt.log.writeln(`${this.name} : launcher.json does not exist`);
    }

    launcherContent.version = generatedVersion;
    if (Object.keys(generatedLaunchConfig.packages).length) {
      launcherContent.packages = generatedLaunchConfig.packages;
    } else {
      delete launcherContent.packages;
    }
    launcherContent['app_server_url'] = '';
    const serializableContent = JSON.stringify(launcherContent, undefined, 2);
    grunt.verbose.writeln(`${this.name} : Final launcher content : ${serializableContent}`);
    grunt.log.writeln(`${this.name}: Writing to : ${chalk.cyanBright(launcherTargetFile)}`);
    outputJsonSync(launcherTargetFile, launcherContent, { spaces: 2 });
  });

  grunt.registerTask('createManifest', 'Creates a manifest file for the packaged SVF components', function () {
    createManifest({
      refDirRoot: process.cwd(),
      outputDir: join(appBuildDir, 'public/ui'),
      excludedPackages: excludePackages,
      verbose,
      svfModuleVersionMap
    });
  });

  grunt.registerTask('renameAppFolder', 'Renames app folder as per given name', function () {
    const targetPath = `${distDir}/${distFinalName}`;
    if (existsSync(targetPath)) {
      rimrafSync(targetPath);
    }
    renameSync(appBuildDir, `${distDir}/${distFinalName}`);
  });

  grunt.registerTask('app_static', ['prepareLPBundle', 'copy:auto_app', 'finalizeLPBundle', 'replace:auto_app', 'replace:auto_minimal', 'createLauncher', 'createManifest']);
  grunt.registerTask('minimal', ['app_static', ...(compress ? ['compress:auto_minimal'] : ['renameAppFolder'])]);
  grunt.registerTask('node', ['app_static', 'copy:auto_node', 'replace:auto_node', ...(compress ? ['compress:auto_node'] : ['renameAppFolder'])]);
  grunt.registerTask('java', ['app_static', 'clean:java_index', 'replace:auto_java', 'exec:build_java', 'copy:auto_java']);

  grunt.tasks(['clean:auto_app', type, 'clean:auto_app'], { verbose }, () => {
    console.log(`Created application distro: ${chalk.greenBright(resolve(compress ? archiveLocation : `${distDir}/${distFinalName}`))}`);
  });
};
