#!/usr/bin/env node

'use strict';

const { Command } = require('commander');
const program = new Command();
const linkDep = require('./dep.link');

program
  .name('dctmw-link')
  .description('Link a DCTM SVF package as dependency to current project')
  .version(require('../package.json').version)
  .argument('<pkgName>', 'NPM package name of the DCTM SVF package to be linked as dependency')
  .action((pkgName) => {
    linkDep(pkgName);
  });

program.parse();
