'use strict';

const { ensureDirSync, ensureSymlinkSync } = require('fs-extra');
const path = require('path');
const _ = require('underscore');

module.exports = function (grunt) {
  grunt.registerMultiTask('smartuiEnsureDirSymlink', 'Ensures symbolic linking of src/debug/release directories for SVF packages, source directories are created if non-existent', function () {
    const options = this.options({
      ensureSrcDir: true
    });

    const taskName = this.name;

    _.each(this.files, function (file) {
      const src = _.isEmpty(file.src) ? (_.isEmpty(file.orig.src) ? undefined : file.orig.src[0]) : file.src[0];
      const dest = file.dest;
      if (src) {
        grunt.log.writeln(taskName + ': ' + src + ' -> ' + dest);
        try {
          if (options.ensureSrcDir !== false) {
            if (!grunt.file.exists(src)) {
              grunt.verbose.writeln(taskName + ': Ensuring directory ' + path.resolve(src));
              ensureDirSync(src);
            } else {
              grunt.verbose.writeln(taskName + ': Source directory already exists');
            }
          } else {
            grunt.verbose.writeln(taskName + ': Skipped enforcing source directory due to options');
          }

          if (grunt.file.exists(src)) {
            grunt.verbose.writeln(taskName + ': Ensuring symbolic link ' + path.resolve(src) + ' -> ' + path.resolve(dest));
            ensureSymlinkSync(path.resolve(src), path.resolve(dest), 'junction');
          } else {
            grunt.log.writeln(taskName + ': Skipped linking to non-existing source directory -> ' + path.resolve(src));
          }
        } catch (error) {
          grunt.verbose.error(error.stack);
          grunt.fail.warn(error);
        }
      } else {
        grunt.log.writeln(taskName + ': Skipped as no source specified');
      }
    });
  });
};
