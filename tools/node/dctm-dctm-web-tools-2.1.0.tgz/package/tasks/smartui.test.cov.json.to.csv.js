'use strict';

const selfDir = __dirname;
const { join, resolve } = require('path');
const chalk = require('chalk');
const [matcher, replacement] = process.platform === 'win32' ? [/.*\\lib\\src\\([^\\]*)\\(.*)/g, 'src\\$2'] : [/.*\/lib\/src\/([^/]*)\/(.*)/g, 'src/$2'];

module.exports = function (grunt) {
  grunt.registerTask('smartuiTestCovJsonToCSV', 'Converts json-summary coverage report to CSV format', function () {
    const { src, dest } = this.options({
      src: '../out-test/debug/coverage/coverage-summary.json',
      dest: '../out-test/debug/coverage'
    });

    if (grunt.file.exists(dest)) {
      if (!grunt.file.isDir(dest)) {
        throw new Error(`Destination ${dest} does not refer to a directory`);
      }
    } else {
      grunt.file.mkdir(dest);
    }

    if (grunt.file.exists(src) && grunt.file.isFile(src)) {
      grunt.verbose.writeln(`Reading coverage report from : ${resolve(src)}`);
      const json = grunt.file.readJSON(src);
      const toCsv = (item) => `${item.pct},"${item.covered}/${item.total}\t"`;

      let output = 'File,Lines (%),Lines,Statements (%),Statements,Functions (%),Functions,Branches (%),Branches\n';
      const keys = Object.keys(json).filter(k => (k !== 'total')).sort();

      for (const key of keys) {
        const val = json[key];
        const k = key.replace(matcher, replacement);
        output += `${k},${toCsv(val.lines)},${toCsv(val.statements)},${toCsv(val.functions)},${toCsv(val.branches)}\n`;
      }

      const val = json['total'];
      output += `TOTAL,${toCsv(val.lines)},${toCsv(val.statements)},${toCsv(val.functions)},${toCsv(val.branches)}\n`;

      const csvPath = join(dest, 'coverage-summary.csv');
      grunt.log.writeln(`Coverage summary CSV -> ${chalk.cyan(csvPath)}`);
      grunt.file.write(csvPath, output);
      const spreadSheetPath = join(dest, 'CoverageReport.xlsm');
      grunt.log.writeln(`Coverage summary spreadsheet -> ${chalk.cyan(spreadSheetPath)}`);
      grunt.file.copy(join(selfDir, 'CoverageReport.xlsm'), spreadSheetPath);
      grunt.log.writeln();
    } else {
      throw new Error(`${src} does not exist.`);
    }
  });
};
