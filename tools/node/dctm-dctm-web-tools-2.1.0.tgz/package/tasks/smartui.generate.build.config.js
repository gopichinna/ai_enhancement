'use strict';

const _ = require('underscore');
const { existsSync, readdirSync, writeFileSync } = require('fs-extra');
const path = require('path');
const { generate: createConfig } = require('@smartui/grunt-support/config');
const parseConfig = require('@smartui/grunt-support/utils/parse.build.config');

function autoDependencies (prefix, dependencies) {
  let dirLibSrc = path.join(process.cwd(), 'lib/src');
  if (!existsSync(dirLibSrc)) {
    dirLibSrc = path.join(__dirname, '../../lib/src');
  }

  if (existsSync(dirLibSrc)) {
    readdirSync(dirLibSrc, { withFileTypes: true })
      .forEach(item => {
        if ((item.isDirectory() || item.isSymbolicLink()) && item.name !== prefix && existsSync(path.join(dirLibSrc, item.name, 'component.js'))) {
          dependencies.push(item.name);
        }
      });
  }
}

module.exports = function (grunt) {
  grunt.registerMultiTask('smartuiGenerateBuildConfig', 'Generates transformed requireJS build config file for SVF projects', function () {
    const
      { prefix, dependencies, rootDir, srcDir, outputFile: configName, verbose, paths = {}, map = {}, removeCsuiProxyModules } = this.options({
        prefix: 'dctmw',
        dependencies: [],
        rootDir: '.',
        srcDir: 'src',
        verbose: false,
        outputFile: 'config-build.js',
        removeCsuiProxyModules: true,
        paths: {} // paths config for requirejs
      });

    if (!dependencies.length) {
      autoDependencies(prefix, dependencies);
      grunt.log.writeln(`Auto discovered dependencies : ${dependencies}`);
    }

    try {
      grunt.log.writeln(this.name + ': Generating build config...');
      createConfig({ prefix, dependencies, rootDir, srcDir, configName, extraConfig: { paths, map }, verbose });

      grunt.log.writeln(this.name + ': Parsing generated config...');
      const configContent = parseConfig(configName);
      configContent.prefix = prefix;
      configContent.paths = _.extend(configContent.paths || {}, paths); // This is required because the nuc task does not merge paths
      if (removeCsuiProxyModules !== false) {
        configContent.map = _
          .chain(_.pairs(configContent.map))
          .map(function (list) {
            list[1] = _
              .chain(_.pairs(list[1]))
              .reject(function (pair) {
                const key = pair[0];
                const value = pair[1];
                return key.startsWith('csui') && value.startsWith('nuc') && (key.substring(4) === value.substring(3));
              })
              .object()
              .value();
            return list;
          })
          .reject(function (list) {
            return _.isEmpty(list[1]);
          })
          .object()
          .value();
      }
      const serializableConfig = JSON.stringify(configContent, undefined, 2);
      grunt.verbose.writeln(this.name + ': Transformed require config ' + serializableConfig);
      grunt.log.writeln(this.name + ': Writing transformed config...');
      writeFileSync(configName, 'require.config(' + serializableConfig + ');');
      grunt.log.writeln(this.name + ': Saved config file ' + path.resolve(configName));
    } catch (error) {
      grunt.verbose.error(error.stack);
      grunt.fail.warn(error);
    }
  });
};
