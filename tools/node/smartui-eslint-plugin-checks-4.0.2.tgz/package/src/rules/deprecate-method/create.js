const { isAbsolute, join } = require('path');
const { loadComponentsDescriptors } = require('@smartui/grunt-support/utils/load.config');
const { isMatch } = require('picomatch');
const { collectDeprecated } = require('../shared');

let deprecated

function getMethodId({ name: methodName, class: className, module }) {
  return `${className}.${methodName} (${module})`
}

module.exports = context => {
  if (!deprecated) {
    const { options = [] } = context;
    /* c8 ignore next 7 */
    let { srcDir = 'src', ignore = [], verbose = false } = options[0] || {};

    // Allow specifying srcDir relatively to the project root and not
    // to the current directory, so that eslint can be called standalone
    // and by grunt, which switches the current directory to the Gruntfile.
    const { SMARTUI_PROJECT_ROOT: rootDir } = process.env;
    if (rootDir && !isAbsolute(srcDir)) srcDir = join(rootDir, srcDir);

    const components = loadComponentsDescriptors({ srcDir, verbose });
    const ignored = new Set(ignore);
    const collected = collectDeprecated(components, 'method', getMethodId, verbose);
    deprecated = [];
    for (const item of collected) {
      const { original } = item;
      const id = getMethodId(original);
      // Ignoring just one of the module aliases is enough to ignore
      // the whole deprecation.
      if (ignored.has(id)) {
        if (verbose) console.log(`  ignoring ${id}`);
        continue;
      }
      deprecated.push(item);
    }
  }
  /* c8 ignore next */
  if (!deprecated.length) return {}

  return {
    MemberExpression: memberExpr => {
      const { object, property } = memberExpr;
      let objectName;

      // .method()
      if (property.type !== 'Identifier') return;
      if (object.type === 'Identifier') {
        // one.method()
        objectName = object.name;
      } else {
        // one.two.method()
        if (object.type !== 'MemberExpression') return;
        const { property } = object;
        if (property.type !== 'Identifier') return;
        objectName = property.name;
      }

      const { name: propertyName } = property

      for (let item of deprecated) {
        if (isDeprecated(item.original, objectName, propertyName)) {
          deprecate(property, item)
        }
      }
    }
  };

  function getMessage({ replace, migrate, until, message }) {
    /* c8 ignore next 3 */
    if (message) return { message };
      const messageId = until && replace ? "deprecateWithUntilAndReplace" :
      until && migrate ? "deprecateWithUntilAndMigrate" :
      replace ? 'deprecateWithReplace' : migrate ? 'deprecateWithMigrate' :
      /* c8 ignore next */
      until ? 'deprecateWithUntil' : 'deprecate'
      return { messageId }
    }

  function getSuggestion({ replace, migrate, suggestion }) {
    /* c8 ignore next */
    if (suggestion) return { desc: suggestion };
    const messageId = replace ? 'suggestReplace' :
      migrate ? 'suggestMigrate' : 'suggestStop'
    return { messageId }
  }

  function getFix(node, { replace }) {
    if (!replace) return () => null;
    return fixer => fixer.replaceText(node, replace);
  }

  function isDeprecated({ name, object }, objectName, propertyName) {
    if (name !== propertyName) return false;
    /* c8 ignore next */
    if (!Array.isArray(object)) object = [object];
    return object.some(pattern => isMatch(objectName, pattern));
  }

  function deprecate(node, item) {
    const { original, replace, migrate, since, until } = item
    const fix = getFix(node, item);
    const message = getMessage(item);
    const suggest = getSuggestion(item);
    const data = {
      'original.id': getMethodId(original),
      'original.name': original.name,
      'original.class': original.class,
      'original.module': original.module,
      replace,
      since,
      until
    }
    if (migrate) {
      data['migrate.id'] = getMethodId(migrate);
      data['migrate.name'] = migrate.name;
      data['migrate.class'] = migrate.class;
      data['migrate.module'] = migrate.module;
    }

    context.report({
      node, ...message, data, fix, suggest: [{ ...suggest, data, fix }]
    });
  }
};
