module.exports = {
  meta: require('./meta.json'),
  create: require('./create.js')
};
