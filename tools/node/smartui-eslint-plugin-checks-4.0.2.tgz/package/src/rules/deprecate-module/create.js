const { isAbsolute, join } = require('path');
const { loadComponentsDescriptors } = require('@smartui/grunt-support/utils/load.config');
const { detectDefinesOrRequires, detectImportsAndExports } = require('requirejs-esm');
const { collectDeprecated, stringifyLiteral } = require('../shared');

let deprecated

module.exports = context => {
  if (!deprecated) {
    const { options = [] } = context;
    /* c8 ignore next 7 */
    let { srcDir = 'src', ignore = [], verbose = false } = options[0] || {};

    // Allow specifying srcDir relatively to the project root and not
    // to the current directory, so that eslint can be called standalone
    // and by grunt, which switches the current directory to the Gruntfile.
    const { SMARTUI_PROJECT_ROOT: rootDir } = process.env;
    if (rootDir && !isAbsolute(srcDir)) srcDir = join(rootDir, srcDir);

    const components = loadComponentsDescriptors({ srcDir, verbose });
    const ignored = new Set(ignore);
    const collected = collectDeprecated(components, 'module', String, verbose);
    deprecated = new Map();
    for (const item of collected) {
      let { original } = item;
      // Original module name can be an array of names, if the same module
      // was moved one or more times earlier.
      if (!Array.isArray(original)) original = [original];
      // Ignoring just one of the module aliases is enough to ignore
      // the whole deprecation.
      const ignore = original.some(name => ignored.has(name));
      if (ignore) {
        // Do not log all aliases; just the first one and their count.
        if (original.length === 1) original = original[0];
        if (verbose) console.log(`  ignoring ${original}`);
        continue;
      }
      for (const name of original) {
        deprecated.set(name, item);
      }
    }
  }
  /* c8 ignore next */
  if (!deprecated.size) return {}

  return {
    Program: program => {
      const modules = detectDefinesOrRequires(program);
      if (modules.length) {
        for (const { deps } of modules) {
          if (deps) {
            for (const element of deps.elements) {
              if (element.type === 'Literal') {
                checkDeprecated(element, element, getAmdFix);
              }
            }
          }
        }
      } else {
        const { imports, exports } = detectImportsAndExports(program);
        for (const statements of [imports, exports]) {
          if (statements.length) {
            for (const { node, source } of statements) {
              if (source && source.type === 'Literal') {
                checkDeprecated(node, source, getEsmFix);
              }
            }
          }
        }
      }
    }
  };

  function getMessage({ replace, migrate, until, message }) {
    if (message) return { message };
    const messageId = until && replace ? "deprecateWithUntilAndReplace" :
      until && migrate ? "deprecateWithUntilAndMigrate" :
      replace ? 'deprecateWithReplace' : migrate ? 'deprecateWithMigrate' :
      until ? 'deprecateWithUntil' : 'deprecate'
      return { messageId }
    }

  function getSuggestion({ replace, migrate, suggestion }) {
    if (suggestion) return { desc: suggestion };
    const messageId = replace ? 'suggestReplace' :
      migrate ? 'suggestMigrate' : 'suggestStop'
    return { messageId }
  }

  function getAmdFix(node, { replace }) {
    if (!replace) return () => null;
    return fixer => {
      const sourceCode = context.getSourceCode();
      const quote = sourceCode.getText(node)[0];
      return fixer.replaceText(node, stringifyLiteral(replace, quote));
    };
  }

  function getEsmFix(node, { original, replace }) {
    if (!replace) return () => null;
    return fixer => {
      const sourceCode = context.getSourceCode();
      const statement = sourceCode
        .getText(node)
        .replace(`'${original}'`, `'${replace}'`)
        .replace(`"${original}"`, `"${replace}"`);
      return fixer.replaceText(node, statement);
    };
  }

  function checkDeprecated(node, { value }, getFix) {
    let item = deprecated.get(value);
    if (!item) return;

    // One module could have multiple names/paths in the past. Replace the array
    // of names in the deprecated description with the current model name.
    item = { ...item, original: value };

    const fix = getFix(node, item);
    const message = getMessage(item);
    const suggest = getSuggestion(item);
    const { original, replace, migrate, since, until } = item
    const data = { original, replace, migrate, since, until }

    context.report({
      node, ...message, data, fix, suggest: [{ ...suggest, data, fix }]
    });
  }
};
