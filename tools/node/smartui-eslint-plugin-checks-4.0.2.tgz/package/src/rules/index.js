// Export each rule by its name.
module.exports['deprecate-module'] = require('./deprecate-module');
module.exports['deprecate-method'] = require('./deprecate-method');
