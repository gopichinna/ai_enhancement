/**
 * Collects deprecated items with the specified key from all components.
 *
 * @example
 * // Returns an array of objects exported by `deprecated.module`
 * // from the component descriptors.
 * const deprecated = collectDeprecated(components, 'module');
 *
 * @param {*} components component descriptors exported from `src/component.js`
 * @param {*} key deprecation type, a key in the `deprecate` object
 * @param {*} verbose
 * @returns an arrow of deprecated types of the selected type
 */
module.exports.collectDeprecated = (components, key, stringify, verbose) => {
  if (verbose) console.log(`Collecting ${key} deprecations.`);
  const format = input => stringify && typeof input !== 'string' ? stringify(input) : input;
  const deprecated = [];
  // Look for deprecate[key] in the component descriptors.
  for (const prefix in components) {
    const { deprecate } = components[prefix];
    if (deprecate) {
      let items = deprecate[key];
      if (items) {
        // A value of deprecate[key] can be an object or an array of objects.
        if (!Array.isArray(items)) items = [items];
        if (verbose) {
          console.log(`  ${items.length} ${key} deprecations from ${prefix}:`);
          for (let { original, replace, migrate, since, until } of items) {
            // Original module name can be an array of names, if the same module
            // was moved one or more times earlier.
            if (Array.isArray(original)) {
              original = `${format(original)[0]}[${original.length}]`;
            } else {
              original = format(original);
            }
            let sign = '-'
            if (migrate) {
              replace = migrate;
              sign = '~'
            }
            console.log(`    ${original}${replace ? ' ' + sign + '> ' + format(replace) : ''} (${
              since}${until ? ' - ' + until : ''})`);
          }
        }
        deprecated.push(...items);
      }
    }
  }
  return deprecated;
}

/**
 * Formats a string literal.
 * Surrounds it with quotes and escapes them inside the string.
 *
 * @example
 * // Returns '"test"'.
 * stringifyLiteral('test', '"');
 *
 * @param {*} value string value to format as a literal
 * @param {*} quote character to use as a quote
 * @returns a string literal
 */
module.exports.stringifyLiteral = (value, quote) =>
  `${quote}${value.replaceAll(quote, `\\${quote}`)}${quote}`;
