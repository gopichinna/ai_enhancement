module.exports.smartui = require('./smartui.json');
