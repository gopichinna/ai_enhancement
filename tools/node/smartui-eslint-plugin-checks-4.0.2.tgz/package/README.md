# @smartui/eslint-plugin-checks

ESLint plugin for performing static checks of Smart UI projects.

See an [example of the `eslint` configuration] in a Smart UI project sample.

**Attention:**
* If you need to stay with ESlint 7.x, use the release line `^2.0.0`. Upgrade your project soon to be able to use ESLint 8.x or newer, so that you can use the latest version of this tool.

The latest version is `^3.0.0`.

## Synopsis

ESLint configuration optimised for Smart UI projects:

```yml
plugins:
  - '@smartui/checks'
extends:
  - plugin:@smartui/checks/productive
overrides:
  -
    files:
      - "**/test/**/*.js"
    extends:
      - plugin:@smartui/checks/test
```

## Installation

Install the package `@smartui/eslint-plugin-checks` locally as a development dependencies:

    npm i -D @smartui/eslint-plugin-checks --registry https://artifactory.opentext.net/artifactory/api/npm/npm_virt/

## Usage

The plugin package has to be referred to in the `eslint` configuration to be able to use its content. Omit the common `eslint` plugin package prefix (`eslint-plugin-`) when referring to the plugin package:

```yml
plugins:
  - '@smartui/checks'
```

## Rules

The following rules are available for static code checks of Smart UI projects:

* [deprecate-module] - deprecates usage of RequireJS modules
* [deprecate-method] - deprecates usage of object methods

Insert the plugin prefix before the rule name, for example:

```yml
rules:
  '@smartui/checks/deprecate-module': error
  '@smartui/checks/deprecate-method': warn
```

All rules are configured to the `warn` level in the `@smartui/checks/productive` configuration.

## Environments

* [smartui] - declares global variables available in RequireJS modules

Insert the plugin prefix before the environment name, for example:

```yml
env:
  "@smartui/checks/smartui": true
```

This environment is included in the `@smartui/checks/productive` configuration.

## Configs

* [productive] - recommended configuration for productive code
* [test] - recommended configuration for test code

Insert the plugin prefix before the config name, for example:

```yml
extends:
  - plugin:@smartui/checks/productive
```

## Development

Clone this repository, install the dependencies and run the tests:

    git clone git@gitlab.otxlab.net:smartui/tools/eslint-plugin-checks.git
    cd eslint-plugin-checks
    npm ci
    cd example
    npm ci
    # demonstrate failed checks
    npm test
    cd ..
    # run unit tests
    npm test

Read about [adding a new rule].

[example of the `eslint` configuration]: ./example/.eslintrc.yml
[deprecate-module]: ./doc/rules/deprecate-module.md
[deprecate-method]: ./doc/rules/deprecate-method.md
[smartui]: ./src/environments/smartui.json
[productive]: ./src/configs/productive.json
[test]: ./src/configs/test.json
[adding a new rule]: ./doc/add-rule.md
