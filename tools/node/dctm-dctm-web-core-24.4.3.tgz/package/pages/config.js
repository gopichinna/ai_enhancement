(function () {
  'use strict';

  const appContext = window.location.pathname.split('/')[1],
    UNLOAD_TIME_KEY = 'unloadTime',
    STALE_PRELOAD_THRESHOLD = 24 * 60 * 60 * 1000, //A day
    selfLocation = getSelfLocation(),
    bypassLocalDataCache = getUrlParameterValue('skip_data_cache') === 'true',
    additionalFilesToLoad = [],
    additionalFilesLoaded = [],
    bundleIndexes = [],
    bootstrapPromises = [],
    bootReadyCallbacks = [],
    appExtensions = [];

  let booting = true, bootReady = false, hasBootError = false;

  // --------------- START: Set defaults for configuration ---------------
  window.sv = window.sv || {};
  window.sv.freezeInitConfigBeforeInit = window.sv.freezeInitConfigBeforeInit === undefined ? true : window.sv.freezeInitConfigBeforeInit;
  window.sv.config = window.sv.config || {};
  window.csui.mobile = !!window.sv.config.mobile;
  window.sv.requirejs = csui.requirejs;
  window.sv.require = csui.require;
  window.sv.define = csui.define;
  window.sv.getUrlParameterValue = getUrlParameterValue;
  window.sv.getPreloadData = getPreloadData;
  window.sv.savePreloadData = savePreloadData;

  const config = window.sv.config;

  config.build = config.build || '';
  config.mobile = !!config.mobile;
  config.appworks = !!config.appworks;
  config.pluginData = config.pluginData || {};
  config.baseLocation = config.baseLocation || '../ui';
  config.otherBundlesLocation = config.otherBundlesLocation || '';
  config.svfPackagePath = config.baseLocation + config.otherBundlesLocation;
  config.buildMode = config.buildMode || 'release';

  const versionQueryString = `${config.buildMode === 'src' ? '' : `v=${config.build}`}`;

  let locHrefSplit = window.location.href.split('/');
  locHrefSplit.splice(locHrefSplit.indexOf('ui'));
  config.connection = config.connection || {
    url: locHrefSplit.join('/'),
    supportPath: '/'
  };
  config.connection.headers = config.connection.headers || {};

  const accessibleCompliantInUrl = getUrlParameterValue('accessible_compliant'),
    preloadData = getPreloadData(),
    handleBootError = config.handleError || console.error;
  delete config.handleError;

  if(accessibleCompliantInUrl && config.embedMode === true){
    config.defaultAccessibleCompliant = (accessibleCompliantInUrl === 'true');
  }

  const loadableLocales = {},
    localeInUrl = getUrlParameterValue('locale');
  (config.loadableLocales || ['root']).forEach(function (loc) {
    loadableLocales[loc] = true;
  });
  config.i18n = config.i18n || {};
  config.i18n.locale = config.i18n.locale || localeInUrl;
  config.i18n.loadableLocales = config.i18n.loadableLocales || loadableLocales;
  config.lang = {};
  config.lang.enforcedLocale = config.i18n.locale;
  if(!config.i18n.locale) {
    config.i18n.locale = preloadData.locale;
  }
  config.i18n.rtl = config.i18n.rtl || undefined;

  config.log = config.log || {
    level: 'WARN',
    consoleRe: false,
    performanceTimeStamp: false,
    moduleNameStamp: false,
    modules: {}
  };
  // --------------- END: Set defaults for configuration ---------------

  function getUrlParameterValue(name) {
    var expression = new RegExp('\\b' + name + '(?:=([^&]*))?', 'i'),
      result = expression.exec(location.search);
    return result ? result[1] != null ? decodeURIComponent(result[1]) : '' : null;
  }

  function getSelfLocation() {
    var currentScript = document.currentScript || (function() {
      var scripts = document.getElementsByTagName('script');
      return scripts[scripts.length - 1];
    })();
    if(!currentScript) return;
    var selfPath = currentScript.src;
    var queryStart = selfPath.indexOf('?');
    if (queryStart > 0) {
      selfPath = selfPath.substring(0, queryStart);
    }
    var anchorStart = selfPath.indexOf('#');
    if (anchorStart > 0) {
      selfPath = selfPath.substring(0, anchorStart);
    }
    var lastSlash = selfPath.lastIndexOf('/');
    selfPath = lastSlash > 0 ? selfPath.substring(0, lastSlash) : '.';

    return selfPath;
  }

  function getQualifiedStoreKey(key) {
    return key && ['SV', appContext, key].join(':');
  }

  function getValueFromStorage(key, storage) {
    var storeKey = getQualifiedStoreKey(key);
    return storage && storage.getItem(storeKey);
  }

  function setValueToStorage(key, value, storage) {
    var storeKey = getQualifiedStoreKey(key);
    storage && storage.setItem(storeKey, JSON.stringify(value));
  }

  function getPreloadData() {
    var preloadTab = JSON.parse(getValueFromStorage('preloadTab', window.sessionStorage)),
      preloadData = JSON.parse(getValueFromStorage('preloadData', window.localStorage));

    if(preloadTab && preloadTab.tabId && preloadData && preloadData.tabs && (typeof preloadData.tabs[preloadTab.tabId] === 'object')) {
      var data = preloadData.tabs[preloadTab.tabId];
      delete data[UNLOAD_TIME_KEY];
      return data;
    }

    return {};
  }

  function savePreloadData(data) {
    var preloadTab = JSON.parse(getValueFromStorage('preloadTab', window.sessionStorage)),
      preloadData = JSON.parse(getValueFromStorage('preloadData', window.localStorage)) || {},
      currTime = new Date().getTime();

    if(!preloadTab || !(preloadTab.tabId)) {
      preloadTab = {tabId: new Date().getTime() + '-' + Math.floor(Math.random() * 1000)};
      setValueToStorage('preloadTab', preloadTab, window.sessionStorage);
    }

    var tabs = preloadData.tabs || {};
    tabs[preloadTab.tabId] = data;
    data[UNLOAD_TIME_KEY] = currTime + STALE_PRELOAD_THRESHOLD;
    preloadData.tabs = tabs;

    for(var tab in tabs) {
      if(tabs.hasOwnProperty(tab)) {
        if(!tabs[tab][UNLOAD_TIME_KEY] || ((currTime - tabs[tab][UNLOAD_TIME_KEY]) > STALE_PRELOAD_THRESHOLD)) {
          delete tabs[tab];
        }
      }
    }

    setValueToStorage('preloadData', preloadData, window.localStorage);
  }

  function addStartupFile(filePath) {
    if(!(['.js', '.json'].some(ext => filePath.endsWith(ext)))) {
      filePath += '.js';
    }
    additionalFilesToLoad.push(filePath);
  }

  function addBundleIndex(bundlePath) {
    if(config.buildMode !== 'src') {
      if(!bundlePath.endsWith('.js')) {
        bundlePath += '.js';
      }
      bundleIndexes.push(bundlePath);
    }
  }

  function loadJs({src, queryString}, callback) {
    if(queryString && src.indexOf(queryString) < 0) {
      const u = new URL(src, selfLocation);
      if(u.searchParams.size) {
        src = `${src}&${queryString}`;
      } else {
        src = `${src}?${queryString}`;
      }
    }

    const el = document.createElement('script');
    el.src = src;
    el.type = 'text/javascript';
    if (callback) {
      el.addEventListener('load', callback);
    }
    document.getElementsByTagName("head")[0].appendChild(el);
  }

  function loadJsFiles({base, files, queryString}, callback) {
    function loadJsFile(file) {
      loadJs({src: base + file, queryString}, function () {
        const next = files.shift();
        if (next) {
          loadJsFile(next);
        } else if (callback) {
          callback();
        }
      });
    }

    if(files.length) {
      loadJsFile(files.shift());
    } else {
      callback && callback();
    }
  }

  function loadRemainingStartupFiles(callback) {
    additionalFilesToLoad.forEach(f => {
      additionalFilesLoaded.push(f);
    });
    const loadFile = () => {
      const file = additionalFilesToLoad.shift();
      if(file) {
        loadJs({src: config.baseLocation + file, queryString: versionQueryString}, ()=>{
          Promise.all(bootstrapPromises).finally(loadFile);
        });
      } else if(callback) {
        callback();
      }
    };
    loadFile();
  }

  function addGuardedFunction(originalFunction) {
    window.sv[originalFunction.name] = function() {
      const a = arguments;
      let validScript;
      try {
        throw new Error();
      }catch(e) {
        let stackTrace = e.stack.split('\n');
        let selfIndex = stackTrace.findIndex((se)=> se.indexOf(`${selfLocation}/config.js`) !== -1);
        if(selfIndex !== -1) {
          const callerEntry = (stackTrace.length > (selfIndex + 1)) ? stackTrace[selfIndex + 1] : null;
          validScript = callerEntry && additionalFilesLoaded.some(f => {
            const baseUrl = selfLocation.endsWith('/') ? selfLocation : selfLocation + '/';
            const fileUrl = new URL((config.devMode === true ? '' : new URL(baseUrl).pathname) + config.baseLocation + f, baseUrl).toString();
            return callerEntry.indexOf(fileUrl) > 0;
          });
        }
      }

      if(validScript) {
        return originalFunction.apply(null, arguments);
      } else {
        console.error(`Startup annexture rejected: unknown source`);
      }
    };

    Object.defineProperty(window.sv[originalFunction.name], 'name', {value: originalFunction.name, writable: false});
  }

  function bootHold() {
    if(booting) {
      let
        resolve, reject,
        promise = new Promise((res, rej) => {
          resolve = res;
          reject = rej;
        });
      promise.resolve = resolve;
      promise.reject = reject;
      bootstrapPromises.push(promise);
      return promise;
    } else {
      console.warn(`Boot hold rejected as already past booting phase.`);
    }
    return Promise.resolve();
  }

  function addBootReadyCallback(callback) {
    if(!bootReady){
      bootReadyCallbacks.push(callback);
    }else{
      console.warn('Cannot process the provided bootReady callback')
    }
  }

  function addExtension(extensionPath) {
    appExtensions.push(extensionPath);
  }

  function loadExtensions(callback) {
    if(appExtensions.length) {
      csui.require(appExtensions.map(ext => `nuc/lib/require.config!${ext}`), callback, handleBootError);
    } else {
      callback && callback();
    }
  }

  function completeBundleLoading(callback) {
    if(bundleIndexes.length) {
      loadJsFiles({base: config.baseLocation, files: bundleIndexes.slice(1), queryString: versionQueryString}, callback);
    } else {
      callback && callback();
    }
  }

  async function processBootReadyCallbacks(callback) {
    try {
      for (const bootReadyCb of bootReadyCallbacks) {
        await Promise.resolve(bootReadyCb());
      }
      callback();
    } catch (err) {
      handleBootError();
    }
  }

  function normalizeLangSetting(callback) {
    csui.require(['i18n'], (i18n)=>{
      let loc = i18n.settings.locale.split('-')[0],
          browserLocaleSplit = navigator.language.split('-');


      if (i18n.settings.loadableLocales.indexOf(loc) === -1) {
        i18n.settings.locale = loc = 'en';
      }
      if (i18n.settings.rtl === undefined || i18n.settings.rtl === null || i18n.settings.rtl === false) {
        if (loc === 'ar' || loc === 'he') {
          i18n.settings.rtl = true;
        }
      }
      i18n.settings.acceptLanguage = i18n.settings.locale;

      preloadData.locale = i18n.settings.locale;
      savePreloadData(preloadData);

      if(browserLocaleSplit.length > 1 && browserLocaleSplit[0] === loc){
        i18n.settings.preferredLocales = [{
          locale: navigator.language,
          quality: 1
        }];
      }

      callback && callback(loc, i18n.settings.rtl === true);
    }, handleBootError);
  }

  function loadTheme(isRtl, callback) {
    csui.require([
      'nuc/lib/jquery'
    ], function($){
      const hasRtlCss = isRtl && (config.buildMode !== 'src');

      // Prepare RTL mode on the whole page
      if (hasRtlCss) {
        document.documentElement.setAttribute('dir', 'rtl');
        document.body.className += ' rtl';
      }

      // Insert the main theme stylesheet
      var themeCss = config.mobile
        ? (`${config.baseLocation}${config.otherBundlesLocation}/mobile/themes/mobile/theme`)
        : (`${config.baseLocation}${config.otherBundlesLocation}/csui/themes/carbonfiber/theme`);

      $('<link>')
        .attr('rel', 'stylesheet')
        .attr('type', 'text/css')
        .attr('href', themeCss + (hasRtlCss ? '-rtl' : '') + `.css${versionQueryString ? `?${versionQueryString}` : ''}`)
        .appendTo('head');

      callback();
    }, handleBootError);
  }

  function loadLocalizationBundles(locale, callback) {
    if(config.buildMode !== 'src' && locale !== 'en') {
      bundleIndexes.forEach(indexPath => {
        const match = /\/bundles\//.exec(indexPath);
        if(match.length) {
          const
            splitIndex = match.index + '/bundles/'.length,
            part1 = indexPath.substring(0, splitIndex),
            part2 = indexPath.substring(splitIndex),
            finalIndexPath = `${part1}nls/${locale}/${part2}`;
          loadJs({src: `${config.baseLocation}${finalIndexPath}`, queryString: versionQueryString}, null);
        }
      });
    }
    callback && callback();
  }

  function handleError(error) {
    hasBootError = true;
    handleBootError(error);
  }

  let
    extBasePath = (config.devMode === true && config.buildMode === 'src') ? selfLocation : undefined,
    paths = {
      nuc: config.svfPackagePath + '/nuc',
      smart: config.svfPackagePath + '/smart',
      csui: config.svfPackagePath + '/csui',
      esoc: config.svfPackagePath + '/esoc',
      dctmw: config.svfPackagePath + '/dctmw',
      "dctm-ext": (extBasePath ? (extBasePath + '/..') : config.baseLocation) + config.otherBundlesLocation + '/dctmw/utils/load-extensions/load-extensions'
    };

  addBundleIndex(`${config.otherBundlesLocation}/nuc/bundles/nuc-index.js`);
  addBundleIndex(`${config.otherBundlesLocation}/csui/bundles/csui-app-index.js`);
  addBundleIndex(`${config.otherBundlesLocation}/smart/bundles/smart-index.js`);
  addBundleIndex(`${config.otherBundlesLocation}/esoc/bundles/esoc-index.js`);
  addBundleIndex(`${config.otherBundlesLocation}/dctmw/bundles/dctmw-index.js`);

  const tempStartupFiles = [], tempBundleIndexes=[], moduleCollectionOrder = {};
  for(const p of Object.keys(config.pluginData)) {
    const pkg = config.pluginData[p];
    const pkgOrder = ((typeof pkg.order === 'number') && (pkg.order !== NaN)) ? pkg.order : -1;
    moduleCollectionOrder[p] = pkgOrder;
    if(pkg.basePath) {
      paths[p] = config.baseLocation + pkg.basePath;
      if(((typeof pkg.initScript) === 'string') && pkg.initScript !== '') {
        tempStartupFiles.push({file: `${pkg.basePath}/${pkg.initScript}`, order: pkgOrder});
      }
      if(((typeof pkg.indexFile) === 'string') && pkg.indexFile !== '') {
        tempBundleIndexes.push({file: `${pkg.basePath}/bundles/${pkg.indexFile}`, order: pkgOrder});
      }
    } else {
      paths[p] = config.baseLocation + config.otherBundlesLocation + '/' + p;
      if(((typeof pkg.initScript) === 'string') && pkg.initScript !== '') {
        tempStartupFiles.push({file: `${config.otherBundlesLocation}/${p}/${pkg.initScript}`, order: pkgOrder});
      }
      if(((typeof pkg.indexFile) === 'string') && pkg.indexFile !== '') {
        tempBundleIndexes.push({file: `${config.otherBundlesLocation}/${p}/bundles/${pkg.indexFile}`, order: pkgOrder});
      }
    }
  }

  tempStartupFiles.sort((a, b)=> (a.order - b.order));
  tempStartupFiles.map(sf => sf.file).forEach(addStartupFile);
  tempBundleIndexes.sort((a, b)=> (a.order - b.order));
  tempBundleIndexes.map(sf => sf.file).forEach(addBundleIndex);

  csui.require.config({
    urlArgs: (config.buildMode === 'src' ? null : versionQueryString),
    paths: paths,
    map: {
      '*': {
        'nuc/models/authenticated.user/server.adaptor.mixin': 'dctmw/server.adaptors/models/nuc/authenticated.user.mixin',
        'nuc/models/member/server.adaptor.mixin': 'dctmw/server.adaptors/models/nuc/member.mixin',
        'nuc/models/member/member.server.adaptor.mixin': 'dctmw/server.adaptors/models/nuc/member.mixin',
        'nuc/models/node/server.adaptor.mixin': 'dctmw/server.adaptors/models/nuc/node.mixin',
        'csui/utils/commands/sign.out': 'dctmw/commands/sign.out',
        // esoc modules
        'esoc/model/pulsesettings/server.adaptor.mixin': 'dctmw/server.adaptors/models/esoc/pulsesettings.model.mixin',
        // csui context & plugin override
        'csui/utils/contexts/impl/csui.context.plugin': 'nuc/contexts/context.plugin',
        'csui/utils/contexts/page/page.context': 'dctmw/pages/app/application.context',
        'csui/models/widget/search.results/search.settings/server.adaptor.mixin': 'dctmw/server.adaptors/models/csui/models/widget/search.results/search.settings/server.adaptor.mixin',
        //others
        'csui/models/widget/favorites.model': 'dctmw/models/widgets/favorites/favorites',
        'smart/mixins/view.events.propagation/view.events.propagation.mixin': 'dctmw/controls/mixins/view.events.propagation.mixin',
        'smart/mixins/layoutview.events.propagation/layoutview.events.propagation.mixin': 'dctmw/controls/mixins/layoutview.events.propagation.mixin',
        'dctmw/models/stm.server.adaptor.mixin': 'dctmw/server.adaptors/models/dctmw/dctm.stm.server.adaptor.mixin'
      }
    },
    config: {
      'nuc/contexts/factories/connector': {
        connection: config.connection
      },
      'i18n': config.i18n,
      'nuc/utils/log': config.log,
      'csui-ext': {
        ignoreRequireErrors: true
      },
      'csui/utils/routing': {
        developmentPage: true
      },
      'nuc/utils/base': {
        formatIsoDateTimeInUtc: true
      },
      'nuc/models/node/node.model': {
        usesIntegerId: false
      },
      'nuc/models/mixins/uploadable/uploadable.mixin': {
        useMock: true,
        useJson: true,
        usePatch: true
      },
      'nuc/lib/moment': {
        suppressSeconds: true
      },
      'csui/controls/tile/behaviors/perfect.scrolling.behavior': {
        usePerfectScrollbar: false
      },
      'dctmw/models/module.collection': {
        moduleOrder: moduleCollectionOrder
      },
      'dctmw/utils/authenticators/base.authenticator': {
        applicationPageUrl: '#signout',
        signinPageUrl: '#signin'
      },
      'dctmw/utils/authenticators/ct.otds.token.authenticator':{
        otdsCallbackPageUrl: config.otdsCallbackPageUrl
      },
      'dctmw/utils/authenticators/session': {
        defaultAccessibleCompliant: config.defaultAccessibleCompliant,
        accessibilityEnabled: config.defaultAccessibleCompliant || (!config.mobile && !config.embedMode && (preloadData.accessibilityEnabled === true)),
        enforcedLocale: config.lang.enforcedLocale
      },
      'csui/utils/accessibility': {
        enabled: config.defaultAccessibleCompliant || (!config.embedMode && (preloadData.accessibilityEnabled === true))
      },
      'dctmw/utils/geolocation.utils': {
        embedMode: !!config.embedMode,
        enableLocationTracking: false,
        mandatorylocationTracking: false
      },
      'dctmw/utils/sw.utils': {
        connection: config.connection
      },
      'dctmw/extensions/authenticators':{
        embedMode: !!config.embedMode
      },
      'csui/widgets/navigation.header/navigation.header.controls': {
        masks: {
          defaults: {
            whitelist: [
              'csui/widgets/navigation.header/controls/home/home.view',
              /*'csui/widgets/navigation.header/controls/breadcrumbs/breadcrumbs.view',*/
              /*'csui/widgets/navigation.header/controls/search/search.view',*/
              'csui/widgets/navigation.header/controls/user.profile/user.profile.view'/*,
              'csui/widgets/navigation.header/controls/favorites/favorites.view'*/
            ]
          }
        }
      }
    }
  });

  addGuardedFunction(bootHold);
  addGuardedFunction(addBootReadyCallback);
  addGuardedFunction(addBundleIndex);
  addGuardedFunction(addExtension);
  addGuardedFunction(handleError);
  
  if(window.sv.freezeInitConfigBeforeInit !== false) {
    Object.freeze(window.sv);
  }

  csui.require([
    'nuc/lib/jquery',
    'nuc/lib/underscore',
    'nuc/lib/require.config!nuc/nuc-extensions.json',
    'nuc/lib/require.config!dctmw/dctmw-extensions.json'
  ], ($, _)=>{
    //This is required only if REST server is remote
    $.ajaxSetup({
      xhrFields: {
        withCredentials: true
      }
    });

    if(bypassLocalDataCache === true) {
      //To always bypass service worker cache
      $.ajaxSetup({
        headers: {
          'X-SW-NO-CACHE': true
        }
      });
    }

    if(!config.mobile) {
      addExtension(`smart/smart-extensions.json`);
      addExtension(`csui/csui-extensions.json`);
    }
    addExtension(`esoc/esoc-extensions.json`);

    loadRemainingStartupFiles(()=>{
      booting = false;
      Promise.all(bootstrapPromises).finally(() => {
        if(!hasBootError) {
          completeBundleLoading(()=>{
            normalizeLangSetting((locale, isRtl)=>{
              loadTheme(isRtl, ()=>{
                csui.require([
                  'dctmw/utils/sw.utils'
                ], function(swUtils){
                  swUtils.initialize().always(() => {
                    loadLocalizationBundles(locale, ()=>{
                      loadExtensions(()=>{
                        bootReady = true;
                        processBootReadyCallbacks(() => {
                          const event = new CustomEvent('dctmw:loaded');
                          document.dispatchEvent(event);
                          config.startup && config.startup();
                        });
                      });
                    });
                  });
                }, handleBootError);
              });
            });
          });
        }
      });
    });
  }, handleBootError);
})();
