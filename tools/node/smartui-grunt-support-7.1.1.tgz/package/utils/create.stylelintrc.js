// Creates configurations for stylelint for Linting CSS-like languages and CSS within containers.
//         - CSS-like languages, e.g. SCSS, Sass and Less
//         - CSS within containers, e.g. in HTML, CSS-in-JS and Vue SFCs
//
// function createStylelintConfig(options?)
//   options:
//     rootDir:      if `stylelintrc` is not specified, their
//                   default names will be appended to `rootDir`
//                   ('..' by default)
//     stylelintrc:     output file to write the main configuration to
//                   ('../stylelintrc.yml' by default)
//     verbose:      print more details on the console
//                   (false by default)
//
// const createStylelintConfig = require('@smartui/grunt-support/utils/create.stylelintrc');
//
// createStylelintConfig();
//
// The .stylelintrc.yml files will be overwritten only if
// they do not start with a line-comment. If you edit the file locally and you
// do not want to be updated whenever you run `npm ci`, add a comment on its
// first line.
//
// This module is supposed to be used with the current directory set to `src`
// of the particular Smart UI project. If you set the current directory to
// some other directory, set `rootDir` or `stylelintrc`.

'use strict';

const { accessSync, constants, existsSync, readFileSync, writeFileSync } = require('fs');

const contentJs = `extends:
  - stylelint-config-standard
`;

module.exports = function (options) {
  // Default parameter values.
  let { rootDir = '..', stylelintrc, verbose } = options;
  if (!stylelintrc) stylelintrc = `${rootDir}/.stylelintrc.yml`;

  console.log('Generating the stylelintrc configuration.');
  tryUpdate(stylelintrc, contentJs);

  // If stylelintrc exists and is not writable, it will be ignored. This file
  // is not critical and the initial Nucleus migration did not include it.
  function tryUpdate (fileName, content) {
    let fileUpdated;
    try {
      fileUpdated = needsUpdate(fileName);
    } catch {
      if (verbose) {
        console.log(`  Ignoring not writable ${fileName}.`);
      }
      fileUpdated = false;
    }
    if (fileUpdated) {
      if (verbose) {
        console.log(`  Writing ${fileName}.`);
      }
      writeFileSync(fileName, content);
    }
  }

  // Let the file updated only if it does not start with a line-comment,
  // which means that it was customised and must not be overwritten.
  function needsUpdate (fileName) {
    if (existsSync(fileName)) {
      const content = readFileSync(fileName, 'utf8');
      if (content.startsWith('#')) {
        if (verbose) {
          console.log(`  Ignoring customised ${fileName}.`);
        }
        return false;
      }
      accessSync(fileName, constants.R_OK | constants.W_OK);
    }
    return true;
  }
};
