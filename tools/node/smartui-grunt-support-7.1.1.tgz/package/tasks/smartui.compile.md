# Compile Smart UI Project

Reads Smart UI sources and writes output bundles. Compound task running low-level tasks.

## Disabling Low-level Tasks

Some of the task run by the `smartuiCompile` task can be disabled by the `tasks` option. For example, disable all checks:

```js
smartuiCompile: {
  all: {
    options: {
      bundles: requirejsModules,
      bundleIndexes: requirejsBundleIndexes,
      tasks: {
        requirejsIndexCheck: false,
        requirejsContentCheck: false,
        requirejsBundleCheck: false,
        requirejsDependencyCheck: false
      }
    }
  }
}
```
