'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { collectModules, collectDependencies } = require('../utils/collect.dependencies');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-contrib-clean');

  grunt.registerMultiTask('smartuiCompile',
    'Performs all tasks to build debug and release project output',
    function (task) {
      const options = this.options({
        config: 'config-build.js',
        rootDir: '..',
        appDir: '.',
        debugDir: '../out-debug',
        releaseDir: '../out-release',
        languageDir: '../out-languagepack_en',
        oscriptModuleName: undefined,
        oscriptInputDir: '../srcmodules',
        oscriptOutputDir: '../out-module',
        oscriptSupportDir: 'support',
        fileExclusionRegExp: /(?:\.spec\.js$)|(?:\bGruntfile\.js$)|(?:\bcomponent\.js$)/,
        buildNumber: undefined,
        version: undefined,
        isScript: undefined,
        onBuildRead: undefined,
        onBuildWrite: undefined,
        onModuleBundleComplete: undefined,
        logLevel: undefined,
        bundles: [],
        bundleIndexes: {},
        moduleDependencies: [],
        projectDependencies: [],
        checkExceptions: [],
        rebaseSourceMap: {},
        allowIndexedPrivateModules: false,
        minifyJSONBundleIndexes: false,
        force: false,
        tasks: undefined
      });
      let {
        config, rootDir, appDir, debugDir: bundleDir, releaseDir, languageDir,
        oscriptModuleName, oscriptInputDir, oscriptOutputDir, oscriptSupportDir,
        fileExclusionRegExp, bundles, bundleIndexes, checkExceptions,
        moduleDependencies, projectDependencies, minifyJSONBundleIndexes: json,
        rebaseSourceMap, allowIndexedPrivateModules, version, buildNumber,
        logLevel, force, isScript, onBuildRead, onBuildWrite, onModuleBundleComplete,
        tasks = {}
      } = options;
      const prefix = Object.keys(bundleIndexes).length &&
        /^bundles\/(\w+)-/.exec(Object.keys(bundleIndexes)[0])[1];
      if (!projectDependencies.length) {
        projectDependencies = collectDependencies(rootDir);
      }
      if (!moduleDependencies.length) {
        moduleDependencies = collectModules(projectDependencies, { rootDir });
      }

      grunt.config.merge({
        // Copy, uglify and combine RequireJS modules to file bundles
        // See https://github.com/requirejs/r.js/blob/master/build/example.build.js.
        requirejsCompile: tasks.requirejsCompile !== false && {
          auto: {
            options: {
              prefix,
              config,
              projectDependencies,
              rootDir,
              appDir,
              bundleDir,
              bundles,
              fileExclusionRegExp,
              logLevel,
              onBuildRead,
              onBuildWrite,
              onModuleBundleComplete,
              rebaseSourceMap,
              isScript
            }
          }
        },

        // Check if bundle indexes refer to distinct collection of modules
        requirejsBundleCheck: tasks.requirejsBundleCheck !== false && {
          auto: {
            options: { appDir, bundleDir, bundles, force }
          }
        },

        // Check if modules from the bundle index module are bundled in the same bundle
        requirejsIndexCheck: tasks.requirejsIndexCheck !== false && {
          auto: {
            options: { appDir, output: bundleDir, bundles, force }
          }
        },

        // Check if bundles contain only modules from this component (with the same prefix)
        requirejsContentCheck: tasks.requirejsContentCheck !== false && {
          auto: {
            options: { bundleDir, bundles, exceptions: checkExceptions, force }
          }
        },

        // Check if we depend only on public modules
        requirejsDependencyCheck: tasks.requirejsDependencyCheck !== false && {
          auto: {
            options: {
              config,
              appDir,
              bundleDir,
              bundles,
              dependencies: moduleDependencies,
              allowIndexedPrivateModules,
              force
            }
          }
        },

        // Extract bundles index to csui-index.js and csui-index.json files
        requirejsBundleIndex: tasks.requirejsBundleIndex !== false && {
          auto: {
            options: { bundleDir, bundleIndexes, force }
          }
        },

        // Generate a complete module list of the specified bundle
        requirejsBundleTOC: tasks.requirejsBundleTOC !== false && {
          auto: {
            options: { bundleDir, bundles, force }
          }
        },

        // Minify the release JavaScript and JSON
        requirejsMinify: tasks.requirejsMinify !== false && {
          auto: {
            // Minifying JSON breaks the naive parsing of bundle indexes in CS
            options: { bundleDir: releaseDir, bundles, bundleIndexes, json, force }
          }
        },

        // Remove files and directories from the output which are not distributed
        requirejsCleanOutput: tasks.requirejsCleanOutput !== false && {
          auto_debug: { src: bundleDir },
          auto_release: { src: releaseDir }
        },

        // Remove files and directories from the output which are not distributed
        clean: tasks.clean !== false && {
          options: { force: true },
          auto_generated: ['bundles/*-index.*'],
          auto_release: [`${releaseDir}/*`],
          auto_language: [`${languageDir}/**`]
        },

        // Copies the debug build output to the release directory
        requirejsCopyRelease: tasks.requirejsCopyRelease !== false && {
          auto: {
            options: { debugDir: bundleDir, releaseDir, bundleIndexes }
          }
        },

        // Copy the module template and release output
        requirejsCopyOScript: tasks.requirejsCopyOScript !== false && {
          auto: {
            options: {
              moduleName: oscriptModuleName,
              inputDir: oscriptInputDir,
              outputDir: oscriptOutputDir,
              supportDir: oscriptSupportDir,
              releaseDir
            }
          }
        },

        // Replaces the build number in the extension-describing file
        requirejsGenerateVersion: tasks.requirejsGenerateVersion !== false && {
          auto: {
            options: { prefix, bundleDir, buildNumber, version }
          }
        },

        // Generate bundles of concatenated i18n modules in the default language
        // (English, locale'root') prepared for localization to other languages
        languagepack: tasks.languagepack !== false && {
          auto: {
            options: {
              inputDir: bundleDir,
              outputDir: languageDir,
              bundles,
              bundleIndexes,
              force
            }
          }
        },

        // Generate RTL versions of stylesheet bundles
        requirejsRtlCss: tasks.requirejsRtlCss !== false && {
          auto: {
            options: { prefix, bundleDir }
          }
        },

        // Minify the release stylesheets
        requirejsMinifyCss: tasks.requirejsMinifyCss !== false && {
          auto: {
            options: { prefix, bundleDir: releaseDir }
          }
        }
      });

      const debug = [];
      if (tasks.requirejsBundleIndex !== false) debug.push('requirejsBundleIndex:auto');
      if (tasks.requirejsCompile !== false) debug.push('requirejsCompile:auto');
      if (tasks.clean !== false) debug.push('clean:auto_generated');
      if (tasks.requirejsCleanOutput !== false) debug.push('requirejsCleanOutput:auto_debug');
      if (tasks.requirejsBundleTOC !== false) debug.push('requirejsBundleTOC:auto');
      if (tasks.requirejsIndexCheck !== false) debug.push('requirejsIndexCheck:auto');
      if (tasks.requirejsContentCheck !== false) debug.push('requirejsContentCheck:auto');
      if (tasks.requirejsBundleCheck !== false) debug.push('requirejsBundleCheck:auto');
      if (tasks.requirejsDependencyCheck !== false) debug.push('requirejsDependencyCheck:auto');
      if (tasks.clean !== false) debug.push('clean:auto_language');
      if (tasks.languagepack !== false) debug.push('languagepack:auto');
      if (tasks.requirejsGenerateVersion !== false) debug.push('requirejsGenerateVersion:auto');
      if (tasks.requirejsRtlCss !== false) debug.push('requirejsRtlCss:auto');

      const release = [];
      if (tasks.clean !== false) release.push('clean:auto_release');
      if (tasks.requirejsCopyRelease !== false) release.push('requirejsCopyRelease:auto');
      if (tasks.requirejsMinify !== false) release.push('requirejsMinify:auto');
      if (tasks.requirejsMinifyCss !== false) release.push('requirejsMinifyCss:auto');
      if (tasks.requirejsCleanOutput !== false) release.push('requirejsCleanOutput:auto_release');
      if (tasks.requirejsCopyOScript !== false) release.push('requirejsCopyOScript:auto');

      grunt.task.run(task === 'debug'
        ? debug
        : task === 'release'
          ? release
          : [...debug, ...release]);
    });
};
