'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-stylelint');
  loadLocalNpmTask(grunt, 'grunt-eslint');
  loadLocalNpmTask(grunt, 'grunt-jsonlint');

  grunt.registerMultiTask('smartuiCheck',
    'Performs static code checks on source and output files',
    function (task) {
      const options = this.options({
        rootDir: '..',
        debugDir: '../out-debug',
        scripts: ['*/**/*.js', '!lib/**'],
        stylesheets: ['**/*.css'],
        configs: ['**/*.json'],
        debugConfigs: undefined,
        pages: ['**/test/*.html'],
        eslintrc: '../.eslintrc.yml',
        eslintrcHtml: '../.eslintrc-html.yml',
        stylelintrc: '../.stylelintrc.yml',
        tasks: undefined
      });
      let {
        rootDir, debugDir, scripts, stylesheets, configs, debugConfigs,
        pages, eslintrc, eslintrcHtml, stylelintrc, tasks = {}
      } = options;
      if (!debugConfigs) debugConfigs = [`${debugDir}/*.json`];

      // Pass the project root to eslint plugins in @smartui/checks.
      // Allow both grunt-eslint and eslint to be used. But eslint
      // runs relatively to the project root, while grunt to the
      // Gruntfile directory.Switching cwd to the project root is
      // not possible, because the file paths retrieved by grunt
      // are relative to the Gruntfile (`src`) subdirectory.
      process.env.SMARTUI_PROJECT_ROOT = rootDir;

      grunt.config.merge({
        // Perform static code checks on JavaScript and HTML files
        eslint: tasks.eslint !== false && {
          auto: {
            options: { overrideConfigFile: eslintrc },
            src: scripts
          },
          auto_fix: {
            options: { overrideConfigFile: eslintrc, fix: true },
            src: scripts
          },
          auto_html: {
            options: { overrideConfigFile: eslintrcHtml },
            src: pages
          },
          auto_html_fix: {
            options: { overrideConfigFile: eslintrcHtml, fix: true },
            src: pages
          }
        },

        // Check that HTML attributes are enclosed in quotes
        checkHbsTemplateQuotes: tasks.checkHbsTemplateQuotes !== false && {
          auto: {
            files: [
              {
                expand: true,
                src: '**/*.hbs'
              }
            ]
          }
        },

        // Check correct format of the CSS source files
        stylelint: tasks.stylelint !== false && {
          auto: {
            options: { overrideConfigFile: stylelintrc },
            src: stylesheets
          },
          auto_fix: {
            options: { overrideConfigFile: stylelintrc, fix: true },
            src: stylesheets
          }
        },

        // Check correct format of the JSON source files
        jsonlint: tasks.jsonlint !== false && {
          auto_src: configs,
          auto_debug: debugConfigs
        }
      });

      const src = [];
      if (tasks.eslint !== false) src.push('eslint:auto');
      if (tasks.eslint !== false) src.push('eslint:auto_html');
      if (tasks.checkHbsTemplateQuotes !== false) src.push('checkHbsTemplateQuotes');
      if (tasks.stylelint !== false) src.push('stylelint:auto');
      if (tasks.jsonlint !== false) src.push('jsonlint:auto_src');

      const debug = [];
      if (tasks.jsonlint !== false) src.push('jsonlint:auto_debug');

      grunt.task.run(task === 'src'
        ? src
        : task === 'fix'
          ? ['eslint:auto_fix', 'eslint:auto_html_fix']
          : task === 'fix-styles'
            ? ['stylelint:auto_fix']
            : task === 'debug'
              ? debug
              : [...src, ...debug]);
    });
};
