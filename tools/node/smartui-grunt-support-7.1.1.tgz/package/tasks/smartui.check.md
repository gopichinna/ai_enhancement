# Check Smart UI Project

Performs static code checks of Smart UI sources. Compound task running low-level tasks.

## Disabling Low-level Tasks

Some of the task run by the `smartuiCheck` task can be disabled by the `tasks` option. For example, disable all checks:

```js
smartuiCompile: {
  all: {
    options: {
      bundles: requirejsModules,
      bundleIndexes: requirejsBundleIndexes,
      tasks: {
        eslint: false,
        checkHbsTemplateQuotes: false,
        stylelint: false,
        jsonlint: false
      }
    }
  }
}
```
