# JATO Icons Bundler
JATO Icons Bundler is a tool that generates a single JavaScript file based on the given svg file names.
As a pre-requisite, package.json should include "@jato/svgs" as dependency, such that, this tool will 
obtain the svg content from jato npm package.


The following is an example of such a generated bundle:
```javascript
  let icons = {
    'actionCloseSmall': `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.85307 4.14632C4.6578 3.95106 4.34122 3.95106 4.14596 4.14632C3.9507 4.34159 3.9507 4.65817 4.14596 4.85343L7.29259 8.00007L4.14618 11.1465C3.95092 11.3417 3.95092 11.6583 4.14618 11.8536C4.34145 12.0488 4.65803 12.0488 4.85329 11.8536L7.9997 8.70717L11.146 11.8534C11.3412 12.0487 11.6578 12.0487 11.8531 11.8534C12.0483 11.6582 12.0483 11.3416 11.8531 11.1463L8.70681 8.00007L11.8533 4.85358C12.0486 4.65832 12.0486 4.34174 11.8533 4.14647C11.658 3.95121 11.3414 3.95121 11.1462 4.14647L7.9997 7.29296L4.85307 4.14632Z" fill="#313233" style="fill:#313233;fill:color(display-p3 0.1922 0.1961 0.2000);fill-opacity:1;"/>
    </svg>
    `,
    'actionChevronSmallDown': `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M4.14645 6.14645C4.34171 5.95118 4.65829 5.95118 4.85355 6.14645L8 9.29289L11.1464 6.14645C11.3417 5.95118 11.6583 5.95118 11.8536 6.14645C12.0488 6.34171 12.0488 6.65829 11.8536 6.85355L8 10.7071L4.14645 6.85355C3.95118 6.65829 3.95118 6.34171 4.14645 6.14645Z" fill="#313233" style="fill:#313233;fill:color(display-p3 0.1922 0.1961 0.2000);fill-opacity:1;"/>
    </svg>
    `,
    'actionChevronSmallUp': `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.8536 9.85357C11.6583 10.0488 11.3417 10.0488 11.1464 9.85357L8 6.70712L4.85355 9.85357C4.65829 10.0488 4.34171 10.0488 4.14645 9.85357C3.95118 9.65831 3.95118 9.34172 4.14645 9.14646L8 5.29291L11.8536 9.14646C12.0488 9.34172 12.0488 9.65831 11.8536 9.85357Z" fill="#313233" style="fill:#313233;fill:color(display-p3 0.1922 0.1961 0.2000);fill-opacity:1;"/>
    </svg>
    `,
    'actionChevronSmallLeft': `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M9.85363 4.14645C10.0489 4.34171 10.0489 4.65829 9.85363 4.85355L6.70718 8L9.85363 11.1464C10.0489 11.3417 10.0489 11.6583 9.85363 11.8536C9.65837 12.0488 9.34178 12.0488 9.14652 11.8536L5.29297 8L9.14652 4.14645C9.34178 3.95118 9.65837 3.95118 9.85363 4.14645Z" fill="#313233" style="fill:#313233;fill:color(display-p3 0.1922 0.1961 0.2000);fill-opacity:1;"/>
    </svg>`
    };
    return icons;
```

## Installation
```shell
npm install @smartui/jato-icons-bundler -D --registry https://artifactory.opentext.net/artifactory/api/npm/npm_virt/
```
## Usage
Typically, if you use it in another npm based project, you could add the following
to the scripts in `package.json`, where -i is the list of icon names delimited with pipe symbol,
 -f is the name of the javascript file name to be generated and -d is the destination directory.

```shell
jatoiconsbundler -i \"actionPlay|actionPinFilled|actionPreferences\" -d dest -f smart.jato.icons -v
```

#### Wrap as AMD module (require.js):
```shell
jatoiconsbundler -i \"actionPlay|actionPinFilled|actionPreferences\" -a -d dest -f smart.jato.icons -v
```
The javascript (./dest/smart.jato.icons.js) to load the icons is then wrapped:
```
define([], function () {
....
});
```

#### Wrap as AMD module (require.js) and specify a module name to be used for the define:
```shell
jatoiconsbundler -i \"actionPlay|actionPinFilled|actionPreferences\" -a csui -d dest -f smart.jato.icons -v
```
The wrapper then starts with:
```
csui.define([], function () {
....
});
```

## Options
```
--version      Show version number
-v, --verbose  Be more verbose (log processed files, etc.) 
-i, --icons    In one of the below ways you can send JATO icon names. \n 1. Pipe-separated JATO icon names \n 2. Text file which has line-separated JATO icon names
Example for "Pipe-separated JATO icon names": "actionPlay|actionPinFilled|actionPreferences"
Example for "Text file which has line-separated JATO icon names": "icons/jato.action.icons.txt"
Contents of jato.action.icons.txt file should be as below...
actionPlay
actionPinFilled
actionPreferences
-d, --dest     Destination directory (must exist)
-f, --file     Destination file name
-a, --amd      Wrap as AMD (require.js) and prefix define with module name ("-a csui" will 
produce csui.define in the wrapper). If -a is specified without further argument, a define 
without a module prefix is added.
--help         Show help
```
Note that icon's names can be obtained from https://cybersecurity-enterprise.glpages.otxlab.net/ux-aspects/jato/design-tokens/#/svgs.

## Usage in AMD module
From the respective module, leading application has to define the above generated Javascript file
and can obtain the svg content from the reference.

For example, if the above Javascript file is created at "myModule/icons/smart.icons.js", then reference
looks like below.

```javascript
define([
  'nuc/lib/underscore', 'nuc/lib/jquery', 'nuc/lib/marionette',
  'myModule/icons/smart.icons'
], function (_, $, Marionette, svfIcons) {
  templateHelpers: function () {
      return {
        closeSVG: svfIcons.actionCloseSmall,
        upSVG: svfIcons.actionChevronSmallUp,
        downSVG: svfIcons.actionChevronSmallDown
      };
    },
});
```