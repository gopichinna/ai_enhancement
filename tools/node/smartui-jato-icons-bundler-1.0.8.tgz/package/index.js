const bundler = require('./lib/bundler.js');

module.exports = bundler;
