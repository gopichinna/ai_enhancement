const fs = require('fs');
const prefixDirPath = './test/generated.files';
const generatedFiles = [
    `${prefixDirPath}/svf.jato.js.icons.js`,
    `${prefixDirPath}/svf.jato.es6.icons.js`,
    `${prefixDirPath}/svf.jato.amd.icons.js`
];

async function testBundleSpec() {

    generatedFiles.forEach((file) => {
        try {
            if (fs.statSync(file)) {
                console.info(`${file} generated successfully!`);
            } else {
                console.error(`${file} NOT generated.`);
            }
        } catch (err) {
            console.error(`error while generating ${file} file, error message : ${err}`);
        }
    })
}

testBundleSpec();
