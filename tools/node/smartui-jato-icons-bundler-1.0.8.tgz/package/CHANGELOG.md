## [1.0.2](https://gitlab.otxlab.net/smartui/tools/jato-icons-bundler/compare/v1.0.3...v1.0.2) (2024-09-25)



## [1.0.3](https://gitlab.otxlab.net/smartui/tools/jato-icons-bundler/compare/v1.0.2...v1.0.3) (2024-09-25)



## [1.0.2](https://gitlab.otxlab.net/smartui/tools/jato-icons-bundler/compare/v1.0.1...v1.0.2) (2024-09-25)



## 1.0.0 (2024-25-09)

Initial release.
