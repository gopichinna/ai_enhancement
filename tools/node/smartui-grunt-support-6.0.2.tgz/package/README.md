# Grunt Support for Smart UI Projects

Grunt tasks and utilities to check, compile, package and test Smart UI projects.

See the the `.md` files with the description of the Grunt tasks in the [tasks] directory. See the `.md` files with the description of the primary shared utilities for [config], [build], [test], [updater] and [server] scenarios. The low-level utilities are documented by leading comments in the source files in the [utils] directory.

**Warning:**
* If you need to stay with Jasmine 2.x, use the release line `^3.0.0`. Upgrade your project soon to be able to use Jasmine 4.x or newer, so that you can use the latest version of this tool.

The latest version is `^4.0.0`.

## Synopsis

An example of the four compound Grunt tasks used in `src/Gruntfile.js` and `test/Gruntfile.js`:

```js
smartuiCheck: {
  all: {}
},
smartuiCompile: {
  all: {
    options: {
      bundles: requirejsModules,
      bundleIndexes: requirejsBundleIndexes
    }
  }
},
smartuiPackage: {
  all: {}
},
smartuiTest: {
  all: {}
}
```

An example of the configuration generation and static asset serving from `package.json`:

```js
"scripts": {
  "prepare": "csui-configure",
  "start": "csui-serve"
}
```

## Installation

When you start a Smart UI project, you usualy install both `@smartui/csui-dependency-installer` and `@smartui/grunt-support`, the former for downloading Smart UI dependencies and the latter for building your project.

The first version, which is simpler, but will require manual upgrading `@smartui/csui-dependency-installer`, `@smartui/grunt-support` and other packages from the `@smartui` scope, when a fix or feature is added to some of those packages:

    npm set -L project @smartui:registry https://artifactory.opentext.net/artifactory/api/npm/npm_virt/
    npm i -D @smartui/csui-dependency-installer @smartui/grunt-support

The second version, which needs additional NPM packages, but it will upgrade `@smartui/csui-dependency-installer`, `@smartui/grunt-support` and other extra packages automatically, when a fix or feature is added to some of those packages:

    npm set -L project @smartui:registry https://artifactory.opentext.net/artifactory/api/npm/npm_virt/
    npm i -D @pkgdep/extra @pkgdep/link
    npx dep-extra i @smartui/csui-dependency-installer @smartui/grunt-support

The work with the project will be the same in both cases. Install, build, test and start the development server, for example:

    npm ci
    npm run build
    npm run test
    npm start

## Automatic or Manual Update

The automatic update saves the effort to install always the latest version of an NPM module. While we want to depend on the same version of an OSS dependency to ensure a stable build environment, we want to consume the "daily build" of an internally developed package to ensure an early integration. Some teams make changes every day and publish unstable versions of their package every day too. Constantly upgrading to the latest development version might cost too much effort.

The price for installing always the latest version, without having to modify `package.json` and `package-lock.json` is longer installation time and package lock changes. For example, installing just the `@smartui/grunt-support` package, which has a lot of peer dependencies, means:

| The way of installation              | Duration [min] | Automatic upgrade? | Package lock changes? | Dependencies locked? |
|:-------------------------------------|---------------:|:------------------:|:---------------------:|:--------------------:|
| From devDependencies                 |        1:15 ✅ |        no ❌       |          no ✅        |         yes ✅       |
| From devDependencies + `npm up`      |        1:35 ✅ |       yes ✅       |         yes ❌        |           ?          |
| From extraDependencies (`dep-extra`) |        2:30 ❌ |       yes ✅       |          no ✅        |         no ❌        |

If you depend on an NPM package with a low frequency of published releases, an occasional manual upgrade will be probably fine - the first option. For example, you do the manual upgrade regularly each quarter and if a bug occurs, then ad-hoc. If you depend on an NPM package with a high frequency of published releases or betas, you will be choosing between the latter two options.

The latter two options can be avoided by alternative deployment options. For example, Smart UI projects can be deployed using `ixmk` (most of them), `npm` (two of them) and `@smartui/csui-dependency-installer` (all of them). If you don't deploy Smart UI project artefacts by `npm`, the only internal NPM packages remaining will be `@smartui/csui-dependency-installer` and `@smartui/grunt-support`, which fall to the category of low-frequency releases.

## Peer Dependencies

This package will add the following NPM modules to the `node_modules` directory of the target project:

```json
{
  "@smartui/eslint-plugin-checks": "^1.5.1",
  "concat-source-text": "^2.0.0",
  "eslint-plugin-html": "^7.1.0",
  "grunt": "^1.6.1",
  "grunt-karma": "^4.0.2",
  "grunt-mkdir": "^1.1.0",
  "grunt-subgrunt": "^1.3.0",
  "is-docker": "^2.2.1",
  "jasmine-core": "^4.6.0",
  "karma": "^6.4.1",
  "karma-brief-reporter": "^0.2.2",
  "karma-chrome-launcher": "^3.1.1",
  "karma-coverage": "^2.2.0",
  "karma-html-reporter": "^0.2.7",
  "karma-jasmine": "^5.1.0",
  "karma-mocha-reporter": "^2.2.5",
  "karma-requirejs": "^1.1.0",
  "karma-requirejs-esm-preprocessor": "^1.0.6",
  "time-grunt": "^2.0.0"
}
```

These NPM modules will be regularly upgraded, which saves the maintenance effort in Smart UI projects. However, this may lead to peer dependency conflicts in more complicated projects, which need other NPM modules than `@smartui/csui-dependency-installer` and `@smartui/grunt-support`.

## Examples

Examples of `package.json`, `src/Gruntfile.js` anbd `test/Gruntfile.js` from a simple Smart UI project.

### package.json

The contents of `csui-dependencies` is used by the Grunt tasks only to get the component prefixes of the Smart UI dependencies. It is not used to get their versions or download their packages. See [csui-dependency-installer] for more information about this configuration and about installing the dependencies and language packs.

The first version, which is simpler, but will require manual upgrading `@smartui/csui-dependency-installer`, `@smartui/grunt-support` and other packages from the `@smartui` scope, when a fix or feature is added to some of those packages:

```js
{
  "private": true,
  "scripts": {
    "prepare": "install-csui-dependencies && csui-configure",
    "build": "cd src && grunt",
    "check": "cd src && grunt check",
    "compile": "cd src && grunt compile",
    "test": "cd test && grunt release",
    "start": "csui-serve"
  },
  "csui-dependencies": {
    "dependencies": [
      "nuc", "smart", "csui"
    ]
  },
  "devDependencies": {
    "@smartui/csui-dependency-installer": "^4.0.0",
    "@smartui/grunt-support": "^4.0.0"
  }
  "keywords": []
}
```

The second version, which needs additional NPM packages, but it will upgrade `@smartui/csui-dependency-installer`, `@smartui/grunt-support` and other extra packages automatically, when a fix or feature is added to some of those packages:

```js
{
  "private": true,
  "scripts": {
    "prepare": "dep-extra i && dep-link ln && install-csui-dependencies && csui-configure",
    "build": "cd src && grunt",
    "check": "cd src && grunt check",
    "compile": "cd src && grunt compile",
    "test": "cd test && grunt release",
    "start": "csui-serve"
  },
  "csui-dependencies": {
    "dependencies": [
      "nuc", "smart", "csui"
    ]
  },
  "devDependencies": {
    "@pkgdep/extra": "^1.3.1",
    "@pkgdep/link": "^1.2.2"
  },
  "extraDependencies": {
    "@smartui/csui-dependency-installer": "^4.0.0",
    "@smartui/grunt-support": "^4.0.0"
  }
  "keywords": []
}
```

### src/Gruntfile.js

```js
module.exports = grunt => {
  // Collect information about this project
  const requirejsModules = [
    { name: 'bundles/esme-all' }
  ];
  const requirejsBundleIndexes = {
    'bundles/esme-index': ['bundles/esme-all']
  };

  // Declare Grunt tasks to compile this project
  grunt.config.init({
    smartuiCheck: {
      all: {}
    },
    smartuiCompile: {
      all: {
        options: {
          bundles: requirejsModules,
          bundleIndexes: requirejsBundleIndexes
        }
      }
    },
    smartuiPackage: {
      all: {}
    }
  });

  // Load the Grunt task implementation
  grunt.loadTasks('../node_modules/@smartui/grunt-support/tasks');

  // Register standard Grunt task aliases
  grunt.registerTask('check', ['smartuiCheck:all:src']);
  grunt.registerTask('debug', ['smartuiCompile:all:debug']);
  grunt.registerTask('release', ['smartuiCompile:all:release']);
  grunt.registerTask('compile', ['debug', 'release']);
  grunt.registerTask('package', ['smartuiPackage']);
  grunt.registerTask('default', ['check', 'compile', 'package']);
};
```

### test/Gruntfile.js

```js
module.exports = grunt => {
  // Declare Grunt tasks to test this project
  grunt.initConfig({
    subgrunt: {
      check: { '../src': ['check'] },
      options: { npmInstall: false }
    },
    smartuiTest: {
      all: {}
    }
  });

  // Load the Grunt task implementation
  grunt.loadTasks('../node_modules/grunt-subgrunt/tasks');
  grunt.loadTasks('../node_modules/@smartui/grunt-support/tasks');

  // Register standard Grunt task aliases
  grunt.registerTask('check', ['subgrunt:check']);
  grunt.registerTask('debug', ['smartuiTest:all:debug']);
  grunt.registerTask('release', ['smartuiTest:all:release']);
  grunt.registerTask('specs', ['debug', 'release']);
  grunt.registerTask('default', ['check', 'specs']);
};
```

[tasks]: ./tasks
[config]: ./config
[build]: ./build
[test]: ./test
[updater]: ./updater
[server]: ./server
[utils]: ./utils
[csui-dependency-installer]: https://gitlab.otxlab.net/ferdipr/csui-dependency-installer#smartuicsui-dependency-installer
