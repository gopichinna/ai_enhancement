const { preprocessor: originalPreprocessor } = require('requirejs-esm-preprocessor');
const { normalizeConfigLocation, loadBuildConfig, loadComponentsDescriptors } = require('../utils/load.config');
const { isScript: defaultIsScript, getScriptRules } = require('../utils/is.script');

function cutQuery (url) {
  const questionMark = url.indexOf('?');
  return questionMark > 0 ? url.substring(0, questionMark) : url;
}

module.exports = function preprocessor (options = {}) {
  let { isScript, srcDir, configName, configPath, verbose } = options;

  if (!(srcDir || configPath)) srcDir = 'src';
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));
  const components = loadComponentsDescriptors({ srcDir, configPath, verbose });
  const { prefix } = loadBuildConfig({ configPath, verbose });
  if (verbose) {
    console.log('Script recognition:');
    console.log(JSON.stringify(getScriptRules(components, prefix), undefined, 2));
  }

  const finalIsScript = path => defaultIsScript(components, path, prefix) && (!isScript || isScript(path));
  return originalPreprocessor({
    ...options,
    isScript: path => finalIsScript(cutQuery(path))
  });
};
