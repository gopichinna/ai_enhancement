const { configure: originalConfigure, startServer: originalStartServer } = require('requirejs-esm-preprocessor');
const { normalizeConfigLocation, loadBuildConfig, loadComponentsDescriptors } = require('../utils/load.config');
const { isScript: defaultIsScript, getScriptRules } = require('../utils/is.script');
const preprocessor = require('./preprocessor');

function configure (args, name, version, options) {
  return originalConfigure(args, name, version, {
    port: +(process.env.PORT || 7777),
    securePort: +(process.env.SECURE_PORT || 9999),
    ...options
  });
}

function cutQuery (url) {
  const questionMark = url.indexOf('?');
  return questionMark > 0 ? url.substring(0, questionMark) : url;
}

function startServer (options = {}, server, secureServer, handler) {
  let { isScript, srcDir, configName, configPath, verbose } = options;

  if (!(srcDir || configPath)) srcDir = 'src';
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));
  const components = loadComponentsDescriptors({ srcDir, configPath, verbose });
  const { prefix } = loadBuildConfig({ configPath, verbose });
  if (verbose) {
    console.log('Script recognition:');
    console.log(JSON.stringify(getScriptRules(components, prefix), undefined, 2));
  }

  const finalIsScript = path => defaultIsScript(components, path, prefix) && (!isScript || isScript(path));
  return originalStartServer({
    port: +(process.env.PORT || 7777),
    secureOptions: { port: +(process.env.SECURE_PORT || 9999) },
    ...options,
    isScript: path => finalIsScript(cutQuery(path))
  }, server, secureServer, handler);
}

function serve (options) {
  startServer(options).catch(err => console.error(err));
}

module.exports = { preprocessor, configure, startServer, serve };
