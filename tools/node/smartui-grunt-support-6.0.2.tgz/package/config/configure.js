const { collectDependencies } = require('../utils/collect.dependencies')
const { inferPrefix } = require('../utils/load.config')

function usage (name) {
  console.log(`Launches a development web server.

Usage: ${name} [option...]

Options:
  -p|--prefix <name>    project prefix
  -d|--deps <names>     comma-delimited dependency prefixes
  -r|--root-dir <path>  path to the project root    (default: ".")
  -s|--src-dir <path>   path to the project sources (default: "src")
  -v|--[no-]verbose     print more about progress   (default: false)
  -V|--version          print version number
  -H|--help             print usage instructions

Prefix is inferred from the <srcDir>/*-extensions.json file name by default.
Dependencies are inferred from csui-dependencies in package.json by default.

Examples:
  ${name}
  ${name} -v`)
}

module.exports = function configure(args, name, version, options = {}) {
  let {
    prefix, dependencies, rootDir = '.', srcDir = 'src', verbose
  } = options

  for (let i = 0, l = args.length; i < l; ++i) {
    const arg = args[i]
    const match = /^(?:-|--)(no-)?([a-zA-Z][-a-z]*)$/.exec(arg)
    if (match) {
      const flag = match[1] !== 'no-'
      switch (match[2]) {
        case 'p': case 'prefix':
          prefix = args[++i]
          continue
        case 'd': case 'deps':
          dependencies = args[++i].split(',').map(dep => dep.trim())
          continue
        case 'r': case 'root-dir':
          rootDir = args[++i]
          continue
        case 's': case 'src-dir':
          srcDir = args[++i]
          continue
        case 'v': case 'verbose':
          verbose = flag
          continue
        case 'V': case 'version':
          console.log(version)
          process.exit(0)
          break
        case 'H': case 'help':
          usage(name)
          process.exit(0)
      }
    }
    console.error(`Unknown argument: "${arg}".`)
    process.exit(1)
  }

  if (!prefix) prefix = inferPrefix(srcDir)
  if (!dependencies) dependencies = collectDependencies(rootDir);

  return { prefix, dependencies, rootDir, srcDir, verbose }
}
