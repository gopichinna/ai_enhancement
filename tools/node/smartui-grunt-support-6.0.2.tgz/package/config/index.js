const configure = require('./configure');
const generate = require('./generate');

module.exports = { configure, generate };
