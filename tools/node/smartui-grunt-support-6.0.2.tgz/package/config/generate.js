const { existsSync } = require('fs');
const createEslintConfig = require('../utils/create.eslintrc');
const createBuildConfig = require('../utils/create.build.config');
const { inferPrefix, normalizeConfigLocation, setBuildConfig } = require('../utils/load.config');
const { collectDependencies } = require('../utils/collect.dependencies');

module.exports = function generate({ prefix, dependencies = [], rootDir = '.', srcDir = 'src', configName, configPath, extraConfig, verbose } = {}) {
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));

  if (!existsSync(srcDir)) {
    return console.warn('Source directory not found. Skipping the configuration generation.');
  }

  if (!prefix) prefix = inferPrefix(srcDir);
  if (!dependencies.length) dependencies = collectDependencies(rootDir);

  const { buildConfig } = createBuildConfig({
      prefix,
      dependencies,
      ...extraConfig
    }, {
      buildConfig: configPath,
      editorConfig: `${rootDir}/config-editor.js`,
      nucleusPath: `${rootDir}/lib/src/nuc`,
      verbose
    });
  buildConfig.prefix = prefix;
  setBuildConfig(buildConfig);

  createEslintConfig({
    eslintrc: `${rootDir}/.eslintrc.yml`,
    eslintrcHtml: `${rootDir}/.eslintrc-html.yml`,
    verbose
  });
}
