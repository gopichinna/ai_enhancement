// Returns a parsed r.js build configuration. Expects a script with the
// `require.config` statement.
//
// const parse = require('@smartui/grunt-support/utils/parse.build.config');
// const config = parse('config-build.js');
//
// Returns {
//   paths: {
//     nuc: 'empty:',
//     csui: '.'
//   }
// }

'use strict';

const { readFileSync } = require('fs');

const configs = new Map();

function parseFile (fileContents) {
  // just remember the object passed to require.config
  const require = {
    config: object => (config = object)
  };
  // support output bundles with namespaced requirejs
  const csui = { require }; // eslint-disable-line no-unused-vars
  // perform the require.config statement from the file source
  let config;
  eval(fileContents); // eslint-disable-line no-eval
  return config;
}

module.exports = function (filePath) {
  let config = configs.get(filePath);
  if (config) {
    return config;
  }
  const fileContents = readFileSync(filePath, 'utf-8');
  config = parseFile(fileContents);
  if (!config) {
    throw new Error(`Parsing "${filePath}" failed.`);
  }
  configs.set(filePath, config);
  return config;
};
