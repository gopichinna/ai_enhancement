// Schedule files for cleaning by the task `requirejsCleanOutput`.
//
// scheduleFileForCleaning(files)
// Schedules a file or an array of files for deletion by its path(s)
// relative to the `src` directory.
//
// checkAndRemoveFileForCleaning(file)
// Returns `true` if a file was scheduled for deletion and removes it
// from the list of the scheduled files.

const filesToClean = new Set();

function normalizeFile (file) {
  return file.toLowerCase().replaceAll('\\', '/');
}

module.exports = {
  scheduleFileForCleaning (files) {
    if (!Array.isArray(files)) {
      files = [files];
    }
    for (const file of files) {
      filesToClean.add(normalizeFile(file));
    }
  },

  checkAndRemoveFileForCleaning (file) {
    file = normalizeFile(file);
    for (const scheduled of filesToClean) {
      if (file.endsWith(scheduled)) {
        filesToClean.delete(scheduled);
        return true;
      }
    }
  }
};
