// Loads one or more tasks located in an NPM module.
//
// const { loadLocalNpmTask, loadParentNpmTask } = require('@smartui/grunt-support/utils/load.npm.tasks');
//
// module.exports = function (grunt) {
//   loadLocalNpmTask(grunt, 'grunt-contrib-clean');
//   loadParentNpmTask(grunt, 'grunt-karma');
//
// loadLocalNpmTask (grunt, task)
// ------------------------------
//
// Looks for the tasks in NPM modules installed in the current project
// - added to the current `package.json`.
//
// loadParentNpmTask (grunt, task)
// -------------------------------
//
// Looks for `node_modules` in ancestor directories of the current one.
// The first directory that it finds will be used to load the requested tasks
// from. This function can be used to load tasks from peer dependencies
// installed to the parent project.

const { existsSync } = require('fs');

function findLocalModule (task) {
  const pkg = require.resolve(`${task}/package.json`);
  return pkg.substring(0, pkg.length - 12);
}

function loadLocalNpmTask (grunt, task) {
  grunt.loadTasks(`${findLocalModule(task)}/tasks`);
}

function findParentNodeModules () {
  let dir = 'node_modules';
  let count = 10;
  do {
    dir = `../${dir}`;
  } while (!existsSync(dir) && --count);
  return dir;
}

function loadParentNpmTask (grunt, task) {
  grunt.loadTasks(`${findParentNodeModules()}/${task}/tasks`);
}

module.exports = { loadLocalNpmTask, loadParentNpmTask };
