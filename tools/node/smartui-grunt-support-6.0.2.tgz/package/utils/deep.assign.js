// A deep-merge version of `Object.assign`. Traverses objects and merges values
// of the same keys, which are both objects recursively.
// If an array is detected, a "shallow concat" is performed. The result array
// contains all items from the target array and appended items from the source
// array, which were not included in the target array.
//
// const { loadBuildConfig } = require('@smartui/grunt-support/utils/load.config');
// const deepAssign = require('@smartui/grunt-support/utils/deep.assign');
//
// const config = loadBuildConfig();
// deepAssign(config, {
//   paths: { conws: '../lib/src/conws' }
// });
//
// Returns the modified config

const isObject = obj => obj && typeof obj === 'object';
const isArray = Array.isArray;

module.exports = function deepAssign (result, ...objects) {
  for (const obj of objects) {
    for (const key in obj) {
      const target = result[key];
      const source = obj[key];
      if (isArray(target) && isArray(source)) {
        result[key] = [...new Set([...target, ...source])];
      } else if (isObject(target) && isObject(source)) {
        result[key] = deepAssign(target, source);
      } else {
        result[key] = source;
      }
    }
  }
  return result;
};
