// Finds the package.json of the package in the context of the current package.
// Looks to the specified directory and then to ten ancestors. If the starting
// directory is not provided, `INIT_CWD` or the current directory will be used
// as default.
//
// const loadPackageJson = require('../utils/load.package.json');
// const { pkgDir, pkg } = loadPackageJson();
//
// pkgDir => where package.json was found (string)
// pkg => parsed content of package.json (object)

const { join, resolve } = require('path');
const { promises } = require('fs');
const { readFile } = promises;

module.exports = async function loadPackageJson ({ rootDir: pkgDir, limit = 10, verbose } = {}) {
  if (!pkgDir) pkgDir = process.env.INIT_CWD || process.cwd();

  let pkgPath, pkgContent;
  for (let i = 0; i < limit; ++i, pkgDir = resolve(pkgDir, '..')) {
    if (verbose) console.log(`Looking for package.json in ${pkgDir}.`);
    try {
      pkgPath = join(pkgDir, 'package.json');
      pkgContent = await readFile(pkgPath, 'utf8');
      break;
    } catch {}
  }
  if (!pkgContent) {
    throw new Error('package.json not found in the current and ancestor directories');
  }
  if (verbose) console.log(`Parsing ${pkgPath}.`);
  const pkg = JSON.parse(pkgContent);
  return { pkgDir, pkgPath, pkgContent, pkg };
};
