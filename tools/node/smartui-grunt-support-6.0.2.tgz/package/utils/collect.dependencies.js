// Provides functions to collect RequireJS plugins, public modules and module
// prefixes of Smart UI dependencies. All functions expect that they are
// executed in the `src` directory. If not, the `rootDir` parameter has to be
// provided and point top the project root.
//
// collectPlugins(prefixes, { rootDir = '..' } = {})
// -------------------------------------------------
//
// Returns an array with plugin module names collected from Smart UI projects
// with the specified module prefixes. Each Smart UI project is supposed
// to return them by `getAllRequireJsPlugins` exported from `src/component/js`,
// if there are any.
//
// const { collectPlugins } = require('@smartui/grunt-support/utils/collect.dependencies');
//
// const plugins = collectPlugins(['nuc', 'smart', 'csui']);
//
// Returns ['css', ... 'txt']
//
// collectModules(prefixes, { rootDir = '..' } = {})
// -------------------------------------------------
//
// Returns an array with all public module names module names from Smart UI
// projects with the specified module prefixes. Each Smart UI project is supposed
// to return them by `getAllModules` exported from `src/component/js`.
//
// const { collectModules } = require('@smartui/grunt-support/utils/collect.dependencies');
//
// const plugins = collectModules(['nuc', 'smart', 'csui']);
//
// Returns ['nuc/lib/backbone', ... 'csui/widgets/search.results/search.results.view']
//
// collectDependencies(rootDir = '..')
// -------------------------------------------------
//
// Returns an array of module prefixes of Smart UI dependencies for the current
// project. It uses the configuration of `csui-dependency-installer` in
// `package.json`.
// If the `csui-dependency-installer` is not used to install the dependencies,
// versions of the dependencies do not have to specified there.
//
// const { collectDependencies } = require('@smartui/grunt-support/utils/collect.dependencies');
//
// const deps = collectDependencies();
//
// Returns ['nuc', 'smart', 'csui']

const { readFileSync } = require('fs');
const { isAbsolute, join } = require('path');

const cwd = process.cwd();

function collectPlugins (prefixes, { rootDir = '..' } = {}) {
  let plugins = [];
  if (!isAbsolute(rootDir)) rootDir = join(cwd, rootDir);
  for (const prefix of prefixes) {
    const { getAllRequireJsPlugins } = require(`${rootDir}/lib/src/${prefix}/component`);
    if (getAllRequireJsPlugins) {
      plugins = [...plugins, ...getAllRequireJsPlugins()];
    }
  }
  return plugins;
}

function collectModules (prefixes, { rootDir = '..' } = {}) {
  let modules = [];
  if (!isAbsolute(rootDir)) rootDir = join(cwd, rootDir);
  for (const prefix of prefixes) {
    const { getAllModules } = require(`${rootDir}/lib/src/${prefix}/component`);
    if (getAllModules) {
      modules = [...modules, ...getAllModules()];
    }
  }
  return modules;
}

function collectDependencies (rootDir = '..') {
  if (!isAbsolute(rootDir)) rootDir = join(cwd, rootDir);
  const pkg = readFileSync(`${rootDir}/package.json`, 'utf8');
  const { 'csui-dependencies': config = {} } = JSON.parse(pkg);
  const { dependencies = [] } = config;
  return dependencies.map(dep => dep.split(':')[0]);
}

module.exports = { collectPlugins, collectModules, collectDependencies };
