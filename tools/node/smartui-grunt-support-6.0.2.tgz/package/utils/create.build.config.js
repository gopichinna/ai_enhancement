// Creates build and editor configuration files for RequireJS:
//   src/config-build.js
//   config-editor.js
//
// function createBuildConfig(configObject, configOptions?)
//   configObject:  part of the build configuration (at least the dependencies)
//   configOptions:
//     buildConfig:  output file to write the build configuration to
//                   ('config-build.js' by default)
//     editorConfig: output file to write the editor configuration to
//                   ('../config-editor.js' by default)
//     nucleusPath:  relative path to nucleus source directory
//                   ('../lib/src/nuc' by default)
//
//  Returns an object with:
//   buildConfig:         object passed to require.config in config-build.js
//   buildConfigUpdated:  boolean set if config-build.js was updated
//   editorConfig:        object passed to require.config in config-editor.js
//   editorConfigUpdated: boolean set if config-editor.js was updated
//
// Example from `src/Gruntfile.js` in the `Greetings` component:
//
// require('../lib/src/nuc/grunt-tasks/utils/create.build.config')({
//   prefix: 'greet', dependencies: ['csui'] // 'nuc' is always included
// });
//
// Alternative way supplying the object for `require.config` directly:
//
// require('../lib/src/nuc/grunt-tasks/utils/create.build.config')({
//   paths: {
//     nuc:   'empty:',
//     csui:  'empty:',
//     greet: '.'
//   }
// });
//
// You can combine the prefix & dependencies and paths & map ways together.
// The contents of paths & map will win in case of conflicts.
//
// The programmatic way reading the input parameters from the project files:
//
// const { loadBuildConfig } = require('@smartui/grunt-support/utils/load.config');
// const { collectDependencies } = require('@smartui/grunt-support/utils/collect.dependencies');
// const createBuildConfig = require('@smartui/grunt-support/utils/create.build.config');
//
// const { prefix } = loadBuildConfig();
// const dependencies = collectDependencies();
//
// const { buildConfig } = createBuildConfig({ prefix, dependencies });
//
// The config-build and config-editor files will be overwritten only if they
// do not start with a line-comment. If you edit the file locally and you do
// not want to be updated whenever you run `npm ci`, add a comment on its first
// line.
//
// This module is supposed to be used with the current directory set to `src`
// of the particular Smart UI project. If you set the current directory to
// some other directory, set `buildConfig`, `editorConfig` and `nucleusPath`.

'use strict';

const { accessSync, constants, existsSync, readFileSync, writeFileSync } = require('fs');
const { basename, dirname, isAbsolute, resolve } = require('path');

module.exports = function createBuildConfig (configObject, buildOptions, alternativeNucleusPath) {
  // Infer paths from prefix and dependencies.
  const { prefix } = configObject;
  if (prefix) {
    const dependencies = configObject.dependencies || [];
    if (!dependencies.includes('nuc')) {
      dependencies.unshift('nuc');
    }
    // Remember the original paths if they were provided.
    const originalPaths = configObject.paths;
    configObject.paths = { [prefix]: '.' };
    for (const depPrefix of dependencies) {
      // When config-build is generated for the parent project itself,
      // do not replace the "." set above with "empty:".
      if (prefix !== depPrefix) configObject.paths[depPrefix] = 'empty:';
    }
    // Let the explicitly specified paths from the original object override
    // the generated paths from the simplified syntax.
    Object.assign(configObject.paths, originalPaths);
    // Do not leave items not recognised by RequireJS in the configuration.
    delete configObject.prefix;
    delete configObject.dependencies;
  }

  // Compatibility - buildOptions used to be a string called buildConfig.
  if (typeof buildOptions !== 'object') {
    buildOptions = { buildConfig: buildOptions };
  }
  // Compatibility - nucleusPath used to be the third parameter.
  if (alternativeNucleusPath) {
    buildOptions.nucleusPath = alternativeNucleusPath;
  }

  // Default parameter values.
  const {
    buildConfig = 'config-build.js',
    editorConfig = '../config-editor.js',
    nucleusPath = '../lib/src/nuc',
    verbose = false
  } = buildOptions;

  console.log('Generating the build configuration.');

  const srcPath = nucleusPath.replace(/\/nuc$/, '');
  const pathsFromRoot = {};
  const moduleRenames = {};

  // Collect the paths to project roots of each dependency.
  for (const compPrefix in configObject.paths) {
    // Paths to the project root, not to the src directory.
    pathsFromRoot[compPrefix] = `${srcPath}/${compPrefix}`;
  }
  // Prevent files from opening from two paths - src/ and lib/src/<prefix>,
  // depending on what was the path, which it was found at.
  if (basename(dirname(resolve(buildConfig))) === 'src') {
    pathsFromRoot[prefix] = 'src';
  }

  // Collect module rename maps from extensions registration files.
  for (const compPrefix in configObject.paths) {
    let extensionsPath = `${pathsFromRoot[compPrefix]}/${compPrefix}-extensions.json`;
    // Relative paths in Node.js modules are resolved against the script
    // source directory; not against the process current directory, where
    // the Smart UI components are installed.
    if (!isAbsolute(extensionsPath)) {
      extensionsPath = `${process.cwd()}/${extensionsPath}`;
    }

    // The paths configuration can point to directories with pre-bundled
    // libraries, which are no Smart UI projects.
    try {
      require.resolve(extensionsPath);
      verbose && console.log(`  "${compPrefix}" - extensions.json found`);
    } catch (error) {
      verbose && console.warn(`  "${compPrefix}" - extensions.json missing`);
      continue;
    }

    try {
      const { rename } = require(extensionsPath);
      if (rename) {
        const renameCount = Object.keys(rename).length;
        const renameText = renameCount === 1 ? 'entry' : 'entries';
        if (verbose) {
          console.log(`  Adding ${renameCount} renaming map ${renameText} from "${compPrefix}".`);
        }
        Object.assign(moduleRenames, rename);
      }
    } catch (error) {
      console.warn(`  Loading the extension registrations for "${compPrefix}" failed:`);
      console.warn(`  File path: "${extensionsPath}".`);
      console.warn(`  Current directory: "${process.cwd()}".`);
      console.warn(`  ${error.stack}`);
    }
  }

  // Collect RequireJS plugins provided by the components depended on.
  for (const compPrefix in configObject.paths) {
    const configPath = configObject.paths[compPrefix];
    // Skip the components that are not excluded. They do not need to
    // re-include some modules for the build like the RequireJS plugins.
    // When config-build is generated for nucleus itself,
    // process it, although its path is not set to "empty:".
    if (configPath !== 'empty:' && prefix !== compPrefix) continue;

    let compModule = `${pathsFromRoot[compPrefix]}/component`;
    // Relative paths in Node.js modules are resolved against the script
    // source directory; not against the process current directory, where
    // the Smart UI components are installed.
    if (!isAbsolute(compModule)) {
      compModule = `${process.cwd()}/${compModule}`;
    }

    // The paths configuration can point to directories with pre-bundled
    // libraries, which are no Smart UI projects.
    try {
      require.resolve(compModule);
      verbose && console.log(`  "${compPrefix}" - component.js found`);
    } catch (error) {
      verbose && console.warn(`  "${compPrefix}" - component.js missing`);
      continue;
    }

    try {
      let { emptyDependencies, getRequireJsPluginPaths } = require(compModule);

      if (prefix === compPrefix && emptyDependencies) {
        if (typeof emptyDependencies === 'function') {
          emptyDependencies = emptyDependencies();
        }
        for (const depPrefix of emptyDependencies) {
          configObject.paths[depPrefix] = 'empty:';
        }
        const pathCount = Object.keys(emptyDependencies).length;
        const pathText = pathCount === 1 ? 'path' : 'paths';
        if (verbose) {
          console.log(`  Stubbing ${pathCount} ${pathText} from "${compPrefix}".`);
        }
      }

      if (getRequireJsPluginPaths) {
        let pluginPaths = getRequireJsPluginPaths();
        // When config-build is generated for nucleus itself,
        // path redirections starting with "nuc/" are not needed.
        if (prefix === compPrefix) {
          const keyPrefix = `${prefix}/`;
          pluginPaths = Object
            .keys(pluginPaths)
            .reduce((result, key) => {
              if (!key.startsWith(keyPrefix)) result[key] = pluginPaths[key];
              return result;
            }, {});
        }
        const pathCount = Object.keys(pluginPaths).length;
        const pathText = pathCount === 1 ? 'path' : 'paths';
        if (verbose) {
          console.log(`  Adding ${pathCount} ${pathText} from "${compPrefix}".`);
        }
        for (const sourceModule in pluginPaths) {
          const pluginPath = `lib/src/${compPrefix}/${pluginPaths[sourceModule]}`;
          // Modules base their paths on their `src` directory.
          configObject.paths[sourceModule] = `../${pluginPath}`;
          pathsFromRoot[sourceModule] = `./${pluginPath}`;
        }
      }
    } catch (error) {
      console.warn(`  Loading the component descriptor for "${compPrefix}" failed:`);
      console.warn(`  Module path: "${compModule}".`);
      console.warn(`  Current directory: "${process.cwd()}".`);
      console.warn(`  ${error.stack}`);
    }
  }

  // When config-build is generated for nucleus itself, the renaming map
  // for modules moved from csui to nuc is not needed.
  if (prefix !== 'nuc') {
    // csui-nuc module name map for loading the modules by their original names
    // Keep this consistent with config.js
    configObject.rename = Object.assign({
      'csui/lib/require.config': 'nuc/lib/require.config'
    }, moduleRenames, configObject.rename);

    // duplicate the renamed modules to the starMap to support build and other
    // tools than need to track the remapped modules by the standard property
    // (the rename map is be used during the runtime to remap both old and new
    //  module names)
    configObject.map = Object.assign({ '*': {} }, configObject.map);
    ensureRenameMapMerged(configObject.map['*']);
  }

  // Duplicates those entries in starMap, which include an old
  // module name as the key with the new module name as the key.
  // Keep this consistent with config.js
  function ensureRenameMapMerged (starMap) {
    const rename = configObject.rename;
    Object
      .keys(rename)
      .forEach(function (oldName) {
        const newName = rename[oldName];
        if (!starMap[newName]) {
          // If the new name is not mapped, duplicate
          // the mapping of the old name.
          const mappedName = starMap[oldName];
          if (mappedName) {
            starMap[newName] = mappedName;
          }
        }
        if (!starMap[oldName]) {
          // If the old name is not mapped, duplicate
          // the mapping of the new name if present,
          // otherwise rename the old to the new name.
          starMap[oldName] = starMap[newName] || newName;
        }
      });
    delete configObject.rename;
  }

  // Common configuration of RequireJS plugins from Nucleus.
  configObject.hbs = Object.assign({
    disableI18n: true,
    disableHelpers: true,
    templateExtension: 'hbs'
  }, configObject.hbs);
  configObject.less = Object.assign({
    sourceMap: { sourceMapFileInline: true }
  });

  // If config-build exists and is is not writable, an error will be thrown.
  // This file is critical for the build and the initial migration required
  // it to be always re-generated.
  const buildConfigUpdated = needsUpdate(buildConfig);
  if (buildConfigUpdated) {
    if (verbose) {
      console.log(`  Writing ${buildConfig}.`);
    }
    const buildContent = `require.config(${JSON.stringify(configObject, undefined, 2)});`;
    writeFileSync(buildConfig, buildContent);
  }

  // If config-editor exists and is not writable, it will be ignored. This file
  // is not critical and the initial Nucleus migration did not include it.
  let editorConfigUpdated = true;
  try {
    editorConfigUpdated = needsUpdate(editorConfig);
  } catch {
    if (verbose) {
      console.log(`  Ignoring not writable ${editorConfig}.`);
    }
    editorConfigUpdated = false;
  }
  if (editorConfigUpdated) {
    if (verbose) {
      console.log(`  Writing ${editorConfig}.`);
    }

    // Remove the configuration not needed for IDE plugins and ensure
    // resolvable paths from the project root, not empty: from the build config.
    delete configObject.hbs;
    delete configObject.less;
    Object.assign(configObject.paths, pathsFromRoot);

    const editorContent = `require.config(${JSON.stringify(configObject, undefined, 2)});`;
    writeFileSync(editorConfig, editorContent);
  }

  return {
    buildConfig: configObject,
    buildConfigUpdated,
    editorConfig: configObject,
    editorConfigUpdated
  };

  // Let the file updated only if it does not start with a line-comment,
  // which means that it was customised and must not be overwritten.
  function needsUpdate (fileName) {
    if (existsSync(fileName)) {
      const buildConfigContent = readFileSync(fileName, 'utf8');
      if (buildConfigContent.startsWith('//')) {
        if (verbose) {
          console.log(`  Ignoring customised ${fileName}.`);
        }
        return false;
      }
      accessSync(fileName, constants.R_OK | constants.W_OK);
    }
    return true;
  }
};
