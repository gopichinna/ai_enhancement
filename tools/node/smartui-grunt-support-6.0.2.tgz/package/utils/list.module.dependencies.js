// Returns a list of public modules exposed from a module bundle -
// a bundle index. Expects a file path to the bundle index module.
//
// const parse = require('@smartui/grunt-support/utils/list.module.dependencies');
// const modules = parse('bundles/nuc-models.js');
//
// Returns ['nuc/models/node/node.model', 'nuc/utils/connector', ...]

'use strict';

const { readFileSync } = require('fs');

const bundles = new Map();

function parseModule (fileContents) {
  // disable requiring of bundle stylesheets
  function require () {}
  // just remember the module dependencies, which are the bundle index
  // for modules representing module bundles
  function define (name, dependencies) {
    bundleIndex = Array.isArray(name) ? name : dependencies;
  }
  // support output bundles with namespaced requirejs
  const csui = { require, define }; // eslint-disable-line no-unused-vars

  // perform the define and require statements from the module source
  let bundleIndex;
  eval(fileContents); // eslint-disable-line no-eval
  return bundleIndex;
}

module.exports = function (filePath) {
  let bundleIndex = bundles.get(filePath);
  if (bundleIndex) {
    return bundleIndex;
  }
  const fileContents = readFileSync(filePath, 'utf-8');
  bundleIndex = parseModule(fileContents);
  if (!bundleIndex) {
    throw new Error(`Parsing "${filePath}" failed.`);
  }
  bundles.set(filePath, bundleIndex);
  return bundleIndex;
};
