// Provides functions to decide if a file path points to a JavaScript module,
// which should be checked and transformed from ESM to AMD, if needed
//
// isScript(components, path, prefix)
// ----------------------------------
//
// Checks if a file with the specified path should be passed to the ESM -> AMD
// preprocessor. The leading absolute path below the project root will be trimmed.
// The `components` is the result returned by `loadComponentsDescriptors`.
// The `prefix` is the Smart UI module prefix of the current project, which can
// be also inferred by by calling `inferPrefix`.
//
// const { loadComponentsDescriptors } = require('@smartui/grunt-support/utils/load.config');
// const { isScript } = require('@smartui/grunt-support/utils/is.script');
//
// const components = loadComponentsDescriptors();                     // from /src
// const components = loadComponentsDescriptors({ srcDir: '../src' }); // from /test
// const preprocess = isScript(components, '/src/utils/test.js', 'esme');
//
// Returns true
//
// getScriptRules(components, prefix)
// ----------------------------------
//
// Returns an object with rules for deciding if a file should be passed
// to the ESM -> AMD preprocessor. This is mainly for logging purposes now.
//
// const { loadComponentsDescriptors } = require('@smartui/grunt-support/utils/load.config');
// const { getScriptRules } = require('@smartui/grunt-support/utils/is.script');
//
// const components = loadComponentsDescriptors();                     // from /src
// const components = loadComponentsDescriptors({ srcDir: '../src' }); // from /test
// const preprocess = getScriptRules(components, '/src/utils/test.js', 'esme');
//
// Returns {
//   srcDir: '../src',
//   configName: 'config-build.js',
//   configPath: '../src/config-build.js'
// }

const deepAssign = require('./deep.assign');

function commonIsScript (path) {
  return path.endsWith('.js') &&
    (path.startsWith('/src/') || path.startsWith('/out-debug/') || path.startsWith('/lib/src/')) &&
    !(path.startsWith('/src/bundles/') || path.startsWith('/out-debug/bundles/'));
}

const methods = {
  startsWith: (path, prefix) => path.startsWith(prefix),
  endsWith: (path, suffix) => path.endsWith(suffix),
  equals: (path, path2) => path === path2
};

function matchesOne (path, method, prefix, comp, parts) {
  if (prefix.startsWith('/lib/')) prefix += `/${comp}`;
  for (const part of parts) {
    if (methods[method](path, `${prefix}${part}`)) return true;
  }
}

function matchesAny (path, prefix, comp, { startsWith, endsWith, equals }) {
  return (startsWith && matchesOne(path, 'startsWith', prefix, comp, startsWith)) ||
    (endsWith && matchesOne(path, 'endsWith', prefix, comp, endsWith)) ||
    (equals && matchesOne(path, 'equals', prefix, comp, equals));
}

function matchesRules (path, rules, comp, prefixes) {
  for (const prefix of prefixes) {
    if (matchesAny(path, prefix, comp, rules)) return true;
  }
}

function computedIsScriptOne (comp, component, path, prefixes) {
  const { isScriptModule } = component;
  if (isScriptModule) {
    const { include, exclude } = isScriptModule;
    if (include) {
      if (!matchesRules(path, include, comp, prefixes)) return false;
    }
    if (exclude) {
      if (matchesRules(path, exclude, comp, prefixes)) return false;
    }
  }
  return true;
}

function computedIsScriptAll (components, path, forPrefix) {
  for (const prefix in components) {
    const component = components[prefix];
    if (forPrefix === prefix) {
      if (!computedIsScriptOne(prefix, component, path, ['/src', '/out-debug', '/lib/src'])) return false;
    } else {
      if (!computedIsScriptOne(prefix, component, path, ['/lib/src'])) return false;
    }
  }
  return true;
}

function isScript (components, path, prefix) {
  return commonIsScript(path) && computedIsScriptAll(components, path, prefix);
}

function getRule (rules, prefix, comp, parts) {
  if (prefix.startsWith('/lib/')) prefix += `/${comp}`;
  const rule = parts.map(part => `${prefix}${part}`);
  return [...new Set([...rules, ...rule])];
}

function getRules (rules, comp, prefixes) {
  const { startsWith, endsWith, equals } = rules;
  let newStartsWith = [];
  let newEndsWith = [];
  let newEquals = [];
  for (const prefix of prefixes) {
    if (startsWith) newStartsWith = getRule(newStartsWith, prefix, comp, startsWith);
    if (endsWith) newEndsWith = getRule(newEndsWith, prefix, comp, endsWith);
    if (equals) newEquals = getRule(newEquals, prefix, comp, equals);
  }
  const result = {};
  if (newStartsWith.length) result.startsWith = newStartsWith;
  if (newEndsWith.length) result.endsWith = newEndsWith;
  if (newEquals.length) result.equals = newEquals;
  return result;
}

function getScriptRule (comp, rules, prefixes) {
  if (rules) {
    const { include, exclude } = rules;
    rules = {};
    if (include) rules.include = getRules(include, comp, prefixes);
    if (exclude) rules.exclude = getRules(exclude, comp, prefixes);
  }
  return rules;
}

function getScriptRules (components, forPrefix) {
  const rules = {
    include: {
      endsWith: '.js',
      startsWith: ['/src/', '/out-debug/', '/lib/src/']
    },
    exclude: {
      startsWith: ['/src/bundles/', '/out-debug/bundles/']
    }
  };
  for (const prefix in components) {
    const { isScriptModule } = components[prefix];
    if (isScriptModule) {
      const prefixes = forPrefix === prefix ? ['/src', '/out-debug', '/lib/src'] : ['/lib/src'];
      const rule = getScriptRule(prefix, isScriptModule, prefixes);
      deepAssign(rules, rule);
    }
  }
  return rules;
}

module.exports = { isScript, getScriptRules };
