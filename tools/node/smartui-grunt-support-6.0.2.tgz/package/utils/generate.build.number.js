// Generates a unique build number from the component version
// and the current time, allowing a new build every two minutes.
// See also https://github.com/prantlf/build-number-generator.
//
// const generate = require('../utils/generate.build.number');
// const build = generate('1.0.3');
//
// 1.0.3.180625392
// => 18-06-25, 392*2 minutes after midnight
// => 25 June 2018 1:04 PM

'use strict';

const { generate } = require('build-number-generator');
module.exports = function (version) {
  return generate(version || '1.0.0');
};
