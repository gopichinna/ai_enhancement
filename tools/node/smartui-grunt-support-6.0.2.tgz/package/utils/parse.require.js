// Returns a list of public modules exposed from a module bundle -
// a bundle index. Expects a file path to the bundle index module.
//
// const parse = require('../utils/list.module.dependencies');
// const modules = parse('bundles/nuc-models.js');
//
// ['nuc/models/node/node.model', 'nuc/utils/connector', ...]

'use strict';

const { readFileSync } = require('fs');

const bundles = new Map();

function parseModule (fileContents) {
  let dependencies, callback;
  function require () {
    dependencies = arguments[0];
    callback = arguments[1];
  }
  function define () {}
  // support output bundles with namespaced requirejs
  const csui = { require, define }; // eslint-disable-line no-unused-vars

  // perform the define and require statements from the module source
  eval(fileContents); // eslint-disable-line no-eval
  return [dependencies, callback];
}

module.exports = function (filePath) {
  let bundleIndex = bundles.get(filePath);
  if (bundleIndex) {
    return bundleIndex;
  }
  const fileContents = readFileSync(filePath, 'utf-8');
  bundleIndex = parseModule(fileContents);
  if (!bundleIndex) {
    throw new Error(`Parsing "${filePath}" failed.`);
  }
  bundles.set(filePath, bundleIndex);
  return bundleIndex;
};
