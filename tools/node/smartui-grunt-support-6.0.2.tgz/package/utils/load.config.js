// Provides functions to get build and other configuration from a Smart UI
// project and cache it to optimise often accesses.
//
// normalizeConfigLocation ({ srcDir, configName, configPath } = {})
// -----------------------------------------------------------------
//
// Computes default location and name of the RequireJS build configuration file.
// If the current directory is not the `src` directory in a Smart UI project
// or the file name is different, some of the parameters can be specified
// to compute the rest. Defaults are:
//   srcDir: '.', configName: 'config-build.js', configPath: 'config-build.js'
//
// const { normalizeConfigLocation } = require('@smartui/grunt-support/utils/load.config');
//
// const configInfo = normalizeConfigLocation();                     // from /src
// const configInfo = normalizeConfigLocation({ srcDir: '../src' }); // from /test
//
// Returns {
//   srcDir: '../src',
//   configName: 'config-build.js',
//   configPath: '../src/config-build.js'
// }
//
// inferPrefix(srcDir = '.')
// -------------------------
//
// Infers the Smart UI project module prefix from file names, so that it does
// not have to be specified at multiple places. If the current directory is
// not the `src` directory in a Smart UI project, the path to that directory
// can be passed as the first parameter.
//
// const { inferPrefix } = require('@smartui/grunt-support/utils/load.config');
//
// const compPrefix = inferPrefix();         // from /src
// const compPrefix = inferPrefix('../src'); // from /test
//
// Returns 'esme'
//
// loadBuildConfig({ srcDir, configName, configPath, verbose } = {})
// -----------------------------------------------------------------
//
// Reads and parses the RequireJS build configuration. Caches the result
// for future calls. The returned object will contain one extra property
// - `prefix` - with the Smart UI project module prefix.
// See `normalizeConfigLocation` for more information about the arguments.
// The `verbose` argument enables console logging.
//
// const { loadBuildConfig } = require('@smartui/grunt-support/utils/load.config');
//
// const config = loadBuildConfig();                     // from /src
// const config = loadBuildConfig({ srcDir: '../src' }); // from /test
//
// Returns {
//   "paths": {
//     "nuc": ".",
//     "css": "../lib/src/nuc/lib/css",
//     "csui-ext": "../lib/src/nuc/utils/load-extensions/load-extensions",
//     "hbs": "../lib/src/nuc/lib/hbs",
//     "i18n": "../lib/src/nuc/lib/i18n",
//     "json": "../lib/src/nuc/lib/json",
//     "less": "../lib/src/nuc/lib/less",
//     "txt": "../lib/src/nuc/lib/text"
//   }
// }
//
// setBuildConfig(config)
// ----------------------
//
// Sets a config object to be cached and returned by `loadBuildConfig`
// in the future. Optimises configuration handling if the build config was
// generated in the same process and can be reused without re-loading it.
//
// const createBuildConfig = require('@smartui/grunt-support/utils/create.build.config');
// const { setBuildConfig } = require('@smartui/grunt-support/utils/load.config');
//
// const { buildConfig } = createBuildConfig({
//   prefix: 'esme', dependencies: ['nuc', 'smart', 'csui']
// }, {
//   buildConfig: 'config-build.js',
//   nucleusPath: `../lib/src/nuc`
// });
//
// buildConfig.prefix = 'esme';
// setBuildConfig(buildConfig);
//
// loadComponentsDescriptors({ rootDir, srcDir, configName, configPath, verbose } = {})
// ------------------------------------------------------------------------------------
//
// Loads descriptors of Smart UI projects, which reveal some features important
// for projects, which depend on them. For example, list of their bundles
// or list of RequireJS plugins, which they expose.
//
// const { loadComponentsDescriptors } = require('@smartui/grunt-support/utils/load.config');
//
// const components = loadComponentsDescriptors();               // from /src
// const components = loadComponentsDescriptors({ configPath }); // from /test
//
// Returns {
//   nuc: { getBundleNames(), getAllModules(), ... }
// }

const { readdirSync } = require('fs');
const { isAbsolute, normalize, dirname } = require('path');
const parseBuildConfig = require('./parse.build.config');

let configCache;
let componentCache;

function normalizeConfigLocation ({ srcDir, configName, configPath } = {}) {
  if (!(configPath || srcDir)) srcDir = '.';
  if (!configPath) {
    if (!configName) configName = 'config-build.js';
    configPath = `${srcDir}/${configName}`;
  } else if (!srcDir) {
    srcDir = dirname(configPath);
  }
  return { srcDir, configPath };
}

function inferPrefix (srcDir = '.') {
  for (const child of readdirSync(srcDir)) {
    const match = /([^/]+)-extensions\.json$/.exec(child);
    if (match) return match[1];
  }
}

function loadBuildConfig ({ srcDir, configName, configPath, verbose } = {}) {
  if (configCache) return configCache;

  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));
  if (verbose) console.log(`Loading build config "${configPath}".`);
  configCache = parseBuildConfig(configPath);

  if (!configCache.prefix) configCache.prefix = inferPrefix(srcDir);

  return configCache;
}

function setBuildConfig (config) {
  configCache = config;
}

function loadComponentsDescriptors ({ rootDir, srcDir, configName, configPath, verbose } = {}) {
  if (componentCache) return componentCache;

  verbose && console.log('Loading component descriptors.');
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));
  const { paths: compPaths } = loadBuildConfig({ configPath, verbose });

  // Relative paths in Node.js modules are resolved against the script
  // source directory; not against the process current directory, where
  // the Smart UI components are installed.
  if (!isAbsolute(srcDir)) srcDir = `${process.cwd()}/${srcDir}`;
  if (!rootDir) rootDir = `${srcDir}/..`;

  const components = {};
  for (const compPrefix in compPaths) {
    const compPath = compPaths[compPrefix];
    const compModule = normalize(compPath === 'empty:'
      ? `${rootDir}/lib/src/${compPrefix}/component`
      : `${srcDir}/${compPath}/component`);
    // The paths configuration can point to directories with pre-bundled
    // libraries, which are no Smart UI projects.
    try {
      require.resolve(compModule);
      verbose && console.log(`  "${compPrefix}" is a Smart UI component`);
    } catch (error) {
      verbose && console.warn(`  "${compPrefix}" is not a Smart UI component`);
      continue;
    }

    try {
      components[compPrefix] = require(compModule);
    } catch (error) {
      console.warn(`Loading "${compModule}" failed:`);
      console.warn(error);
    }
  }

  componentCache = components;

  return components;
}

module.exports = {
  normalizeConfigLocation,
  loadBuildConfig,
  setBuildConfig,
  loadComponentsDescriptors,
  inferPrefix
};
