// Creates configurations for eslint to check JavaScript modules and inline
// JavaScript code in HTML files.
//
// function createEslintConfig(options?)
//   options:
//     rootDir:      if `eslintrc` or `eslintrcHtml` are not specified, their
//                   default names will be appended to `rootDir`
//                   ('..' by default)
//     eslintrc:     output file to write the main configuration to
//                   ('../eslintrc.yml' by default)
//     eslintrcHtml: output file to write the configuration for HTML files to
//                   ('../eslintrc-html.yml' by default)
//     verbose:      print more details on the console
//                   (false by default)
//
// const createEslintConfig = require('@smartui/grunt-support/utils/create.eslintrc');
//
// createEslintConfig();
//
// The .eslintrc.yml and .eslintrc-html.yml files will be overwritten only if
// they do not start with a line-comment. If you edit the file locally and you
// do not want to be updated whenever you run `npm ci`, add a comment on its
// first line.
//
// This module is supposed to be used with the current directory set to `src`
// of the particular Smart UI project. If you set the current directory to
// some other directory, set `rootDir` or `eslintrc` and `eslintrcHtml`.

'use strict';

const { accessSync, constants, existsSync, readFileSync, writeFileSync } = require('fs');

const contentJs = `plugins:
  - '@smartui/checks'
extends:
  - plugin:@smartui/checks/productive
overrides:
  -
    files:
      - "**/test/**/*.js"
    extends:
      - plugin:@smartui/checks/test`;
const contentHtml = `plugins:
  - '@smartui/checks'
  - html
extends:
  - plugin:@smartui/checks/productive
overrides:
  -
    files:
      - "**/test/**/*.js"
    extends:
      - plugin:@smartui/checks/test`;

module.exports = function (options) {
  // Default parameter values.
  let { rootDir = '..', eslintrc, eslintrcHtml, verbose } = options;
  if (!eslintrc) eslintrc = `${rootDir}/.eslintrc.yml`;
  if (!eslintrcHtml) eslintrcHtml = `${rootDir}/.eslintrc-html.yml`;

  console.log('Generating the eslint configuration.');
  tryUpdate(eslintrc, contentJs);
  tryUpdate(eslintrcHtml, contentHtml);

  // If eslintrc exists and is not writable, it will be ignored. This file
  // is not critical and the initial Nucleus migration did not include it.
  function tryUpdate (fileName, content) {
    let fileUpdated;
    try {
      fileUpdated = needsUpdate(fileName);
    } catch {
      if (verbose) {
        console.log(`  Ignoring not writable ${fileName}.`);
      }
      fileUpdated = false;
    }
    if (fileUpdated) {
      if (verbose) {
        console.log(`  Writing ${fileName}.`);
      }
      writeFileSync(fileName, content);
    }
  }

  // Let the file updated only if it does not start with a line-comment,
  // which means that it was customised and must not be overwritten.
  function needsUpdate (fileName) {
    if (existsSync(fileName)) {
      const eslintrcContent = readFileSync(fileName, 'utf8');
      if (eslintrcContent.startsWith('#')) {
        if (verbose) {
          console.log(`  Ignoring customised ${fileName}.`);
        }
        return false;
      }
      accessSync(fileName, constants.R_OK | constants.W_OK);
    }
    return true;
  }
};
