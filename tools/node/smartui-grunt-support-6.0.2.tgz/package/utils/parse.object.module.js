// Returns an object parsed out of a module with its export entered
// as an object literal. Expects a script with the `define` statement.
//
// const parse = require('@smartui/grunt-support/utils/parse.object.module');
// const config = parse('nuc/models/node/impl/nls/lang.js');
//
// Returns {
//   root: true,
//   'en-us': false,
//   en: false
// }

'use strict';

const { readFileSync } = require('fs');

let preprocess;
try {
  ({ preprocess } = require('requirejs-esm-preprocessor'));
} catch (err) {
  console.log(err);
  console.warn('ESM preprocessor not available. Modules loaded by RequireJS plugins have to be AMD.');
}

const objects = new Map();

function parseModule (contents, path) {
  // just remember the module content, which is a JSON object
  function define (name, content) {
    result = typeof name === 'string' ? content : name;
  }
  // support output bundles with namespaced requirejs
  const csui = { define }; // eslint-disable-line no-unused-vars
  let result;
  if (preprocess) {
    contents = preprocess({ path, contents });
  }
  // perform the define statement from the file source
  eval(contents); // eslint-disable-line no-eval
  if (typeof result === 'function') {
    result = result();
  }
  return result;
}

module.exports = function (filePath) {
  let object = objects.get(filePath);
  if (object) {
    return object;
  }
  const fileContents = readFileSync(filePath, 'utf-8');
  object = parseModule(fileContents, filePath);
  if (!object) {
    throw new Error(`Parsing "${filePath}" failed.`);
  }
  objects.set(filePath, object);
  return object;
};
