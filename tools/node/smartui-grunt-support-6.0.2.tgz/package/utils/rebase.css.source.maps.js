// Inserts a path prefix before every source file name in a CSS source map,
// which does not start with one or more directories.
//
// function rebaseCssSourceMaps(grunt, directory, prefix)
//   options:
//     directory: path to the directory with CSS source maps
//     prefix:    prefix to insert before every source file name
//
// const rebaseCssSourceMaps = require('@smartui/grunt-support/utils/rebase.css.source.maps');
//
// rebaseCssSourceMaps('../out-release/bundles', '/smartui/esme/bundles/');

const { readdirSync, readFileSync, writeFileSync } = require('fs');
const { join } = require('path');

module.exports = function rebaseCssSourceMaps (grunt, dir, prefix) {
  const maps = readdirSync(dir);
  let count = 0;
  for (const map of maps) {
    if (!map.endsWith('.css.map')) continue;
    ++count;
    const file = join(dir, map);
    grunt.verbose.writeln(`Rebasing CSS source map ${file}.`);
    const content = JSON.parse(readFileSync(file, 'utf8'));
    const { sources } = content;
    for (let i = 0, l = sources.length; i < l; ++i) {
      const source = sources[i];
      if (!source.includes('/')) {
        sources[i] = `${prefix}${source}`;
      }
    }
    writeFileSync(file, JSON.stringify(content));
  }
  grunt.log.ok(`${count} CSS source ${grunt.util.pluralize(count, 'map/maps')} rebased.`);
};
