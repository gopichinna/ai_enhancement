# requirejsCleanOutput

Deletes files from the build output directory, which were copied by the
requirejs task, but do not need to be shipped because they were bundled.

    requirejsCleanOutput: {
      release: {
        src: '../out-release'
      },
      debug: {
        src: '../out-debug'
      }
    }

## Options

### force: false

Continue even if a file operation fails.

### cleanScheduledFiles: true

Clean the files scheduled for cleaning by the `generateSVGs` task.

### processItem({ name, path }, helpers) {}

Override the default file processing.
