'use strict';

module.exports = function (grunt) {
  const { readFileSync } = require('fs');
  const _ = grunt.util._;

  // traverse handlebars templates filese (.hbs) and check for the use of atttributes
  // using unquoted templates
  grunt.registerMultiTask('checkHbsTemplateQuotes',
    'Check *.hbs files for missing quotes around templates',

    function () {
      const taskName = this.name;
      grunt.log.debug(taskName + ': found ' + this.files.length + ' files');
      let numFound = 0;
      _.each(this.files, function (file) {
        const src = file.src[0];
        const jsText = readFileSync(src, 'utf8');

        const regex = /[A-Za-z-_]+={{/g;
        const searchRes = jsText.match(regex);
        if (searchRes) {
          numFound += searchRes.length;
          grunt.log.error(src + ' uses ' + searchRes.length + ' attributes with unquoted handle bars templates templates.');
        }
      });
      if (numFound > 0) {
        grunt.fail.warn('Found ' + numFound + ' attributes with unquoted templates in handlebars files.');
      } else {
        grunt.log.debug('No attributes with unquoted templates used in handlebars files.');
      }
    });
};
