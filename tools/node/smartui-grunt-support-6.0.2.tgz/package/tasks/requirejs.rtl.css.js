'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { inferPrefix } = require('../utils/load.config');
const rebaseCssSourceMaps = require('../utils/rebase.css.source.maps');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, '@lodder/grunt-postcss');

  grunt.registerMultiTask('requirejsRtlCss',
    'Generate RTL versions of stylesheet bundles',
    function () {
      const options = this.options({
        prefix: undefined,
        appDir: '.',
        bundleDir: '../out-debug'
      });
      let { prefix, appDir, bundleDir } = options;
      if (!prefix) prefix = inferPrefix(appDir);

      grunt.config.merge({
        postcss: {
          // Generate RTL versions of stylesheet bundles
          auto_rtl: {
            options: {
              failOnError: true,
              map: {
                inline: false,
                sourcesContent: true
              },
              processors: [
                require('rtlcss')()
              ]
            },
            files: [{
              expand: true,
              src: [`${bundleDir}/bundles/*.css`, `!${bundleDir}/bundles/*-rtl.css`],
              dest: '',
              rename: (dest, src) => dest + src.replace('.css', '-rtl.css')
            }]
          }
        }
      });

      grunt.registerTask('autoRebaseRtlCssSourceMaps', () =>
        rebaseCssSourceMaps(grunt, `${bundleDir}/bundles`, `/smartui/${prefix}/bundles/`));

      grunt.task.run(['postcss:auto_rtl', 'autoRebaseRtlCssSourceMaps']);
    });
};
