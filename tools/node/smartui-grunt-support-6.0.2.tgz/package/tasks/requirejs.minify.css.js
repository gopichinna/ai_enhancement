'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { inferPrefix } = require('../utils/load.config');
const rebaseCssSourceMaps = require('../utils/rebase.css.source.maps');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, '@lodder/grunt-postcss');

  grunt.registerMultiTask('requirejsMinifyCss',
    'Minify stylesheets in the release directory',
    function () {
      const options = this.options({
        prefix: undefined,
        appDir: '.',
        bundleDir: '../out-release'
      });
      let { prefix, appDir, bundleDir } = options;
      if (!prefix) prefix = inferPrefix(appDir);

      grunt.config.merge({
        postcss: {
          // Minify the release stylesheets
          auto_min: {
            options: {
              failOnError: true,
              map: {
                inline: false,
                sourcesContent: true
              },
              processors: [
                require('cssnano')({
                  preset: [
                    'default',
                    {
                      discardComments: {
                        removeAll: true
                      }
                    }
                  ]
                })
              ]
            },
            src: [`${bundleDir}/bundles/*.css`, `!${bundleDir}/bundles/*.min.css`]
          }
        }
      });

      grunt.registerTask('autoRebaseCssSourceMaps', () =>
        rebaseCssSourceMaps(grunt, `${bundleDir}/bundles`, `/smartui/${prefix}/bundles/`));

      grunt.task.run(['postcss:auto_min', 'autoRebaseCssSourceMaps']);
    });
};
