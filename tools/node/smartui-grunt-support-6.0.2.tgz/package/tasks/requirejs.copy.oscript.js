'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { basename } = require('path');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-contrib-copy');

  grunt.registerMultiTask('requirejsCopyOScript',
    'Copies the oscript template and the release build output to the oscript directory',
    function () {
      const options = this.options({
        moduleName: undefined,
        inputDir: '../srcmodules',
        outputDir: '../out-module',
        releaseDir: '../out-release',
        supportDir: 'support'
      });
      let { moduleName, inputDir, outputDir, releaseDir, supportDir } = options;
      if (!moduleName && grunt.file.exists(inputDir)) {
        const children = grunt.file.expand(`${inputDir}/*`);
        grunt.verbose.writeln(`Guessing OScript module from ${grunt.log.wordlist(children)}.`);
        moduleName = basename(children[0]);
      }

      grunt.config.merge({
        // Copy the module template and release output
        copy: {
          auto_module: {
            files: [
              {
                cwd: `${inputDir}/${moduleName}`,
                src: '**',
                dest: `${outputDir}/${moduleName}`,
                expand: true
              },
              {
                cwd: releaseDir,
                src: '**',
                dest: `${outputDir}/${moduleName}/${supportDir}`,
                expand: true
              }
            ]
          }
        }
      });

      if (grunt.file.exists(inputDir)) grunt.task.run(['copy:auto_module']);
      else grunt.verbose.writeln(`Missing OScript template "${inputDir}".`);
    });
};
