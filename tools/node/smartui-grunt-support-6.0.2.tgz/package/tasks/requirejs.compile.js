'use strict';

const { resolve } = require('path');
const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { inferPrefix } = require('../utils/load.config');
const { collectPlugins, collectDependencies } = require('../utils/collect.dependencies');
const { createModulePreprocessor, createBundlePostprocessor } = require('../build');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, '@prantlf/grunt-contrib-requirejs');

  grunt.registerMultiTask('requirejsCompile',
    'Compiles and bundles sources to the debug output directory',
    function () {
      const verbose = grunt.option('verbose');
      const options = this.options({
        prefix: undefined,
        rootDir: '..',
        appDir: '.',
        bundleDir: '../out-debug',
        config: 'config-build.js',
        projectDependencies: [],
        bundles: [],
        fileExclusionRegExp: /(?:\.spec\.js$)|(?:\bGruntfile\.js$)|(?:\bcomponent\.js$)/,
        preserveLicenseComments: true,
        logLevel: undefined,
        isScript: undefined,
        rebaseSourceMap: {},
        onBuildRead: undefined,
        onBuildWrite: undefined,
        onModuleBundleComplete: undefined
      });
      let {
        prefix, rootDir, appDir, bundleDir, config, bundles, fileExclusionRegExp,
        preserveLicenseComments, logLevel, projectDependencies,
        onBuildRead, onBuildWrite, onModuleBundleComplete,
        isScript, rebaseSourceMap
      } = options;
      if (logLevel == null) logLevel = verbose ? 0 : 2;
      if (!prefix) prefix = inferPrefix(appDir);
      if (!projectDependencies.length) projectDependencies = collectDependencies(rootDir);

      const plugins = collectPlugins(projectDependencies, { rootDir });
      for (const bundle of bundles) {
        const { exclude = [] } = bundle;
        bundle.exclude = exclude ? [...plugins, ...exclude] : plugins;
      }

      const fullRootDir = resolve(rootDir).replaceAll('\\', '/');
      const preprocessModule = createModulePreprocessor({
        isScript,
        rootDir: fullRootDir,
        configPath: config,
        srcDir: appDir,
        verbose: logLevel === 0,
        silent: logLevel === 4
      });
      const onBuildReadCombined = function requirejsCompileBuildRead (moduleName, path, contents) {
        contents = preprocessModule(moduleName, path, contents);
        if (onBuildRead) {
          contents = onBuildRead(moduleName, path, contents);
        }
        return contents;
      };

      const postprocessBundle = createBundlePostprocessor({ prefix, bundleDir, rebaseSourceMap, verbose });
      const onModuleBundleCompleteCombined = function requirejsCompileBuildRead (bundleData) {
        postprocessBundle(bundleData);
        if (onModuleBundleComplete) {
          onModuleBundleComplete(bundleData);
        }
      };

      grunt.config.merge({
        // Copy, uglify and combine RequireJS modules to file bundles
        // See https://github.com/requirejs/r.js/blob/master/build/example.build.js.
        requirejs: {
          auto: {
            options: {
              namespace: 'csui',

              mainConfigFile: config,
              dir: bundleDir,
              appDir,
              baseUrl: '.',
              siteRoot: '.',
              modules: bundles,

              fileExclusionRegExp,
              skipDirOptimize: true,
              normalizeDirDefines: 'skip',
              // Instead of cleaning the output directory, this deletes
              // .hbs files from the source directory
              // removeCombined: true,
              optimize: 'none',
              generateSourceMaps: true,
              preserveLicenseComments,
              writeBuildTxt: false,

              separateCSS: true,
              compressCSS: false,
              // This prevents resolving @import directives and inserting
              // the content of source stylesheets to the output one
              // optimizeCss: 'none',
              less: {
                compress: false,
                sourceMap: {
                  sourceMapFileInline: true,
                  sourceMapBasepath: resolve('..'),
                  sourceMapRootpath: '..'
                }
              },

              logLevel,

              onBuildRead: onBuildReadCombined,
              onBuildWrite,
              onModuleBundleComplete: onModuleBundleCompleteCombined
            }
          }
        }
      });

      grunt.task.run(['requirejs:auto']);
    });
};
