'use strict';

module.exports = function (grunt) {
  const { readFileSync } = require('fs');
  const _ = grunt.util._;

  // walk through src files (.js, .hbs) and look for static id values
  grunt.registerMultiTask('checkSrc4StaticIds',
    'check for the use of static ids',

    function () {
      const taskName = this.name;
      grunt.log.debug(taskName + ': found ' + this.files.length + ' files');
      let idsFound = 0;
      _.each(this.files, function (file) {
        const src = file.src[0];
        // ignore tests and libraries
        const isTestSpec = src.search(/spec.js$/) >= 0;
        const isMock = src.search(/mock.js$/) >= 0;
        const isInTestDir = src.search(/\/test\//) >= 0;
        const isInLibDir = src.search(/^lib\//) >= 0;

        if (!(isTestSpec || isMock || isInTestDir || isInLibDir)) {
          const jsText = readFileSync(src, 'utf8');

          // for looking in templates
          const regex = /\sid=['"]([a-zA-Z0-9_-]+)['"]/g;
          const searchRes = jsText.match(regex);
          if (searchRes) {
            idsFound += searchRes.length;
            grunt.log.error(src + ' has ' + searchRes.length + ' static ids: ' + searchRes);
          }
          // for looking in .js files. Will this simple approach create false positives?
          const regex2 = /\sid:\s*['"]([a-zA-Z0-9_-]+)['"]/g;
          const searchRes2 = jsText.match(regex2);
          if (searchRes2) {
            idsFound += searchRes2.length;
            grunt.log.error(src + ' has ' + searchRes2.length + ' static ids: ' + searchRes2);
          }
        }
      });
      if (idsFound > 0) {
        grunt.log.error('Found ' + idsFound + ' static ids in files');
      } else {
        grunt.log.debug('No static ids found in files');
      }
    });

  // walk through all .html snapshots and look for static id values there
  grunt.registerMultiTask('checkHtml4StaticIds',
    'check the snapshots for static ids',

    function () {
      const taskName = this.name;
      grunt.log.debug(taskName + ': found ' + this.files.length + ' files');
      // will gather the values and make them unique as the snapshots will find the same values repeatedly
      let idsFound = [];

      _.each(this.files, function (file) {
        const src = file.src[0];
        const htmlText = readFileSync(src, 'utf8');

        // we will only report id values without numbers, assuming that the numbers are result of a _.uniqueID() mechanism.
        // this will not be perfect. Also, we are not considerate of where in the page the string is found, so this will find false positives.
        const regex = /\sid=['"]([a-zA-Z_-]+)['"]/g;
        const searchRes = htmlText.match(regex);
        if (searchRes) {
          idsFound.push(searchRes);
          grunt.log.debug(src + ' has ' + searchRes.length + ' static ids: ' + searchRes);
        }
      });
      if (idsFound.length > 0) {
        idsFound = _.uniq(_.flatten(idsFound));
        grunt.log.error('Found ' + idsFound.length + ' static ids in files: ' + idsFound);
      } else {
        grunt.log.debug('No static ids found in files');
      }
    });
};
