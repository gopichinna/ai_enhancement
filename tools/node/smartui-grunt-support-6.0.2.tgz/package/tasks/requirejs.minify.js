const { readFile, writeFile } = require('fs/promises');
const { basename, dirname } = require('path');
const convertSourceMap = require('convert-source-map');
const { transform, formatMessages } = require('esbuild');

async function printWarnings (grunt, warnings, logLimit) {
  const messages = await formatMessages(warnings, { kind: 'warning', color: true });
  let l = warnings.length;
  if (logLimit > 0 && logLimit < l) {
    l = logLimit;
  }
  for (let i = 0; i < l; ++i) {
    const { location = {} } = warnings[i];
    grunt.log.warn(`${messages[i]} on line ${location.line}, column ${location.column}`);
  }
}

module.exports = function (grunt) {
  async function readModule (dir, mod, hasMap, legalComments, logLevel, logLimit) {
    let message = `Reading ${dir}/${mod}`;
    if (hasMap !== false) message += ` and ${dir}/${mod}.map`;
    grunt.verbose.writeln(`${message}.`);

    const promises = [readFile(`${dir}/${mod}`, 'utf8')];
    if (hasMap !== false) {
      promises.push(readFile(`${dir}/${mod}.map`, 'utf8'));
    }
    let [code, map] = await Promise.all(promises);

    // workaround for the esbuild transformer, which reads only inline source maps
    if (map) {
      code = convertSourceMap.removeMapFileComments(code);
      if (!code.endsWith('\n')) {
        code += '\n';
      }
      map = convertSourceMap.fromJSON(map).toComment();
      code += map;
    }

    grunt.log.writeln(`Minifying ${mod}.`);
    let warnings;
    ({ code, map, warnings } = await transform(code, {
      loader: 'js',
      minify: true,
      sourcemap: 'external',
      legalComments,
      logLevel,
      logLimit
    }));
    const warn = logLevel !== 'silent' && logLevel !== 'error';
    if (warn && warnings.length > 0) {
      await printWarnings(grunt, warnings, logLimit);
    }

    // workaround for the eslint transformer, which doesn't append the mapping comment
    if (!code.endsWith('\n')) {
      code += '\n';
    }
    code += convertSourceMap.generateMapFileComment(`${basename(mod)}.map`);
    map = JSON.parse(map);
    return { code, map };
  }

  function writeModule (dir, mod, comp, { code, map }, prefix) {
    grunt.verbose.writeln(`Fixing ${mod}.map.`);
    for (let srcs = map.sources, i = 0, l = srcs.length; i < l; ++i) {
      const src = srcs[i];
      if (src.startsWith('../../src')) srcs[i] = `${prefix}${comp}${src.substr(9)}`;
      else if (src.startsWith('/src')) srcs[i] = `${prefix}${comp}${src.substr(4)}`;
      else if (src.startsWith('src')) srcs[i] = `${prefix}${comp}${src.substr(3)}`;
    }
    const { file } = map;
    if (file && file.startsWith('bundles/')) {
      map.file = `${prefix}${comp}/${file}`;
    }
    grunt.verbose.writeln(`Writing ${dir}/${mod} and ${dir}/${mod}.map.`);
    return Promise.all([
      writeFile(`${dir}/${mod}`, code),
      writeFile(`${dir}/${mod}.map`, JSON.stringify(map))
    ]);
  }

  grunt.registerMultiTask('requirejsMinify',
    'Minifies JavaScript bundles produced by the requirejs task in a Smart UI project.',
    async function () {
      const options = this.options({
        bundleDir: '../out-release',
        bundles: [],
        bundleIndexes: {},
        prefix: '',
        sourceMapPrefix: '/smartui/',
        logLevel: 'warning',
        logLimit: 10,
        legalComments: 'eof',
        json: false,
        force: false
      });
      const { bundleDir, sourceMapPrefix, logLevel, logLimit, legalComments, json, force } = options;
      const bundles = options.bundles.map(({ name }) => name);
      const bundleIndexes = Object.keys(options.bundleIndexes);
      const prefix = options.prefix || (bundles[0] &&
        /^(?:bundles\/)?(\w+)-/.exec(bundles[0])[1]);
      const files = this.files;
      const done = this.async();

      try {
        if (files.length) await minifyFiles();
        if (bundles.length) await minifyBundles();
        if (bundleIndexes.length) await minifyBundleIndexes();
      } catch (error) {
        grunt.log.error(error.message);
        grunt.verbose.error(error.stack);
        /* c8 ignore next */
        const warn = force ? grunt.log.warn : grunt.fail.warn;
        warn('Minifying JavaScript files failed.');
      } finally {
        done();
      }

      function minifyFiles () {
        return Promise.all(files.map(({ src }) =>
          src.map(file => {
            const name = basename(file);
            return minifyOne(dirname(file), name, /^(\w+)-/.exec(name)[1]);
          })
        ).flat());
      }

      function minifyBundles () {
        return Promise.all(bundles.map(bundleName =>
          minifyOne(bundleDir, `${bundleName}.js`, prefix)));
      }

      function minifyBundleIndexes () {
        const promises = [];
        for (const bundleIndex of bundleIndexes) {
          promises.push(minifyOne(bundleDir, `${bundleIndex}.js`, prefix, false));
          if (json) {
            promises.push(minifyJson(bundleDir, `${bundleIndex}.json`));
          }
        }
        return Promise.all(promises);
      }

      async function minifyOne (dir, mod, comp, hasMap) {
        const result = await readModule(dir, mod, hasMap, legalComments, logLevel, logLimit);
        return writeModule(dir, mod, comp, result, sourceMapPrefix);
      }

      async function minifyJson (dir, mod) {
        grunt.verbose.writeln(`Reading ${dir}/${mod}.`);
        const data = await readFile(`${dir}/${mod}`, 'utf8');
        grunt.log.writeln(`Minifying ${mod}.`);
        const minified = JSON.stringify(JSON.parse(data));
        grunt.verbose.writeln(`Writing ${dir}/${mod}.`);
        return writeFile(`${dir}/${mod}`, minified);
      }
    });
};
