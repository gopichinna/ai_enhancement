'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-contrib-copy');

  grunt.registerMultiTask('requirejsCopyRelease',
    'Copies the debug build output to the release directory',
    function () {
      const options = this.options({
        debugDir: '../out-debug',
        releaseDir: '../out-release',
        bundleIndexes: {}
      });
      const { debugDir, releaseDir } = options;

      grunt.config.merge({
        // Copies the debug build output to the release directory
        copy: {
          auto_release: {
            files: [{
              cwd: debugDir, src: '**', dest: releaseDir, expand: true
            }]
          }
        }
      });

      grunt.task.run(['copy:auto_release']);
    });
};
