'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { generate } = require('build-number-generator');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-replace');

  grunt.registerMultiTask('requirejsGenerateVersion',
    'Replaces the build number in the extension-describing file',
    function () {
      const options = this.options({
        prefix: undefined,
        bundleDir: '../out-debug',
        buildNumber: undefined,
        version: undefined
      });
      let { prefix, bundleDir, buildNumber } = options;
      if (!buildNumber) {
        buildNumber = process.env.BUILD || generate(options.version ||
          grunt.file.readJSON('../package.json').version || '1.0.0');
      }

      grunt.config.merge({
        // Replaces the build number in the extension-describing file
        replace: {
          auto: {
            options: {
              force: true,
              patterns: [{
                match: /"version": "[.0-9]+"/g,
                replacement: `"version": "${buildNumber}"`
              }]
            },
            files: [{
              src: [`${prefix}-extensions.json`],
              dest: `${bundleDir}/${prefix}-extensions.json`
            }]
          }
        }
      });

      grunt.task.run(['replace:auto']);
    });
};
