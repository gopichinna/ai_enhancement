'use strict';

const { loadLocalNpmTask, loadParentNpmTask } = require('../utils/load.npm.tasks');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-contrib-clean');
  loadLocalNpmTask(grunt, 'grunt-mkdir');
  loadParentNpmTask(grunt, 'grunt-karma');

  grunt.registerMultiTask('smartuiTest',
    'Runs unit tests in debug and release modes inlcluding report generation',
    function (task) {
      const options = this.options({
        testDir: '.',
        debugDir: undefined,
        releaseDir: undefined
      });
      const { testDir } = options;
      const {
        testConfig = `${testDir}/karma.conf.js`,
        debugDir = `${testDir}/debug`,
        debugConfig = `${testDir}/karma.debug.js`,
        releaseDir = `${testDir}/release`,
        releaseConfig = `${testDir}/karma.release.js`
      } = options;

      grunt.config.merge({
        // Remove directories with old reports
        clean: {
          auto_single: [`${testDir}/coverage/*`, `${testDir}/results/*`],
          auto_debug: [`${debugDir}/coverage/*`, `${debugDir}/results/*`],
          auto_release: [`${releaseDir}/results/*`]
        },

        // Create report directories
        mkdir: {
          auto_single: {
            options: { create: [`${testDir}/coverage`, `${testDir}/results`] }
          },
          auto_debug: {
            options: { create: [`${debugDir}/coverage`, `${debugDir}/results`] }
          },
          auto_release: {
            options: { create: [`${testDir}/results`] }
          }
        },

        // Run Karma with the default configuration, which runs all test specs once
        karma: {
          auto_single: { configFile: testConfig },
          auto_debug: { configFile: debugConfig },
          auto_release: { configFile: releaseConfig }
        }
      });

      grunt.registerTask('auto_single', [
        'mkdir:auto_single', 'clean:auto_single', 'karma:auto_single']);
      grunt.registerTask('auto_debug', [
        'mkdir:auto_debug', 'clean:auto_debug', 'karma:auto_debug']);
      grunt.registerTask('auto_release', [
        'mkdir:auto_release', 'clean:auto_release', 'karma:auto_release']);
      grunt.registerTask('auto_test', ['auto_release']);

      grunt.task.run(task === 'single'
        ? ['auto_single']
        : task === 'debug'
          ? ['auto_debug']
          : task === 'release' ? ['auto_release'] : ['auto_test']);
    });
};
