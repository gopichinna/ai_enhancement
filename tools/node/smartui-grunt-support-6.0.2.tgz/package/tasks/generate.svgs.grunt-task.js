'use strict';

const { scheduleFileForCleaning } = require('../utils/files.for.cleaning');

module.exports = function (grunt) {
  const svgson = require('svgson');
  const path = require('path');
  const fs = require('fs');
  const readline = require('readline');
  const { promisify } = require('util');
  const readdir = promisify(fs.readdir);
  const rmdir = promisify(fs.rmdir);
  const unlink = promisify(fs.unlink);
  const stat = promisify(fs.stat);
  const _ = require('underscore');

  function writeFile (path, data, opts = 'utf8') {
    return new Promise((resolve, reject) => {
      fs.writeFile(path, data, opts, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  function parseStyles (stylesStr) {
    const allStyles = stylesStr.split(';');
    const styles = {};
    for (let k = 0; k < allStyles.length; k++) {
      if (allStyles[k]) {
        const keyValue = allStyles[k].split(':');
        styles[keyValue[0].trim()] = keyValue[1].trim();
      }
    }
    return styles;
  }

  // new .... =>

  async function createClassMappings (svgStr) {
    const ids = {};
    await svgson.parse(svgStr, {
      transformNode: function (node) {
        // grunt.log.debug(`node: ${JSON.stringify(node)}`);
        if (node.type === 'element' && node.attributes && node.attributes.id) {
          const id = node.attributes.id;
          let cnt = 0;
          switch (id) {
            case 'state':
            case 'focus':
            case 'colorFirst':
            case 'colorSecond':
            case 'colorThird':
              if (node.attributes.class) {
                ids[node.attributes.class] = `csui-icon-v2-${id}`;
              }
              break;
            case 'metaphor':
              if (node.attributes.class) {
                ids[node.attributes.class] = `csui-icon-v2-${id}${cnt}`;
                cnt++;
              }
              if (node.children) {
                for (let ci = 0; ci < node.children.length; ci++) {
                  const child = node.children[ci];
                  if (child.type === 'element' && child.attributes) {
                    if (!ids[child.attributes.class]) {
                      ids[child.attributes.class] = `csui-icon-v2-${id}${cnt}`;
                      cnt++;
                    }
                  }
                }
              }
              break;
          } // switch
        }
      } // transformNode
    });
    return ids;
  }

  async function getStylesForClasses (svgStr) {
    const styles = {};
    await svgson.parse(svgStr, {
      transformNode: function (node) {
        // grunt.log.debug(`node: ${JSON.stringify(node)}`);
        if (node.type === 'element' && node.name === 'style') {
          for (let k = 0; node.children && k < node.children.length; k++) {
            const child = node.children[k];
            const all = child.value;
            let matches;
            const regex = /\.(.*?)\{(.*?)\}/g;
            while ((matches = regex.exec(all)) != null) {
              if (matches && matches.length === 3) {
                const selector = matches[1].trim();
                styles[selector] = parseStyles(matches[2]);
              }
            }
          }
        }
      } // transformNode
    });
    return styles;
  }

  function replaceClassByInlineStyles (nodeAttributes, styles) {
    const c = nodeAttributes.class;
    const stylesForClass = styles[c];
    for (let i = 0; i < Object.keys(stylesForClass).length; i++) {
      const styleName = Object.keys(stylesForClass)[i];
      if (styleName === 'enable-background') {
        continue; // skip enable-background, because it produces invalid html
      }
      const styleValue = stylesForClass[styleName];
      if (nodeAttributes[styleName]) {
        grunt.log.warn(
            `Replacing style ${styleName}. Old value: ${nodeAttributes[styleName]}, new value: ${styleValue}. (this was not expected - you should investigate)`);
      }
      nodeAttributes[styleName] = styleValue;
    }
    delete nodeAttributes.class;
  }

  async function convertClassesToInlineStyles (svgStr, classMappingToNormalizedClassNames,
    sourceStylesByClasses, iconName, extraCssClass) {
    const svgAst1 = await svgson.parse(svgStr, {
      transformNode: function (node) {
        if (node.type === 'element') {
          switch (node.name) {
            case 'style':
              break;
            case 'svg':
              if (!node.attributes) {
                node.attributes = {};
              }
              delete node.attributes.id;
              delete node.attributes['data-name'];
              delete node.attributes.version;
              delete node.attributes['xmlns:xlink'];
              delete node.attributes['xml:space'];
              delete node.attributes.style;
              node.attributes.class = 'csui-icon-v2' + extraCssClass + ' csui-icon-v2__' +
                                       iconName;
              break;
            default:
              if (node.attributes) {
                const nodeAttributes = node.attributes;
                const inlineStyles = JSON.parse(JSON.stringify(sourceStylesByClasses)); // deep clone
                // grunt.log.debug(`inlineStyles: ${JSON.stringify(inlineStyles)}`);
                if (nodeAttributes.id) {
                // remove the id from the node
                  delete nodeAttributes.id;
                }
                if (nodeAttributes.class) {
                  const originalClass = nodeAttributes.class;
                  replaceClassByInlineStyles(nodeAttributes, inlineStyles);
                  nodeAttributes.class = classMappingToNormalizedClassNames[originalClass];
                }
              }
          } // switch
        }
        return node;
      }
    });

    // remove the style element before serializing the svg again
    if (svgAst1.children) {
      for (let i = 0; i < svgAst1.children.length; i++) {
        const child = svgAst1.children[i];
        if (child.name === 'style' || (child.name === 'defs' &&
            child.children && child.name === 'defs' &&
            child.children[0].name === 'style')) {
          svgAst1.children.splice(i, 1);
          break;
        }
      }

      // remove title element before serializing the svg again (LPAD-90937)
      for (let i = 0; i < svgAst1.children.length; i++) {
        const child = svgAst1.children[i];
        if (child.name === 'title') {
          svgAst1.children.splice(i, 1);
          break;
        }
      }
    }

    const outSVGstr = svgson.stringify(svgAst1);
    // grunt.log.debug(`serialized svg ast: ${outSVGstr}`);

    return outSVGstr;
  }

  async function processSVG (src, iconName, extraCssClass) {
    // grunt.log.debug(`processSVG src: ${src}`);

    let completeSvgString = '';
    try {
      const svgStr = await new Promise((resolve, reject) => {
        readline.createInterface({
          input: fs.createReadStream(src),
          terminal: false
        }).on('line', function (line) {
          const truncatedLine = line.trim();
          if (!truncatedLine) {
            return;
          }
          if (truncatedLine.startsWith('<!--') && truncatedLine.endsWith('-->')) {
            return; // don't add comment
          }
          completeSvgString = completeSvgString + truncatedLine + ' ';
        }).on('close', function () {
          resolve(completeSvgString);
        }).on('error', reject);
      });

      // grunt.log.debug(`svg text: ${completeSvgString}`);

      // new ... =>
      const classMapping = await createClassMappings(svgStr);
      const styles = await getStylesForClasses(svgStr);
      const s = await convertClassesToInlineStyles(svgStr, classMapping, styles, iconName,
        extraCssClass);

      // todo: remmove old and no more used code ... =>
      // ids = await getClasses(svgStr);
      // // grunt.log.debug(`ids: ${JSON.stringify(ids)}`);
      // s = await renameClasses(ids, svgStr, iconName);
      return s;
    } catch (ex) {
      grunt.log.error(`processSVG: exception while processing ${src}: ${ex}`);
      throw ex;
    }
  }

  /*
  * Checks existance of file or directory
  *
  * returns stat structure if file exists
  *         undefined if file does not exist
  */
  async function exists (file) {
    try {
      return await stat(file);
    } catch (statEx) {
      if (statEx.code !== 'ENOENT') {
        throw statEx;
      }
    }
  }

  grunt.registerMultiTask('generateSVGs', 'Takes SVG files from a list and generates versions' +
                                          ' of it with changed colors that can be used for a' +
                                          ' mode with a dark background like in high contrast' +
                                          ' mode', async function () {
    const done = this.async();
    const taskName = this.name;

    try {
      grunt.log.debug(`${taskName}, target ${this.target} has ${this.files.length} files blocks`);

      // grunt.log.debug(`this: ${JSON.stringify(this, undefined, 2)}`);

      const options = this.data.options;
      grunt.log.debug(`options: ${JSON.stringify(options, undefined, 2)}`);

      const nameMap = options.nameMap ? options.nameMap : {};
      const iconNamePrefix = options.iconNamePrefix ? options.iconNamePrefix : '';
      const extraCssClass = options.extraCssClass ? ' ' + options.extraCssClass : '';
      const scheduleFilesForCleaning = options.extraCssClass ?? true;

      for (let i = 0; i < this.files.length; i++) {
        let files = this.files[i];

        if (!_.isArray(files)) {
          files = [files];
        }

        // grunt.log.debug(`files ${JSON.stringify(files, undefined, 2)}`);
        for (let j = 0; j < files.length; j++) {
          const oneFileSet = files[j];
          const iconMapJSFileName = oneFileSet.dest;
          if (!iconMapJSFileName) {
            grunt.log.error(
                `${taskName}, target ${this.target}: dest not defined for fileset`);
            done(false); // fail grunt task asynchronously
            return;
          }

          const iconMapJSFileStat = await exists(iconMapJSFileName);
          if (iconMapJSFileStat) {
            if (iconMapJSFileStat.isDirectory()) {
              grunt.log.error(
                  `${taskName}, target ${this.target}: dest (${iconMapJSFileName}) is an existing directory`);
              done(false); // fail grunt task asynchronously
              return;
            }
          }

          if (!_.isArray(oneFileSet.src)) {
            oneFileSet.src = [oneFileSet.src];
          }
          if (oneFileSet.src.length) {
            const srcFiles = [];
            for (let k = 0; k < oneFileSet.src.length; k++) {
              const src = oneFileSet.src[k];
              // check if src is a directory
              const srcStat = await stat(src);
              if (srcStat.isDirectory()) {
                const filesInSrcDir = await readdir(src);
                for (let l = 0; l < filesInSrcDir.length; l++) {
                  const srcFile = filesInSrcDir[l];
                  const parsedSrcFile = path.parse(srcFile);
                  if (parsedSrcFile.ext === '.svg') {
                    srcFiles.push(path.join(src, srcFile));
                  }
                }
              } else {
                const parsedSrcFile = path.parse(src);
                if (parsedSrcFile.ext === '.svg') {
                  srcFiles.push(src);
                }
              }
            }

            const icons = {};
            const finalIconNames = {};
            for (let l = 0; l < srcFiles.length; l++) {
              const srcFile = srcFiles[l];
              grunt.log.debug(`src ${srcFile}`);
              const parsedSrcFile = path.parse(srcFile);
              let iconName = parsedSrcFile.name;
              // map iconName if there is one found in the options
              if (nameMap[iconName]) {
                const finalName = iconNamePrefix + nameMap[iconName];
                if (finalIconNames[finalName]) {
                  throw new Error(
                      `Renaming of ${iconName} to ${finalName} would produce duplicate icon name`);
                }
                iconName = finalName;
              } else {
                iconName = iconNamePrefix + iconName;
              }
              finalIconNames[iconName] = true;

              if (icons[iconName]) {
                throw new Error(`Icon with name ${iconName} has duplicate name`);
              }
              const svgStr = await processSVG(srcFile, iconName, extraCssClass);
              icons[iconName] = svgStr;
            }

            // generate the hash map with all SVGs
            let jsText = 'define([], function () {\n' +
                         '  return {\n';
            const iconNames = Object.keys(icons);
            for (let l = 0; l < iconNames.length; l++) {
              const iconName = iconNames[l];
              const iconStr = icons[iconName];

              jsText += '"' + iconName + '":';
              jsText += "'" + iconStr + "',\n";
            }
            jsText += ' };\n';
            jsText += '});';
            await writeFile(iconMapJSFileName, jsText);
            if (scheduleFilesForCleaning) {
              scheduleFileForCleaning(srcFiles);
            }
          }
        }
      }
      done();
    } catch (ex) {
      grunt.log.error(`${taskName}, target ${this.target} has thrown an exception: ${ex}`);
      grunt.log.error(`${ex.stack}`);
      done(false); // fail grunt task asynchronously
    }
  });

  async function rmdirs (dir) {
    const entries = await readdir(dir);
    const results = await Promise.all(entries.map(async (entry) => {
      const fullPath = path.join(dir, entry);
      const stats = await stat(fullPath);
      const task = stats.isDirectory() ? rmdirs(fullPath) : unlink(fullPath);
      return task.catch(error => ({ error }));
    }));
    results.forEach(result => {
      // Ignore missing files/directories; bail on other errors
      if (result && result.error.code !== 'ENOENT') {
        throw result.error;
      }
    });
    await rmdir(dir);
  }

  grunt.registerMultiTask('cleanupGeneratedSVGs', 'Deletes all generated SVG files',
    async function () {
      const done = this.async();
      const taskName = this.name;

      try {
        let directories = this.data;

        if (!_.isArray(directories)) {
          directories = [directories];
        }

        for (let i = 0; i < directories.length; i++) {
          const dir = directories[i];

          if (await exists(dir)) {
            grunt.log.debug(`Deleting ${dir}...`);
            await rmdirs(dir);
          } else {
            grunt.log.debug(`Skip deleting ${dir}, because it does not exist`);
          }
        }
        grunt.log.debug(`Finished ${taskName}...`);

        done();
      } catch (ex) {
        grunt.log.error(`${taskName}, target ${this.target} has thrown an exception: ${ex}`);
        grunt.log.error(`${ex.stack}`);
        done(false); // fail grunt task asynchronously
      }
    });
};
