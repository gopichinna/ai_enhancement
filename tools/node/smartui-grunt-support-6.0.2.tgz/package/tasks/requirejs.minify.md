# RequireJS Minifier for Smart UI

Minifies JavaScript bundles produced by the requirejs task in a Smart UI project using [terser].

* Can minify modern JavaScript. The integrated minifier in RequireJS cannot.
* Sets the root in the source map to the component prefix. A typical Smart UI project does not.

See also [grunt-support], which offers a task to simplify copying output artefacts from debug to release directory (`requirejsCopyRelease`), which is what should preceed their minification.

## Installation

1: You need [Node.js] 12 or newer and [Grunt] 1.3.0 or newer.

2: Make sure that the `@smartui` scope is declared in `.npmrc` in your project:

    npm set -L project @smartui:registry https://artifactory.opentext.net/artifactory/api/npm/npm_virt/

3: Install the `requirejsMinify` task and add it to your `package.json`:

    npm i -D @smartui/grunt-requirejs-minify

## Configuration

1: Remove the `requirejs:release` task, which builds and minifies the output, retain the `reequirejs:debug` task:

```js
grunt.initConfig({
  requirejs: {
    debug: { ... }
  },
  ...
});
```

2: Add `clean:release`, `copy:release` and` `requirejsMinify:release` tasks. Use the same array of bundle configurations that your passed to the `requirejs` task:

```js
grunt.initConfig({
  clean: {
    release: ['../out-release/**']
  },
  copy: {
   release: {
     files: [
       {
         cwd: '../out-debug',
         src: '**',
         dest: '../out-release',
         expand: true
       }
    ]
   }
  },
  requirejsMinify: {
    release: {
      options: { bundles: requirejsModules }
    }
  },
  ...
});
```

3: Load the `requirejsMinify` task:

```javascript
grunt.loadNpmTasks('@smartui/grunt-requirejs-minify');
```

4: Execute the `clean:release`, `copy:release` and `requirejsMinify` tasks instead of the `requirejs:release`:

```js
grunt.registerTask('release', ['clean:release', 'copy:release', 'requirejsMinify', ...]);
```

### Options

Default task options support the most usual usage scenario:

```js
requirejsMinify: {
  default: {
    bundleDir: '../out-release',
    bundles: [],
    prefix: '', // usually inferred from the bundle names
    ecma: 2020,
    json: false,
    force: false
  }
}
```

#### bundleDir
Type: `String`
Default value: `../out-release`

The output directory with the JavaScript bundles.

### bundles
Type: `Array<Object>`
Default value: `[]`

An array opf bundle-configuration objects. The same as you pass to the `requirejs` tasks through the `modules` option, for example:

```js
[
  {
    name: 'bundles/greet-commands',
    ...
  },
  {
    name: 'bundles/greet-rest',
    ...
  }
]
```

Only the `name` properties will be used to identify the file names.

### prefix
Type: `String`
Default value: `''`

The component prefix of the target Smart UI project. It will be inferred from the first bundle name, if empty. For example, `greet` will be inferred from `bundles/greet-commands`.

### ecma
Type: `Number`
Default value: `2020`

Specifies the desired ECMAScript standard version for the output. Setting it to `2015` or higher will use modern language features like shorthand object properties to achieve a higher compression ration. The values lowere than `2015` are `3` and `5`.

### json
Type: `Boolean`
Default value: `false`

If set to `true`, it will minify JSON bundle indexes too. It is `false` by default to avoid unnecessary problems on Content Server (Livelink). The concatenation of the bundle indexes in OScript is naive and needs them pretty-printed. If you do not deliver for CS, you can set it to `true` and save a couple of bytes.

### force
Type: `Boolean`
Default value: `false`

If set to `true`, it will suppress failures. Instead of making the Grunt fail,
the errors will be written only to the console.

[Node.js]: https://nodejs.org
[Grunt]: https://gruntjs.com
[terser]: https://terser.org/
[grunt-support]: https://gitlab.otxlab.net/smartui/tools/grunt-support
