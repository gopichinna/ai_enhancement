'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { collectModules, collectDependencies } = require('../utils/collect.dependencies');

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-contrib-clean');

  grunt.registerMultiTask('smartuiCompile',
    'Performs all tasks to build debug and release project output',
    function (task) {
      const options = this.options({
        config: 'config-build.js',
        rootDir: '..',
        appDir: '.',
        debugDir: '../out-debug',
        releaseDir: '../out-release',
        languageDir: '../out-languagepack_en',
        oscriptModuleName: undefined,
        oscriptInputDir: '../srcmodules',
        oscriptOutputDir: '../out-module',
        oscriptSupportDir: 'support',
        fileExclusionRegExp: /(?:\.spec\.js$)|(?:\bGruntfile\.js$)|(?:\bcomponent\.js$)/,
        buildNumber: undefined,
        version: undefined,
        isScript: undefined,
        onBuildRead: undefined,
        onBuildWrite: undefined,
        onModuleBundleComplete: undefined,
        logLevel: undefined,
        bundles: [],
        bundleIndexes: {},
        moduleDependencies: [],
        projectDependencies: [],
        checkExceptions: [],
        rebaseSourceMap: {},
        allowIndexedPrivateModules: false,
        minifyJSONBundleIndexes: false,
        force: false
      });
      let {
        config, rootDir, appDir, debugDir: bundleDir, releaseDir, languageDir,
        oscriptModuleName, oscriptInputDir, oscriptOutputDir, oscriptSupportDir,
        fileExclusionRegExp, bundles, bundleIndexes, checkExceptions,
        moduleDependencies, projectDependencies, minifyJSONBundleIndexes: json,
        rebaseSourceMap, allowIndexedPrivateModules, version, buildNumber,
        logLevel, force, isScript, onBuildRead, onBuildWrite, onModuleBundleComplete
      } = options;
      const prefix = Object.keys(bundleIndexes).length &&
        /^bundles\/(\w+)-/.exec(Object.keys(bundleIndexes)[0])[1];
      if (!projectDependencies.length) {
        projectDependencies = collectDependencies(rootDir);
      }
      if (!moduleDependencies.length) {
        moduleDependencies = collectModules(projectDependencies, { rootDir });
      }

      grunt.config.merge({
        // Copy, uglify and combine RequireJS modules to file bundles
        // See https://github.com/requirejs/r.js/blob/master/build/example.build.js.
        requirejsCompile: {
          auto: {
            options: {
              prefix,
              config,
              projectDependencies,
              rootDir,
              appDir,
              bundleDir,
              bundles,
              fileExclusionRegExp,
              logLevel,
              onBuildRead,
              onBuildWrite,
              onModuleBundleComplete,
              rebaseSourceMap,
              isScript
            }
          }
        },

        // Check if bundle indexes refer to distinct collection of modules
        requirejsBundleCheck: {
          auto: {
            options: { appDir, bundleDir, bundles, force }
          }
        },

        // Check if modules from the bundle index module are bundled in the same bundle
        requirejsIndexCheck: {
          auto: {
            options: { appDir, output: bundleDir, bundles, force }
          }
        },

        // Check if bundles contain only modules from this component (with the same prefix)
        requirejsContentCheck: {
          auto: {
            options: { bundleDir, bundles, exceptions: checkExceptions, force }
          }
        },

        // Check if we depend only on public modules
        requirejsDependencyCheck: {
          auto: {
            options: {
              config,
              appDir,
              bundleDir,
              bundles,
              dependencies: moduleDependencies,
              allowIndexedPrivateModules,
              force
            }
          }
        },

        // Extract bundles index to csui-index.js and csui-index.json files
        requirejsBundleIndex: {
          auto: {
            options: { bundleDir, bundleIndexes, force }
          }
        },

        // Generate a complete module list of the specified bundle
        requirejsBundleTOC: {
          auto: {
            options: { bundleDir, bundles, force }
          }
        },

        // Minify the release JavaScript and JSON
        requirejsMinify: {
          auto: {
            // Minifying JSON breaks the naive parsing of bundle indexes in CS
            options: { bundleDir: releaseDir, bundles, bundleIndexes, json, force }
          }
        },

        // Remove files and directories from the output which are not distributed
        requirejsCleanOutput: {
          auto_debug: { src: bundleDir },
          auto_release: { src: releaseDir }
        },

        // Remove files and directories from the output which are not distributed
        clean: {
          options: { force: true },
          auto_generated: ['bundles/*-index.*'],
          auto_release: [`${releaseDir}/*`],
          auto_language: [`${languageDir}/**`]
        },

        // Copies the debug build output to the release directory
        requirejsCopyRelease: {
          auto: {
            options: { debugDir: bundleDir, releaseDir, bundleIndexes }
          }
        },

        // Copy the module template and release output
        requirejsCopyOScript: {
          auto: {
            options: {
              moduleName: oscriptModuleName,
              inputDir: oscriptInputDir,
              outputDir: oscriptOutputDir,
              supportDir: oscriptSupportDir,
              releaseDir
            }
          }
        },

        // Replaces the build number in the extension-describing file
        requirejsGenerateVersion: {
          auto: {
            options: { prefix, bundleDir, buildNumber, version }
          }
        },

        // Generate bundles of concatenated i18n modules in the default language
        // (English, locale'root') prepared for localization to other languages
        languagepack: {
          auto: {
            options: {
              inputDir: bundleDir,
              outputDir: languageDir,
              bundles,
              bundleIndexes,
              force
            }
          }
        },

        // Generate RTL versions of stylesheet bundles
        requirejsRtlCss: {
          auto: {
            options: { prefix, bundleDir }
          }
        },

        // Minify the release stylesheets
        requirejsMinifyCss: {
          auto: {
            options: { prefix, bundleDir: releaseDir }
          }
        }
      });

      const debug = [
        'requirejsBundleIndex:auto', 'requirejsCompile:auto',
        'clean:auto_generated', 'requirejsCleanOutput:auto_debug',
        'requirejsBundleTOC:auto', 'requirejsIndexCheck:auto',
        'requirejsContentCheck:auto', 'requirejsBundleCheck:auto',
        'requirejsDependencyCheck:auto', 'clean:auto_language',
        'languagepack:auto', 'requirejsGenerateVersion:auto',
        'requirejsRtlCss:auto'];
      const release = [
        'clean:auto_release', 'requirejsCopyRelease:auto',
        'requirejsMinify:auto', 'requirejsMinifyCss:auto',
        'requirejsCleanOutput:auto_release', 'requirejsCopyOScript:auto'
      ];
      grunt.task.run(task === 'debug'
        ? debug
        : task === 'release'
          ? release
          : [...debug, ...release]);
    });
};
