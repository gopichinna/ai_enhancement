'use strict';

module.exports = function (grunt) {
  // compare number of files found with expected numbers
  grunt.registerMultiTask('checkSnapshotNumbers',
    'check correct number of snapshots',
    function () {
      const name = this.name;
      const expectedNumber = this.data.options.expectedNumber;
      grunt.log.debug(name + ': ' + this.files.length + ' vs ' + expectedNumber);

      if (expectedNumber > this.files.length) {
        throw new Error(name + ': expected ' + expectedNumber + ' files but only got ' + this.files.length);
      }
    }
  );
};
