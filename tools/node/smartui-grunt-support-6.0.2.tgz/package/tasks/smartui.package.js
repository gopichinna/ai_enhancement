'use strict';

const { loadLocalNpmTask } = require('../utils/load.npm.tasks');
const { readdirSync } = require('fs');

function guessPrefix () {
  for (const file of readdirSync('.')) {
    const index = file.indexOf('-extensions.json');
    if (index > 0) return file.substring(0, index);
  }
  throw new Error('Prefix neither provided nor guessed.');
}

module.exports = function (grunt) {
  loadLocalNpmTask(grunt, 'grunt-contrib-compress');

  grunt.registerMultiTask('smartuiPackage',
    'Packages sources and build output for distribution',
    function (task) {
      const options = this.options({
        prefix: undefined,
        debugDir: '../out-debug',
        releaseDir: '../out-release',
        languageDir: '../out-languagepack_en',
        extraSourceFiles: [],
        extraDebugFiles: [],
        extraReleaseFiles: [],
        extraLanguageFiles: []
      });
      const {
        prefix = guessPrefix(), debugDir, releaseDir, languageDir,
        extraSourceFiles, extraDebugFiles, extraReleaseFiles, extraLanguageFiles
      } = options;

      grunt.config.merge({
        // Package sources and build output for distribution
        compress: {
          auto_src: {
            options: {
              archive: `../dist/${prefix}-src.zip`,
              level: 9
            },
            files: [
              { src: ['**'] },
              ...extraSourceFiles
            ]
          },

          auto_debug: {
            options: {
              archive: `../dist/${prefix}-debug.zip`,
              level: 9
            },
            files: [
              {
                expand: true,
                cwd: debugDir,
                src: ['**']
              },
              extraDebugFiles
            ]
          },

          auto_release: {
            options: {
              archive: `../dist/${prefix}-release.zip`,
              level: 9
            },
            files: [
              {
                expand: true,
                cwd: releaseDir,
                src: ['**']
              },
              extraReleaseFiles
            ]
          },

          auto_languagepack_en: {
            options: {
              archive: `../dist/${prefix}-languagepack_en.zip`,
              level: 9
            },
            files: [
              {
                expand: true,
                cwd: languageDir,
                src: ['**']
              },
              extraLanguageFiles
            ]
          }
        }
      });

      grunt.task.run(`compress${task ? ':auto_' + task : ''}`);
    });
};
