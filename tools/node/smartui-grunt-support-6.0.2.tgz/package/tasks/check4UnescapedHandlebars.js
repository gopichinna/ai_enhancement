'use strict';

module.exports = function (grunt) {
  const { readFileSync } = require('fs');
  const _ = grunt.util._;

  // walk through handlebars templates (.hbs) and look for the use of unescaped values
  grunt.registerMultiTask('checkHbs4UnescapedValues',
    'check for the use of unescaped values',

    function () {
      const taskName = this.name;
      grunt.log.debug(taskName + ': found ' + this.files.length + ' files');
      let numFound = 0;
      _.each(this.files, function (file) {
        const src = file.src[0];
        const jsText = readFileSync(src, 'utf8');

        const regex = /{{{/g;
        const searchRes = jsText.match(regex);
        if (searchRes) {
          numFound += searchRes.length;
          grunt.log.error(src + ' uses ' + searchRes.length + ' unescaped values');
        }
      });
      if (numFound > 0) {
        grunt.log.error('Found ' + numFound + ' unescaped values in handlebars templates');
      } else {
        grunt.log.debug('No unescaped values found in handlebars templates');
      }
    });
};
