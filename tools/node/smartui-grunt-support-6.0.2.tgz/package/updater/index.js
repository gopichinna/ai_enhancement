const loadPackageJson = require('../utils/load.package.json');
const { promises } = require('fs');
const { readFile } = promises;

module.exports.check = force => {
  if (!force && process.env.RELCOMP) {
    console.log('Aborting the upgrade of internal dependencies. An IXMK project detected. (RELCOMP environment variable is not empty.) Dependencies in an ixmk project are usually maintained by its build tools. If you want to force the execution, use the --ignore-ixmk argument.');
    return false;
  }
  return true;
};

module.exports.list = async ({ rootDir, verbose } = {}) => {
  const updates = await startAndGetUpdates(rootDir, verbose);
  if (!updates.length) return;

  console.log(`Will update ${updates.join(', ')}.`);
};

module.exports.update = async ({ rootDir, save = true, verbose } = {}) => {
  const updates = await startAndGetUpdates(rootDir, verbose);
  if (!updates.length) return;

  console.log(`Updating ${updates.join(', ')}.`);
  const args = ['up', '--no-audit', '--progress=false', '--no-update-notifier'];
  if (!save) {
    args.push('--no-save');
  }
  if (verbose) {
    args.push('--verbose');
  }
  args.push(...updates);
  if (verbose) {
    console.log(`Executing npm "${args.join(' ')}".`);
  }
  await spawnProcess('npm', args);
  await spawnProcess('npm', ['ls', '--depth', '1', ...updates]);
};

async function startAndGetUpdates (rootDir, verbose) {
  const { pkgDir, pkg } = await loadPackageJson({ rootDir, verbose });
  rootDir = pkgDir;

  const { peerDependencies = {}, devDependencies = {}, dependencies = {} } = pkg;
  const deps = { ...peerDependencies, ...devDependencies, ...dependencies };
  if (verbose) console.log(`Analysing ${Object.keys(deps).length} dependencies.`);

  return getUpdates(rootDir, deps, verbose);
}

async function getUpdates (rootDir, deps, verbose, all = new Set()) {
  const updates = new Set();
  for (const name in deps) {
    const version = deps[name];
    if ((name.startsWith('@opentext/') || name.startsWith('@smartui/')) &&
        !all.has(name) && !/^\d+(?:\.\d+(?:\.\d+(?:-[^=<>]+)?)?)?$/.test(version)) {
      updates.add(name);
      all.add(name);
    }
  }
  if (verbose) console.log(`Added ${updates.size ? [...updates].join(', ') : 'nothing'}.`);
  for (const name of [...updates]) {
    const pkgName = `${rootDir}/node_modules/${name}/package.json`;
    const { peerDependencies = {} } = JSON.parse(await readFile(pkgName, 'utf8'));
    const depCount = Object.keys(peerDependencies).length;
    if (depCount) {
      if (verbose) console.log(`Analysing ${depCount} peer dependencies of "${name}".`);
      const peers = await getUpdates(rootDir, peerDependencies, verbose, all);
      for (const name of peers) {
        updates.add(name);
      }
    }
  }
  return [...updates];
}

function spawnProcess (command, args) {
  const { spawn } = require('child_process');
  return new Promise((resolve, reject) => {
    // NPM is a batch file on windows, which needs a shell expansion.
    const child = spawn(command, args, { shell: true })
      .on('error', reject)
      .on('exit', code => code ? reject(new Error(`"${command}" exited with ${code}`)) : resolve());
    child.stdout.on('data', data => process.stdout.write(data.toString()));
    child.stderr.on('data', data => process.stderr.write(data.toString()));
  });
}
