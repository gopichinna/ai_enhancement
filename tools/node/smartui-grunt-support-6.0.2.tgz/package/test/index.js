const { normalizeConfigLocation, loadBuildConfig, loadComponentsDescriptors } = require('../utils/load.config');
const { isScript: defaultIsScript, getScriptRules } = require('../utils/is.script');

const defaultPatterns = ['src/**/*.js', 'lib/src/**/*.js'];

function createKarmaPreprocessors ({ srcDir, configName, configPath, preprocessors = {}, patterns = [], isScript, sourceMap, verbose } = {}) {
  patterns = [...defaultPatterns, ...patterns];
  for (const pattern of patterns) {
    const names = preprocessors[pattern];
    if (names) names.unshift('requirejs-esm');
    else preprocessors[pattern] = ['requirejs-esm'];
  }

  if (!(srcDir || configPath)) srcDir = '../src';
  ({ srcDir, configPath } = normalizeConfigLocation({ srcDir, configName, configPath }));
  const components = loadComponentsDescriptors({ srcDir, configPath, verbose });
  const { prefix } = loadBuildConfig({ configPath, verbose });
  if (verbose) {
    console.log('Script recognition:');
    console.log(JSON.stringify(getScriptRules(components, prefix), undefined, 2));
  }

  const finalIsScript = path => defaultIsScript(components, path, prefix) && (!isScript || isScript(path));
  return { preprocessors, requirejsEsmPreprocessor: { isScript: finalIsScript, sourceMap } };
}

module.exports = { createKarmaPreprocessors };
