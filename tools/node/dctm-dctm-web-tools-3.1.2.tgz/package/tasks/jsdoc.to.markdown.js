'use strict';

const
  path = require('path');
const { writeFileSync } = require('fs');
const jsdoc2md = require('jsdoc-to-markdown');
const chalk = require('chalk');

module.exports = (grunt) => {
  grunt.registerMultiTask('jsdoc2md', 'Generate .md files from jsdoc comments in source code', function () {
    const
      options = this.options();
    const done = this.async();

    let skipCount = 0;

    const promises = this.files.flatMap(fileDesc => {
      return fileDesc.src.map(file => {
        const
          srcName = path.basename(file, path.extname(file));
        const srcPath = path.dirname(file);
        const destPath = ((fileDesc.dest) ? path.dirname(fileDesc.dest) : srcPath);
        const destFile = path.join(destPath, srcName + '.md');

        return jsdoc2md.render({ ...options, files: [file] })
          .then(mdContent => {
            if (mdContent) {
              grunt.verbose.writeln(`jsdoc2md: ${chalk.green(file)} -> ${chalk.green(destFile)}`).or.writeln(`writing ${chalk.green(destFile)}`);
              grunt.file.mkdir(destPath);
              writeFileSync(destFile, mdContent);
            } else {
              skipCount++;
              grunt.verbose.writeln(`jsdoc2md: no doc for ${chalk.yellow(file)}`);
            }
          })
          .catch(e => {
            grunt.log.error(chalk.red(`${e} while processing: ${file}`));
            throw e;
          });
      });
    });

    Promise.all(promises).then(() => {
      grunt.verbose.or.writeln(`${chalk.green(`[${this.files.length - skipCount}]`)} documentations are generated.`);
      if (skipCount) {
        grunt.verbose.or.writeln(chalk.yellow(`[${skipCount}] files skipped due to no documentation, check verbose log for list of files.`));
      }
      done();
    }).catch(e => {
      grunt.fail.fatal('jsdoc2md: Failed to generate documentations.');
      done('false');
    });
  });
};
