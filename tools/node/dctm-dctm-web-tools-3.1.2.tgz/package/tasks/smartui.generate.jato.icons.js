'use strict';

const fg = require('fast-glob');
const path = require('path');
const {
  readFile,
  writeFile,
  stat,
  unlink
} = require('fs/promises');
const jatoIconBundler = require('@smartui/jato-icons-bundler');
const { getImmediateSVFDependencies } = require('@dctm/dctm-web-tools/utils/svf.helper');
const { processSVG } = require('../utils/icon.helper');

const keyExtractorRegexp = /['"]([^'"]+)['"]\s*:/g;
const contentExtractorRegexp = /let\s*icons\s=\s({[\s\S]*?});/;
const SRC_BASE = '../lib/src';
const mdFileName = 'BaseJatoIcons.md';

const CsuiIconsMap = {
  actionIcons: 'csui/themes/csui.jato.action.icons.js',
  // branding: 'csui/themes/csui.jato.branding.icons.js', //not part of bundle index
  illustrations: 'csui/themes/csui.jato.mime.illustrations.js',
  mimeIcons: 'csui/themes/csui.jato.mime.icons.js',
  statusIcons: 'csui/themes/csui.jato.status.icons.js'
};
const SmartIconsMap = {
  actionIcons: 'smart/themes/jato.icons/smart.jato.action.icons.js',
  illustrations: 'smart/themes/jato.icons/smart.jato.illustrations.js',
  mimeIcons: 'smart/themes/jato.icons/smart.jato.mime.js',
  statusIcons: 'smart/themes/jato.icons/smart.jato.status.icons.js'
};
/* folder-name to target file name mapping without the 'jato_' prefix */
const fileMapping = {
  action: 'action_icons',
  branding: 'branding',
  emoticon: 'emoticons',
  illustration: 'illustrations',
  mime: 'mime_icons',
  status: 'status_icons',
  other: 'other_icons'
};
/* folder-name to icon category name mapping */
const folderToTypeMapping = {
  action: 'actionIcons',
  branding: 'branding',
  // emoticon: 'emoticons', //for now not including emoticons
  illustration: 'illustrations',
  mime: 'mimeIcons',
  status: 'statusIcons',
  other: 'otherIcons'
};
/* Used only for providing the reference module name in the md file */
const iconRepoName = {};

Object.entries(fileMapping).forEach(([k, v]) => {
  const typeKey = folderToTypeMapping[k];
  if (typeKey) {
    iconRepoName[typeKey] = 'dctmw.jato.' + fileMapping[k].replaceAll('_', '.');
  }
});

async function fileExists (file) {
  try {
    return await stat(file);
  } catch (statEx) {
    if (statEx.code !== 'ENOENT') {
      throw statEx;
    }
  }
}

async function generateIconsManifest (grunt) {
  const iconsMap = {};
  const svfDeps = getImmediateSVFDependencies();
  const entries = [...Object.entries(SmartIconsMap), ...Object.entries(CsuiIconsMap)];

  for (const [type, filePath] of entries) {
    const keys = await getIconKeys(grunt, path.join(SRC_BASE, filePath));
    iconsMap[type] = [...new Set([...(iconsMap[type] || []), ...keys])];
  }

  for (const dep of svfDeps) {
    for (const [type, name] of Object.entries(fileMapping)) {
      const iconType = folderToTypeMapping[type];
      const filePath = `${SRC_BASE}/${dep}/utils/theme/jato_${name}.js`;
      if (iconType && await fileExists(filePath)) {
        const keys = await getIconKeys(grunt, filePath);
        iconsMap[iconType] = [...new Set([...(iconsMap[iconType] || []), ...keys])];
      }
    }
  }

  return iconsMap;
}

async function createMDfile (groupedKeys, targetDir) {
  let mdContent =
    '# JATO Icons from the parent modules\n\n' +
    'This file contains the list icons which will be provided to this package directly from the parent modules<br/>\n' +
    '**NOTE: At runtime, DCTM icon modules will have additional icons which might be coming from other packages.**\n---\n';

  for (const [type, keys] of Object.entries(groupedKeys)) {
    mdContent += `\n## Type: ${type} [dctmw/utils/icons/${iconRepoName[type]}]\n\n`;
    keys.sort();
    if (keys.length) {
      keys.forEach(key => {
        mdContent += `- ${key}\n`;
      });
    } else {
      mdContent += '---\n';
    }
  }
  await writeFile(path.join(targetDir, mdFileName), mdContent);
}

function extractKeys (content) {
  return [...content.matchAll(keyExtractorRegexp)].map(match => match[1]);
}

async function getIconKeys (grunt, filePath) {
  if (await fileExists(filePath)) {
    const content = await readFile(filePath, 'utf8');
    return extractKeys(content);
  } else {
    grunt.log.warn(`generateDctmwJatoSVGBundle: ${filePath} not found`);
    return [];
  }
}

async function processIconFiles (grunt, targetDir, additionalSvgs, iconsData, icons, baseIconsData, prefix, verbose) {
  for (const [type, iconGroupKey] of Object.entries(folderToTypeMapping)) {
    const inheritedIcons = new Set(baseIconsData[iconGroupKey]);

    const destFileName = fileMapping[type] + '.js';
    let jatoIconsList = iconsData[iconGroupKey] || [];
    const iconContent = icons[iconGroupKey];
    if (iconContent) {
      jatoIconsList.push(...iconContent.split('|'));
    }

    jatoIconsList = [...new Set(jatoIconsList)].join('|');

    let svgFiles = [];
    const promises = [];
    const fileNames = [];

    if (await fileExists(additionalSvgs)) {
      svgFiles = await fg(`${additionalSvgs}/${type}/*.svg`);
      for (const entry of svgFiles) {
        promises.push(processSVG(entry));
        fileNames.push(path.basename(entry, path.extname(entry)));
      }
    }

    const FILE_HEAD = 'define([], function(){\nlet icons = {\n';
    const FILE_TAIL = '};\nreturn icons;\n});';

    const tempFileName = 'temp_' + iconGroupKey;
    const jatoIconBundle = path.join(targetDir, tempFileName + '.js');

    let generatedContent = FILE_HEAD;
    if (jatoIconsList) {
      const currProjIconSet = new Set();
      await jatoIconBundler(jatoIconsList, targetDir, tempFileName, verbose, true, false);
      if (await fileExists(jatoIconBundle)) {
        const data = await readFile(jatoIconBundle, 'utf8');
        const content = data.match(contentExtractorRegexp)[1];
        generatedContent += '/* copied from the output of jato-icon-bundler */\n';
        const iconsString = content.substring(content.indexOf('{') + 1, content.lastIndexOf('}'));
        const skippedIcons = [];

        for (const line of iconsString.split('\n')) {
          const key = extractKeys(line);
          if (key.length) {
            currProjIconSet.add(key[0]);
            if (inheritedIcons.has(key[0])) {
              skippedIcons.push(key[0]);
            } else {
              generatedContent += line + '\n';
            }
          }
        }
        if (skippedIcons.length) {
          grunt.log.warn(`generateDctmwJatoSVGBundle: Skipped the following icons of type ${type}: ${skippedIcons.join('|')}`);
        }
      } else {
        grunt.log.warn(`generateDctmwJatoSVGBundle: unable to locate the file ${tempFileName}.js`);
      }

      // Test if we were able to generate a file with all provided icons in the jato.icons file
      const providedIconsSet = new Set(jatoIconsList.split('|'));
      if (providedIconsSet.size !== currProjIconSet.size) {
        const missingItems = [...providedIconsSet].filter(item => !currProjIconSet.has(item));
        grunt.fail.fatal('Unable to find the following items in the @jato/svg library : ' + [...missingItems].sort().join('|'));
      }
    }
    if (await fileExists(jatoIconBundle)) {
      await unlink(jatoIconBundle);
    }

    if (svgFiles.length) {
      const svgs = await Promise.all(promises);
      let parsedContent = '';
      let processed = false;

      for (let i = 0; i < svgs.length; i++) {
        const iconName = fileNames[i];
        if (!generatedContent.includes(`'${iconName}'`)) {
          processed = true;
          parsedContent += `'${prefix}${iconName}':\`${svgs[i]}\`,\n`;
        } else {
          grunt.log.warn(`generateDctmwJatoSVGBundle: Skipping ${iconName} since it was already present`);
        }
      }

      if (processed) {
        generatedContent += `/* SVGs BUNDLED FROM ${additionalSvgs}/${type} */\n`;
        generatedContent += parsedContent;
      }
    }

    generatedContent += FILE_TAIL;
    const generatedFilePath = path.join(targetDir, 'jato_' + destFileName);
    grunt.log.writeln(`generateDctmwJatoSVGBundle: Generated ${generatedFilePath}`);
    await writeFile(generatedFilePath, generatedContent, 'utf8');
  }
}

module.exports = function (grunt) {
  grunt.registerTask('generateDctmwJatoSVGBundle', 'Generates JATO icon bundles using jato-icons-bundler from the jato.icons file and utils/theme/jato/images location', async function () {
    const done = this.async();

    try {
      const iconsManifest = await generateIconsManifest(grunt);
      const targetDir = 'utils/theme';

      const {
        verbose,
        additionalSvgs,
        icons,
        iconsJson,
        prefix
      } = this.options({
        verbose: false,
        icons: {},
        additionalSvgs: 'utils/theme/jato/images',
        iconsJson: 'utils/theme/jato/jato.icons.json'
      });

      if (!prefix) {
        throw new Error('Package prefix has to be configured');
      }

      await createMDfile(iconsManifest, targetDir);

      let iconsData = {};
      if (await fileExists(iconsJson)) {
        iconsData = JSON.parse(await readFile(iconsJson, 'utf8'));
      }
      await processIconFiles(grunt, targetDir, additionalSvgs, iconsData, icons, iconsManifest, prefix, verbose);

      done();
    } catch (error) {
      grunt.fail.fatal(error);
    }
  });
};
