'use strict';

const chalk = require('chalk');
const { join, resolve } = require('path');
const { existsSync, ensureDirSync, readJsonSync, ensureSymlinkSync, unlinkSync } = require('fs-extra');

function ensureDirSymLink (source, target) {
  console.log(`Creating symbolic link ${chalk.cyan(source)} -> ${chalk.cyan(target)}`);
  const srcDir = resolve(source);
  ensureDirSync(srcDir);
  try {
    const targetPath = resolve(target);
    if (existsSync(targetPath)) {
      console.log(`Unlinking old target for ${chalk.red(targetPath)}`);
      unlinkSync(targetPath);
    }
    ensureSymlinkSync(srcDir, targetPath, 'junction');
  } catch (e) {
    console.warn(e);
  }
}

function createLink ({ depInstallDir, pkgDir, svfName }) {
  const targetDir = join(depInstallDir, 'lib');
  if (resolve(depInstallDir) !== resolve(pkgDir)) {
    ensureDirSymLink(targetDir, join(pkgDir, 'lib'));
  }
  ensureDirSymLink(join(pkgDir, 'src'), join(targetDir, `src/${svfName}`));
  ensureDirSymLink(join(pkgDir, 'out-debug'), join(targetDir, `debug/${svfName}`));
  ensureDirSymLink(join(pkgDir, 'out-release'), join(targetDir, `release/${svfName}`));
}

module.exports = function (pkgName) {
  const depInstallDir = process.env.INIT_CWD;
  if (!depInstallDir) throw new Error('not run during npm install');

  const pkgDir = join(depInstallDir, 'node_modules', pkgName);

  if (existsSync(pkgDir)) {
    const pkgJson = readJsonSync(join(pkgDir, 'package.json'));
    const { svf: { name: svfName } } = pkgJson;
    if (svfName) {
      createLink({ depInstallDir, pkgDir, svfName });
    } else {
      throw new Error(`SVF descriptor missing from package.json of ${[pkgName]}`);
    }
  } else {
    const { name, svf: { name: svfName } } = readJsonSync(join(depInstallDir, 'package.json'));
    if (name === pkgName) {
      if (svfName) {
        createLink({ depInstallDir, pkgDir: depInstallDir, svfName });
      } else {
        console.warn(chalk.redBright(`SVF descriptor missing from package.json of ${[pkgName]}`));
      }
      process.exit(0);
    }
    throw new Error(`Could not link non-existing ${pkgName}`);
  }
};
