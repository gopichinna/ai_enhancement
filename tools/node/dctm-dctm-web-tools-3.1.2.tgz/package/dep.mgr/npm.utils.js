'use strict';

const chalk = require('chalk');

const DCTM_SVF_SCOPE = '@dctm';
const DCTM_NPM_SEARCH_PATTERN = 'dctm-web-*';

const NPM_REPO_NAME = 'npm_virt';
const ARTIFACTORY_API_BASE_URL = 'https://artifactory.opentext.net/artifactory/api';

function getNPMPackageMetadata ({ pkgName, debug, npmRepoName = NPM_REPO_NAME }) {
  return import('node-fetch')
    .then(({ default: fetch }) => {
      const repoUrl = `${ARTIFACTORY_API_BASE_URL}/npm/${npmRepoName}`;
      debug && console.log(`Fetching metadata for ${chalk.cyan(pkgName)} from ${chalk.cyan(repoUrl)}`);
      return fetch(`${repoUrl}/${pkgName}`)
        .then(response => response.json())
        .then(resp => {
          const { errors = [] } = resp;
          if (errors.length) {
            return Promise.reject(errors[0]);
          } else {
            debug && console.log(`Distribution tags of ${chalk.cyan(pkgName)} are ${chalk.cyan(JSON.stringify(resp['dist-tags']))}`);
            return resp;
          }
        });
    });
}

function discoverNPMPackages ({ distTag, debug, npmRepoName = NPM_REPO_NAME, packageScope = DCTM_SVF_SCOPE, packageNamePattern = DCTM_NPM_SEARCH_PATTERN }) {
  return import('node-fetch')
    .then(({ default: fetch }) => {
      const isScoped = (!!packageScope && typeof packageScope === 'string');
      const normalizedPkgNamePattern = (!!packageNamePattern && typeof packageNamePattern === 'string') ? packageNamePattern : '*';
      const completePkgNamePattern = isScoped ? `${packageScope}/${normalizedPkgNamePattern}` : normalizedPkgNamePattern;
      const discoveryUrl = `${ARTIFACTORY_API_BASE_URL}/search/prop?repos=${npmRepoName}&npm.name=${completePkgNamePattern}`;
      const url = new URL(discoveryUrl);
      url.searchParams.append('npm.disttag', distTag);
      debug && console.log(`Discovering NPM packages from ${chalk.cyan(url)}`);

      return fetch(url)
        .then(response => response.json())
        .then(({ results = [], errors = [] }) => {
          if (errors.length) {
            return Promise.reject(errors[0]);
          } else {
            return results.map(({ uri = '' }) => {
              let parts = uri.split('/-/');
              if (parts.length) {
                parts = parts[0].split('/').reverse();
                if (parts.length) {
                  if (isScoped && parts.length > 2) {
                    return `${parts[1]}/${parts[0]}`;
                  } else if (parts.length > 1) {
                    return parts[0];
                  }
                }
              }
              return null;
            }).filter(n => !!n);
          }
        });
    });
}

module.exports = { getNPMPackageMetadata, discoverNPMPackages };
