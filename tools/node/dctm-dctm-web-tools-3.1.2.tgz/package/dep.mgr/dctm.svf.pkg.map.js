'use strict';

const chalk = require('chalk');
const { join: pathJoin } = require('path');
const { existsSync, readdirSync } = require('fs-extra');
const { execSync } = require('child_process');
const { readSelfPackageJson } = require('../utils/json.util');
const { calculateSVFDependencies } = require('../utils/svf.helper');
const { getNPMPackageMetadata, discoverNPMPackages } = require('./npm.utils');
const PATTERN_VERSION = /(\d+)\.(\d+)\.(\d+)(-next(\.\d+)?)?$/;
const PKG_DCTM_SVF_CORE = '@dctm/dctm-web-core';

function createVersionBreakup (strVersion = '') {
  const match = strVersion.match(PATTERN_VERSION);
  if (!match) {
    throw new Error(`[strVersion=${strVersion}] is not compatible with DCTM SVF allowed semvar standard`);
  } else {
    return {
      exact: strVersion,
      major: match[1],
      minor: match[2],
      patch: match[3],
      distTagDev: `${match[1]}.${match[2]}-next`,
      distTagRel: `${match[1]}.${match[2]}-latest`
    };
  }
}

function getRemotePkgMeta (options = {}) {
  const { debug, useRelease } = options;
  const { version: targetVersion } = (typeof options.version === 'string') ? options : readSelfPackageJson(options);
  const versionBreakup = createVersionBreakup(targetVersion);
  const distTag = useRelease ? versionBreakup.distTagRel : versionBreakup.distTagDev;
  const svfPkgsKnownSoFar = [];

  debug && console.log(`Target version: ${chalk.cyan(targetVersion)}`);
  return Promise.resolve()
    .then(() => discoverNPMPackages({ ...options, distTag, debug }))
    .then((discoveredPackages = []) => {
      // This re-ordering is needed to ensure highest priority for SVF core package processing, while calculating resolvable svf package data later.
      return [PKG_DCTM_SVF_CORE, ...(discoveredPackages.filter(pkgName => pkgName !== PKG_DCTM_SVF_CORE))];
    })
    .then((discoveredPackages = []) => Promise.all(discoveredPackages.map(pkgName => getNPMPackageMetadata({ pkgName, debug }))))
    .then((metadata) => {
      const pkgMap = {};

      let mappedMetadata = metadata.map(pkgMeta => {
        const { name: npmName, versions, 'dist-tags': distTags } = pkgMeta;
        const { svf: { name: svfName, deps: svfDeps } } = versions[distTags[distTag]] ?? { svf: { name: '', deps: [] } };

        if (!svfName) {
          return null;
        }

        svfPkgsKnownSoFar.push(svfName);
        const resolves = svfDeps.filter(d => !svfPkgsKnownSoFar.includes(d));

        // Prepare data to be used during next run while calculating complete dependecies
        resolves.forEach(upstreamDep => {
          if (!pkgMap[upstreamDep]) {
            pkgMap[upstreamDep] = { dependencies: [] };
          }
        });
        if (pkgMap[svfName]) {
          Array.prototype.push.apply(pkgMap[svfName].dependencies, svfDeps);
        } else {
          pkgMap[svfName] = { dependencies: [...svfDeps] };
        }
        // End of prepare data

        Array.prototype.push.apply(svfPkgsKnownSoFar, resolves);
        svfPkgsKnownSoFar.push(svfName);
        resolves.push(svfName);
        const pkg = {
          npmName,
          svfName,
          resolves
        };

        pkg.distTags = {
          dev: distTags[versionBreakup.distTagDev],
          devNext: versionBreakup.distTagDev,
          rel: distTags[versionBreakup.distTagRel],
          relLast: distTags['latest']
        };

        return pkg;
      });

      debug && console.log(`SVF PKG MAP: ${chalk.cyan(JSON.stringify(pkgMap))}`);
      mappedMetadata = mappedMetadata.filter(pkg => !!pkg);
      mappedMetadata.forEach(pkg => {
        Object.assign(pkg, calculateSVFDependencies(pkg.svfName, pkgMap));
        debug && console.log(`SVF PKG: ${chalk.cyan(JSON.stringify(pkg))}`);
      });

      return mappedMetadata;
    }, console.error);
}

function getLocalPkgMeta (options = {}) {
  const projDir = require('../utils/dir.util').getProjectDirectory();
  const { refDir = projDir, debug } = options;
  const selfPackageJson = readSelfPackageJson({ debug });
  const selfNpmDependencies = { ...selfPackageJson.dependencies, ...selfPackageJson.devDependencies, ...selfPackageJson.peerDependencies };

  const selfNpmDepKeys = Object.keys(selfNpmDependencies);
  const allNpmDepsPresent = selfNpmDepKeys.length ? selfNpmDepKeys.every(d => existsSync(pathJoin(refDir, 'node_modules', d))) : existsSync(pathJoin(refDir, 'node_modules', PKG_DCTM_SVF_CORE));
  if (!allNpmDepsPresent) {
    execSync('npm install', { stdio: 'inherit', cwd: refDir });
  }

  const pkgMap = {};
  const directSvfNpmPackages = {};
  const svfPkgsKnownSoFar = [];
  const dctmNpmNames = readdirSync(pathJoin(refDir, 'node_modules', '@dctm'), { withFileTypes: true }).filter(e => e.isDirectory() || e.isSymbolicLink()).map(e => `@dctm/${e.name}`).filter(n => n !== PKG_DCTM_SVF_CORE);
  dctmNpmNames.unshift(PKG_DCTM_SVF_CORE);
  dctmNpmNames.forEach(d => {
    if (existsSync(pathJoin(refDir, 'node_modules', d, 'src/component.js'))) {
      debug && console.log(`NPM package ${chalk.cyan(d)} is found as a direct SVF package.`);
      const { svf: { name: svfName, deps: svfDeps } } = require(pathJoin(refDir, 'node_modules', d, 'package.json'));

      if (!svfName) {
        return;
      }

      svfPkgsKnownSoFar.push(svfName);
      const resolves = svfDeps.filter(d => !svfPkgsKnownSoFar.includes(d));

      // Prepare data to be used during next run while calculating complete dependecies
      resolves.forEach(upstreamDep => {
        if (!pkgMap[upstreamDep]) {
          pkgMap[upstreamDep] = { dependencies: [] };
        }
      });
      if (pkgMap[svfName]) {
        Array.prototype.push.apply(pkgMap[svfName].dependencies, svfDeps);
      } else {
        pkgMap[svfName] = { dependencies: [...svfDeps] };
      }
      // End of prepare data

      Array.prototype.push.apply(svfPkgsKnownSoFar, resolves);
      svfPkgsKnownSoFar.push(svfName);
      resolves.push(svfName);

      directSvfNpmPackages[svfName] = {
        npmName: d,
        svfName,
        resolves
      };
    }
  });

  debug && console.log(`SVF PKG MAP: ${chalk.cyan(JSON.stringify(pkgMap))}`);

  Object.keys(directSvfNpmPackages).forEach((svfName) => {
    const pkg = directSvfNpmPackages[svfName];
    Object.assign(pkg, calculateSVFDependencies(pkg.svfName, pkgMap));
    debug && console.log(`SVF PKG: ${chalk.cyan(JSON.stringify(pkg))}`);
  });

  return directSvfNpmPackages;
}

module.exports = { getRemotePkgMeta, getLocalPkgMeta, PKG_DCTM_SVF_CORE };
