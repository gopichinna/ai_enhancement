'use strict';

const chalk = require('chalk');
const { execSync } = require('child_process');
const { readSelfPackageJson, writeSelfPackageJson } = require('../utils/json.util');
const { getImmediateSVFDependencies, getCompleteSVFDependencies } = require('../utils/svf.helper');

module.exports = async function (options = {}) {
  const projDir = require('../utils/dir.util').getProjectDirectory();
  const selfPackageJson = readSelfPackageJson(options);
  const { svf: { name: svfName } } = selfPackageJson;
  const { getRemotePkgMeta } = require('./dctm.svf.pkg.map');
  const completeDependencies = getCompleteSVFDependencies();
  const immediateDependencies = getImmediateSVFDependencies();
  let { pkgNames, debug, saveDev, useRelease } = options;
  let isSelfA12NDependent = completeDependencies.indexOf('a12n') >= 0;
  let isSelfA12NCompatible = isSelfA12NDependent || completeDependencies[completeDependencies.length - 1] === 'dctmw';

  if (debug) {
    console.log(`Complete dependencies [${chalk.cyan(completeDependencies.length ? completeDependencies : 'none')}] at present`);
    console.log(`Immediate dependencies [${chalk.cyan(immediateDependencies.length ? immediateDependencies : 'none')}] at present`);
    console.log(`Current context ${isSelfA12NDependent ? 'is' : chalk.red('is not')} ${chalk.green('a12n')} dependent.`);
  }

  if (typeof pkgNames === 'string') {
    pkgNames = [pkgNames];
  }

  const filteredOutPackageNames = [];
  pkgNames = pkgNames.filter(pName => {
    if (pName === svfName) {
      console.log(chalk.red(`Can not add self(${svfName}) as a dependency`));
      return false;
    }

    if (completeDependencies.includes(pName)) {
      filteredOutPackageNames.push(pName);
      return false;
    }

    return true;
  });

  filteredOutPackageNames.length && console.log(`Ignored adding dependencies [${chalk.yellow(filteredOutPackageNames)}] as they are already available in project path`);

  if (pkgNames.length) {
    const pkgMap = {};

    const pkgMetadata = await getRemotePkgMeta({ debug, useRelease });
    pkgMetadata.forEach(({ npmName, svfName, resolves, distTags, svfPkgs }) => {
      const isPkgA12NDependent = svfPkgs.indexOf('a12n') >= 0;
      const isPkgA12NCompatible = svfName === 'dctmw' || isPkgA12NDependent;
      if (isSelfA12NDependent && !isPkgA12NCompatible) {
        debug && console.log(`${chalk.red(svfName)} is unavailable as it isn't compatible with ${chalk.green('a12n')}`);
        return;
      }

      resolves.forEach(r => {
        pkgMap[r] = { npmName, svfName, distTags, isPkgA12NCompatible, isPkgA12NDependent };
      });
    });

    const resolvedNPMDeps = {};
    const resolvedPackages = [];
    const unresolvedPackages = [];
    pkgNames.forEach(svfPkgName => {
      debug && console.log(`Evaluating dependency ${chalk.cyan(svfPkgName)} before adding`);
      const npmDep = pkgMap[svfPkgName];
      if (npmDep) {
        if (npmDep.isPkgA12NDependent) {
          if (!isSelfA12NCompatible) {
            debug && console.log(`${chalk.red(svfPkgName)} is unavailable as it is incompatible with current context`);
            unresolvedPackages.push(svfPkgName);
            return;
          }
        } else {
          if (isSelfA12NDependent) {
            debug && console.log(`${chalk.red(svfPkgName)} is unavailable as it is incompatible with current context`);
            unresolvedPackages.push(svfPkgName);
            return;
          }
        }

        isSelfA12NCompatible &= npmDep.isPkgA12NCompatible;
        isSelfA12NDependent |= npmDep.isPkgA12NDependent;

        if (!resolvedPackages.includes(npmDep.svfName)) {
          resolvedPackages.push(npmDep.svfName);
        }
        resolvedNPMDeps[npmDep.npmName] = useRelease === true ? `~${npmDep.distTags.rel}` : npmDep.distTags.devNext;
      } else {
        unresolvedPackages.push(svfPkgName);
      }
    });
    unresolvedPackages.length && console.log(`${chalk.yellow(`Can't add incompatible/unknown SVF dependencies [${unresolvedPackages}]`)}`);
    debug && resolvedPackages.length && console.log(`SVF packages to add [${chalk.green(resolvedPackages)}] through NPM dependencies ${chalk.green(JSON.stringify(resolvedNPMDeps))}`);

    if (Object.keys(resolvedNPMDeps).length) {
      const selfSvf = selfPackageJson.svf;
      const deps = Array.isArray(selfSvf.deps) ? selfSvf.deps : [];
      selfSvf.deps = deps;
      Array.prototype.push.apply(deps, resolvedPackages);
      const packageDependencies = saveDev === true ? selfPackageJson.devDependencies : selfPackageJson.dependencies;
      Object.assign(packageDependencies, resolvedNPMDeps);
      selfPackageJson[saveDev === true ? 'devDependencies' : 'dependencies'] = packageDependencies;
      debug && console.log(`Final package.json ${chalk.green(JSON.stringify(selfPackageJson, undefined, 2))}`);

      writeSelfPackageJson({ debug, jsonContent: selfPackageJson });

      console.log('Installing dependencies...');
      execSync('npm install', { stdio: 'inherit', cwd: projDir });
    }
  } else {
    console.log(chalk.yellow('No additional dependencies to be added'));
  }
};
