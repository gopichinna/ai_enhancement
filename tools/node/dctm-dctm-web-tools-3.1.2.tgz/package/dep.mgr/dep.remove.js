'use strict';

const { join: pathJoin } = require('path');
const chalk = require('chalk');
const { execSync } = require('child_process');
const { sync: rimrafSync } = require('rimraf');
const { readSelfPackageJson, writeSelfPackageJson } = require('../utils/json.util');
const { getImmediateSVFDependencies, getCompleteSVFDependencies } = require('../utils/svf.helper');

module.exports = async function (options = {}) {
  const projDir = require('../utils/dir.util').getProjectDirectory();
  const selfPackageJson = readSelfPackageJson(options);
  const { svf: { name: svfName } } = selfPackageJson;
  const { getLocalPkgMeta } = require('./dctm.svf.pkg.map');
  const completeDependencies = getCompleteSVFDependencies();
  const immediateDependencies = getImmediateSVFDependencies();
  let { pkgNames, debug } = options;

  if (debug) {
    console.log(`Complete dependencies [${chalk.cyan(completeDependencies.length ? completeDependencies : 'none')}] at present`);
    console.log(`Immediate dependencies [${chalk.cyan(immediateDependencies.length ? immediateDependencies : 'none')}] at present`);
  }

  if (typeof pkgNames === 'string') {
    pkgNames = [pkgNames];
  }

  const filteredOutPackageNames = [];
  pkgNames = pkgNames.filter(pName => {
    if (pName === 'dctmw') {
      console.log(chalk.red('Can not remove mandatory dependency \'dctmw\''));
      return false;
    }

    if (pName === svfName) {
      console.log(chalk.red(`Can not remove self(${svfName}) as a dependency`));
      return false;
    }

    if (!completeDependencies.includes(pName)) {
      filteredOutPackageNames.push(pName);
      return false;
    }

    return true;
  });

  filteredOutPackageNames.length && console.log(`${chalk.yellow(`Can't remove unknown dependencies [${filteredOutPackageNames}]`)}`);

  if (pkgNames.length) {
    const pkgMetadata = getLocalPkgMeta({ refDir: projDir, debug });

    const rejectedSVFs = [];
    const removableSVFs = [];
    const calculateRemovable = (pkgName) => {
      return Object.keys(pkgMetadata).filter(k => !(k === pkgName || removableSVFs.includes(k))).every(k => {
        return !pkgMetadata[k].iDeps.includes(pkgName);
      });
    };
    pkgNames.forEach(pkgName => {
      if (!pkgMetadata[pkgName]) {
        rejectedSVFs.push(pkgName);
      } else {
        const isRemovable = calculateRemovable(pkgName);
        if (!isRemovable) {
          rejectedSVFs.push(pkgName);
        } else {
          removableSVFs.push(pkgName);
          pkgMetadata[pkgName].iDeps.forEach(d => {
            if (!pkgMetadata[d] && calculateRemovable(d)) {
              removableSVFs.push(d);
              const i = rejectedSVFs.indexOf(d);
              if (i !== -1) {
                rejectedSVFs.splice(i, 1);
              }
            }
          });
        }
      }
    });
    rejectedSVFs.length && console.log(chalk.yellow(`Can't remove dependencies [${rejectedSVFs}] as they are in use by other dependencies`));

    if (removableSVFs.length) {
      const removableNPMs = {};
      removableSVFs.forEach(s => {
        if (pkgMetadata[s]) {
          removableNPMs[pkgMetadata[s].npmName] = true;
        }
        const iIndex = immediateDependencies.indexOf(s);
        if (iIndex !== -1) {
          immediateDependencies.splice(iIndex, 1);
        }
      });

      debug && console.log(chalk.green(`SVF packages to be removed [${removableSVFs}] with their corresponding NPM packages [${Object.keys(removableNPMs)}]`));

      const svf = selfPackageJson.svf || {};
      svf.deps = immediateDependencies;
      selfPackageJson.svf = svf;

      ['dependencies', 'devDependencies', 'peerDependencies'].forEach(dSection => {
        selfPackageJson[dSection] && Object.keys(selfPackageJson[dSection]).forEach(k => {
          if (removableNPMs[k]) {
            delete selfPackageJson[dSection][k];
          }
        });
      });

      debug && console.log(`Final package.json ${chalk.green(JSON.stringify(selfPackageJson, undefined, 2))}`);

      writeSelfPackageJson({ debug, jsonContent: selfPackageJson });

      console.log('Cleaning up dependencies...');
      removableSVFs.forEach(s => {
        rimrafSync(pathJoin(projDir, `lib/src/${s}`));
        rimrafSync(pathJoin(projDir, `lib/debug/${s}`));
        rimrafSync(pathJoin(projDir, `lib/release/${s}`));
      });
      execSync('npm install', { stdio: 'inherit', cwd: projDir });
    }
  } else {
    console.log(chalk.yellow('No dependencies to be removed.'));
  }
};
