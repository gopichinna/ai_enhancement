'use strict';

const chalk = require('chalk');
const { execSync } = require('child_process');
const { join: pathJoin } = require('path');
const { copy: fileCopy, remove: removeFile } = require('fs-extra');
const { PKG_JSON_FILENAME, readSelfPackageJson, writeSelfPackageJson } = require('../utils/json.util');
const PKG_JSON_BKUP_FILENAME = `${PKG_JSON_FILENAME}.bak`;

module.exports = async function (options = {}) {
  let { pkgName, debug, save = true, install = true, releaseOnly = false, excludes = [], overwrite = false } = options;
  excludes = excludes.filter(ex => ex !== pkgName);
  debug && console.log(`Executing with options: ${chalk.cyan(JSON.stringify(options, null, 2))}`);

  const projDir = require('../utils/dir.util').getProjectDirectory();
  const { getRemotePkgMeta, PKG_DCTM_SVF_CORE } = require('./dctm.svf.pkg.map');

  let pkgMetadata = await getRemotePkgMeta({ debug });
  debug && console.log(`All discovered packages: ${chalk.cyan(JSON.stringify(pkgMetadata))}`);
  console.log(`Found a total of ${chalk.green(pkgMetadata.length)} packages.`);

  console.log(`Filtering packages with common dependency: ${chalk.green(pkgName)}`);
  pkgMetadata = pkgMetadata.filter(pkg => (pkg.npmName === PKG_DCTM_SVF_CORE || pkg.svfPkgs.includes(pkgName)));

  console.log(`Excluding top-level SVF packages: ${chalk.yellow(JSON.stringify(excludes))}`);
  pkgMetadata = pkgMetadata.filter(pkg => !(excludes.includes(pkg.svfName)));

  const selfPackageJson = readSelfPackageJson({ debug });
  const selfVersion = selfPackageJson.version;

  if (pkgMetadata.length) {
    let globalError = false;
    let hasChange = false;

    selfPackageJson.dependencies ??= {};
    selfPackageJson.devDependencies ??= {};
    selfPackageJson.peerDependencies ??= {};
    const selfNpmDependencies = { ...selfPackageJson.dependencies, ...selfPackageJson.devDependencies, ...selfPackageJson.peerDependencies };
    pkgMetadata.forEach(pkg => {
      const npmName = pkg.npmName;
      const writeDown = !selfNpmDependencies[npmName] || overwrite;

      if (writeDown) {
        const distTags = pkg.distTags ?? {};
        let localError = false;
        let version;
        if (releaseOnly) {
          if (!distTags.rel) {
            localError = true;
            console.log(`A matching ${chalk.red('release')} version not found for: ${chalk.red(npmName)} in the series ${chalk.red(selfVersion)}`);
          } else {
            version = `~${distTags.rel}`;
          }
        } else {
          const devKey = save ? 'devNext' : 'dev'; // When package.json changes will be saved, then use the version series otherwise use exact version number to guarantee latest is pulled
          if (!distTags[devKey]) {
            localError = true;
            console.log(`A matching ${chalk.red(devKey)} version not found for: ${chalk.red(npmName)} in the series ${chalk.red(selfVersion)}`);
          } else {
            version = distTags[devKey];
          }
        }

        globalError |= localError;

        if (!localError) {
          console.log(`Adding package ${chalk.green(npmName)} with version ${chalk.green(version)}`);
          selfPackageJson.dependencies[npmName] = version;
          delete selfPackageJson.devDependencies[npmName];
          delete selfPackageJson.peerDependencies[npmName];
          hasChange = true;
        }
      } else {
        debug && console.log(`Skipping existing dependency ${chalk.yellow(npmName)}. Specify overwrite option to update.`);
      }
    });

    if (globalError) {
      console.log(chalk.red(`Error exists, cannot continue.${debug ? '' : ' Run with -d option for more verbose logging.'}`));
      return;
    }

    if (!selfPackageJson.svf) {
      hasChange = true;
      selfPackageJson.svf = {};
    }

    if (!Object.keys(selfPackageJson.devDependencies).length) {
      delete selfPackageJson.devDependencies;
    }

    if (!Object.keys(selfPackageJson.peerDependencies).length) {
      delete selfPackageJson.peerDependencies;
    }

    let pkgJsonBackedUp = false; const pkgJsonPath = pathJoin(projDir, PKG_JSON_FILENAME); const bkupPkgJsonPath = pathJoin(projDir, PKG_JSON_BKUP_FILENAME);
    if (hasChange) {
      debug && console.log(`Updated ${PKG_JSON_FILENAME} content ${chalk.cyan(JSON.stringify(selfPackageJson, null, 2))}`);
      if (save) {
        console.log(`Saving changes to ${chalk.cyan(PKG_JSON_FILENAME)}`);
        writeSelfPackageJson({ jsonContent: selfPackageJson, debug });
      } else {
        console.log(`Changes wont't be saved to ${chalk.yellow(PKG_JSON_FILENAME)}.`);
        debug && console.log(`Backing up ${chalk.cyan(pkgJsonPath)} to ${chalk.cyan(bkupPkgJsonPath)}`);
        pkgJsonBackedUp = true;
        await fileCopy(pkgJsonPath, bkupPkgJsonPath, { overwrite: true, preserveTimestamps: true });
        writeSelfPackageJson({ jsonContent: selfPackageJson, debug });
      }
    } else {
      console.log(`No changes to ${chalk.cyan(PKG_JSON_FILENAME)}`);
    }

    if (install) {
      console.log(chalk.green('Installing SVF packages...'));
      execSync('npm install', { stdio: 'inherit', cwd: projDir });
    } else {
      console.log(chalk.yellow('Skipping installation per specified option.'));
    }

    if (pkgJsonBackedUp) {
      debug && console.log(`Restoring ${chalk.cyan(pkgJsonPath)} from ${chalk.cyan(bkupPkgJsonPath)}`);
      await fileCopy(bkupPkgJsonPath, pkgJsonPath, { overwrite: true, preserveTimestamps: true });
      debug && console.log(`Removing ${chalk.cyan(bkupPkgJsonPath)}`);
      await removeFile(bkupPkgJsonPath);
    }

    console.log(chalk.green('Done.'));
  } else {
    console.log(chalk.red(`No compatible SVF packages found for d=${pkgName}, ex=${JSON.stringify(excludes)} and v=${selfVersion} combination.`));
  }
};
