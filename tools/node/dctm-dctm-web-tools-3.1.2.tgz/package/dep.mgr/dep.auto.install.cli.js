#!/usr/bin/env node

'use strict';

const { Command } = require('commander');
const program = new Command();
const autoInstaller = require('./dep.auto.install');

program
  .name('dctmw-dep-auto')
  .description('Automatically add and install all DCTM SVF packages of a common dependency denominator')
  .version(require('../package.json').version)
  .option('-d, --debug', 'Output verbose logging')
  .option('--no-save', 'Do not persist changes done to package.json')
  .option('--no-install', 'Do not install the packages. Along with --no-save, the command just dry runs what would happen')
  .option('-ro, --release-only', 'Only add relesed version of dependencies. Defaults to false, indicating installation of present in-development version')
  .option('-x, --exclude [excludes...]', 'Top level SVF packages to be excluded, even if they match the common dependency denominator')
  .option('-od, --overwrite-declared', 'For dependency pacakges, overwrite the declared version in package.json with their auto discovered versions. Defaults to false, indicating declaration in package.json is given priority')
  .argument('<pkgName>', 'SVF name of the common dependency that should be present in all auto discovered packages.')
  .action(async (pkgName, opts) => {
    await autoInstaller({ pkgName, debug: opts.debug, save: opts.save, install: opts.install, releaseOnly: opts.releaseOnly, excludes: opts.exclude, overwrite: opts.overwriteDeclared });
  });

program.parse();
