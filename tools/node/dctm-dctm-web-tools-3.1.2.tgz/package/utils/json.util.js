'use strict';

const chalk = require('chalk');
const { join: pathJoin } = require('path');
const { readJsonSync, outputJsonSync } = require('fs-extra');
const projDir = require('../utils/dir.util').getProjectDirectory();
const PKG_JSON_FILENAME = 'package.json';

function readPackageJson (options = {}) {
  const { refDir, debug } = options;

  if (refDir) {
    const pkgJsonPath = pathJoin(refDir, PKG_JSON_FILENAME);
    debug && console.log(`Reading from ${chalk.cyan(pkgJsonPath)}`);
    return readJsonSync(pkgJsonPath);
  } else {
    debug && console.log(chalk.red(`Missing 'refDir' option. Not able to read ${PKG_JSON_FILENAME}`));
  }

  return {};
}

function readSelfPackageJson (options = {}) {
  return readPackageJson({ ...options, refDir: projDir });
}

function writePackageJson (options = {}) {
  const { refDir, debug, jsonContent = {} } = options;

  if (refDir) {
    const pkgJsonPath = pathJoin(refDir, PKG_JSON_FILENAME);
    debug && console.log(`Updating ${chalk.cyan(pkgJsonPath)}`);
    outputJsonSync(pkgJsonPath, jsonContent, { spaces: 2 });
  } else {
    debug && console.log(chalk.red(`Missing 'refDir' option. Not able to write ${PKG_JSON_FILENAME}`));
  }
}

function writeSelfPackageJson (options = {}) {
  writePackageJson({ ...options, refDir: projDir });
}

module.exports = {
  PKG_JSON_FILENAME,
  readPackageJson,
  readSelfPackageJson,
  writePackageJson,
  writeSelfPackageJson
};
