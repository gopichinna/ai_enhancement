const readline = require('readline');
const fs = require('fs');

const processSVG = // Read the svg file and return the complete SVG as a one-line-string
  async function processSVG (src) {
    let completeSvgString = '';
    return await new Promise((resolve, reject) => {
      readline.createInterface({
        input: fs.createReadStream(src),
        terminal: false
      }).on('line', function (line) {
        const truncatedLine = line.trim();
        if (!truncatedLine) {
          return;
        }
        if (truncatedLine.startsWith('<?xml') && truncatedLine.endsWith('?>')) {
          return; // skip the xml tag
        }
        if (truncatedLine.startsWith('<!--') && truncatedLine.endsWith('-->')) {
          return; // don't add comment
        }
        completeSvgString = completeSvgString + truncatedLine + ' ';
      }).on('close', function () {
        const final = completeSvgString.trim().replace(/'/g, '\\\''); // escape single quotes
        resolve(final);
      });
    });
  };
exports.processSVG = processSVG;
