'use strict';

const { dirname, normalize, join: pathJoin } = require('path');
const { existsSync } = require('fs-extra');
const chalk = require('chalk');
let projectDir;

function getProjectDirectoryInternal () {
  if (process.env['npm_package_json']) {
    return dirname(process.env['npm_package_json']);
  }

  let scanPath = normalize(process.cwd());
  while (scanPath) {
    if (existsSync(pathJoin(scanPath, 'package.json'))) {
      return scanPath;
    }
    const pDir = dirname(scanPath);
    scanPath = (pDir === scanPath) ? null : pDir;
  }

  console.log(chalk.yellowBright('A package.json could not be found in scan path. Falling back to current directory as project directory'));
  return normalize(process.cwd());
}

function getProjectDirectory () {
  if (projectDir === undefined) {
    projectDir = getProjectDirectoryInternal();
  }

  return projectDir;
}

module.exports = {
  getProjectDirectory
};
