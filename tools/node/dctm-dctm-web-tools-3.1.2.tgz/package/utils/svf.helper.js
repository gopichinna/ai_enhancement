'use strict';

const { join: pathJoin } = require('path');
const { existsSync, readdirSync } = require('fs-extra');
const _ = require('underscore');
const PATTERN_VERSION = /\d+\.\d+\.\d+/;
let pkgVersion;
let normalizedVersion;
const nonSVFPkgs = [];
const completeDependencies = [];
const immediateDependencies = [];
let generatedLaunchConfig = {};
let discoveryDone = false;

function calculateSVFDependencies (svfName, pkgMap) {
  pkgMap = JSON.parse(JSON.stringify(pkgMap));

  const immediateDependencies = [];
  const completeDependencies = [];
  const deps = [];

  let presentRank = 0;

  if (svfName && pkgMap[svfName]) {
    pkgMap[svfName].rank = presentRank;
    const nDeps = [...pkgMap[svfName].dependencies].reverse();
    Array.prototype.push.apply(deps, nDeps);
    Array.prototype.push.apply(immediateDependencies, pkgMap[svfName].dependencies);
  } else {
    Array.prototype.push.apply(deps, Object.keys(pkgMap));
  }

  while (deps.length !== 0) {
    const dep = deps.shift();
    pkgMap[dep].rank = --presentRank;
    if (pkgMap[dep]) {
      const nDeps = [...pkgMap[dep].dependencies].reverse();
      Array.prototype.push.apply(deps, nDeps);
    }
  }

  const svfPkgs = Object.keys(pkgMap)
    .filter(k => pkgMap[k].rank !== undefined)
    .sort((a, b) => {
      return pkgMap[a].rank - pkgMap[b].rank;
    });

  Array.prototype.push.apply(completeDependencies, (svfName && pkgMap[svfName]) ? svfPkgs.slice(0, svfPkgs.length - 1) : svfPkgs);

  return { iDeps: immediateDependencies, cDeps: completeDependencies, svfPkgs };
}

function discoverPackages () {
  if (discoveryDone === true) {
    return;
  }

  const projDir = require('./dir.util').getProjectDirectory();
  const { version: verPkg, svf: { name: svfName } } = require(pathJoin(projDir, 'package.json'));
  pkgVersion = verPkg;

  const origLaunchConfigPath = pathJoin(projDir, 'launcher.json');
  if (existsSync(origLaunchConfigPath)) {
    const origLaunchConfig = require(origLaunchConfigPath);
    generatedLaunchConfig = { ...origLaunchConfig };
  }

  const pkgMap = {};
  const srcDirPath = pathJoin(projDir, 'lib/src');

  readdirSync(srcDirPath, { withFileTypes: true }).forEach(d => {
    if (d.isDirectory() || d.isSymbolicLink()) {
      const componentPath = pathJoin(srcDirPath, d.name, 'component.js');
      const initScriptName = `${d.name}-init.js`;
      const initScriptPath = pathJoin(srcDirPath, d.name, initScriptName);
      if (existsSync(componentPath)) {
        const compJs = require(componentPath);
        pkgMap[d.name] = { dependencies: _.isFunction(compJs.getSVFDependencies) ? compJs.getSVFDependencies() : [] };
        if (existsSync(initScriptPath)) {
          pkgMap[d.name]['initScript'] = initScriptName;
        }
      } else {
        nonSVFPkgs.push(d.name);
      }
    }
  });

  const calculatedDependencies = calculateSVFDependencies(svfName, pkgMap);
  Array.prototype.push.apply(immediateDependencies, calculatedDependencies.iDeps);
  Array.prototype.push.apply(completeDependencies, calculatedDependencies.cDeps);
  const svfPkgs = calculatedDependencies.svfPkgs;

  const addlIndex = svfPkgs.indexOf('dctmw');
  if (addlIndex < 0) {
    throw new Error('Not using DCTM SVF framework');
  }

  discoveryDone = true;

  generatedLaunchConfig.version = getVersion();
  const addlPackages = {};
  let order = 0;
  for (let i = addlIndex + 1; i < svfPkgs.length; i++) {
    const pkg = svfPkgs[i];
    const pkgDescriptor = { order: ++order };
    if (pkgMap[pkg].initScript) {
      pkgDescriptor.initScript = pkgMap[pkg].initScript;
    }
    addlPackages[pkg] = pkgDescriptor;
  }
  generatedLaunchConfig.packages = addlPackages;
}

function getLaunchConfig () {
  discoverPackages();
  return generatedLaunchConfig;
}

function getNonSVFPackages () {
  discoverPackages();
  return [...nonSVFPkgs];
}

function getCompleteSVFDependencies () {
  discoverPackages();
  return [...completeDependencies];
}

function getImmediateSVFDependencies () {
  discoverPackages();
  return [...immediateDependencies];
}

function getVersion () {
  discoverPackages();

  if (normalizedVersion) {
    return normalizedVersion;
  }

  const match = pkgVersion.match(PATTERN_VERSION);

  if (!match) {
    throw new Error(`Unconventional package version : ${pkgVersion}, semvar compatible version is expected.`);
  }

  normalizedVersion = match[0];
  return normalizedVersion;
}

module.exports = {
  getVersion,
  getLaunchConfig,
  getNonSVFPackages,
  getImmediateSVFDependencies,
  getCompleteSVFDependencies,
  calculateSVFDependencies
};
