'use strict';

function requestInterceptor (req, res, next) {
  // TODO: Customized logic to take control of certain request URLs
  next(); // Default implementation is to do nothing and hand-off to next interceptor
}

module.exports = {
  LOCAL_HTTP_PORT: 6989,
  LOCAL_HTTPS_PORT: 9698,
  APP_SERVER_URL: '', // Sample URL format - http://10.194.111.112:8080/D2-Smartview or http://10.194.111.112:8080/d2fs-rest-web
  APP_SERVER_IS_PROXIED: true,
  PROXIED_APP_SERVER_ALLOWS_SELF_SIGNED_HTTPS: false, // TODO: Set to `true` while connecting to a proxied HTTPS app server configured with self-signed certificate
  LAUNCHER_JSON_LOCATION_WRT_UI: '', // If launcher.json is moved from its original location in /public/ui, then set this property to relative path value of its new location w.r.t the original location, instead of the equivalent property in index.html
  requestInterceptor
};
